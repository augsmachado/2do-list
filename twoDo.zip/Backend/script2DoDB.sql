--drop database 2Do;
create database 2Do;
use 2Do;

create table users(
	id serial primary key,
    username varchar(100) not null,
    email varchar(100) not null,
    password varchar(100) not null
);

create table clients(
	id serial primary key,
    fullname varchar(100) not null,
    cpf varchar(100) not null,
    address varchar(100) not null,
    phone varchar(100) not null,
    birthDate date not null
);


create table embroideries(
	id serial primary key,
    name varchar(100) not null,
    photo varchar(100) not null,
    description varchar(255) not null
);

create table thumbnails(
	id serial primary key,
    name varchar(100) not null,
    photo varchar(100) not null,
    description varchar(255) not null
);

create table materials(
	id serial primary key,
    name varchar(100) not null,
    unitMeasure varchar(100) not null,
    amount int not null,
    width float not null,
    height float not null,
    length float not null
);

create table products(
	id serial primary key,
    name varchar(100) not null,
    photo varchar(100) not null,
    width float not null,
    unitMeasure varchar(100) not null,
	height float not null,
    length float not null
);


create table orders(
	id serial primary key,
    
    idUser int not null,
    idClient int not null,
  
	idProduct int not null,
    idThumbnail int not null,
    idEmbroidery int not null,
    
    orderCreationDate timestamp not null,
	orderDeliveryDate timestamp not null,
    
    orderStats varchar(100) not null,
    
    orderAmount int not null,
    orderValue float not null,
    orderWidth float not null,
    orderHeight float not null,
    orderLength float not null,
    orderUnitMeasure varchar(100) not null,
    orderDescription text
);

ALTER TABLE orders
ADD FOREIGN KEY (idClient) REFERENCES clients(id);

ALTER TABLE orders
ADD FOREIGN KEY (idProduct) REFERENCES products(id);

ALTER TABLE orders
ADD FOREIGN KEY (idThumbnail) REFERENCES thumbnails(id);

ALTER TABLE orders
ADD FOREIGN KEY (idEmbroidery) REFERENCES embroideries(id);

ALTER TABLE orders
ADD FOREIGN KEY (idUser) REFERENCES users(id);