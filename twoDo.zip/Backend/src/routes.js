const express = require('express');
const multer = require('multer');

const uploadConfig = require('./config/upload');

const UserController = require('./controllers/UserController');
const ClientController = require('./controllers/ClientController');
const EmbroideryController = require('./controllers/EmbroideryController');
const ThumbnailController = require('./controllers/ThumbnailController');
const ProductController = require('./controllers/ProductController');
const MaterialController = require('./controllers/MaterialController');
const OrderController = require('./controllers/OrderController');

const routes = express.Router();
const upload = multer(uploadConfig);

//Users
// Login
routes.use('/login', async (req, res) => {
    if (req.method == "POST") {
        const user = await UserController.login(req, res)
        if (user.username) {
            res.send(user);
        }
        else {
            res.send(login);
        }
    }
})
// Orders
routes.get('/users', UserController.index);
routes.get('/users/:_id', UserController.show);
routes.post('/users', UserController.store);
routes.put('/users/:_id', UserController.update);
routes.delete('/users/:_id', UserController.destroy);

routes.post('/resetPassword', UserController.resetPassword);

// Clients
routes.get('/clients', ClientController.index);
routes.get('/clients/:_id', ClientController.show);
routes.post('/clients', ClientController.store);
routes.put('/clients/:_id', ClientController.update);
routes.delete('/clients/:_id', ClientController.destroy);
//Birthdays
routes.get('/birthday', ClientController.birthDay);
routes.put('/updateBirth/:_id', ClientController.updateBirth);

// Embroideries
routes.get('/embroideries', EmbroideryController.index);
routes.get('/embroideries/:_id', EmbroideryController.show);
routes.post('/embroideries', upload.single('photo'), EmbroideryController.store);
routes.put('/embroideries/:_id', upload.single('photo'), EmbroideryController.update);
routes.delete('/embroideries/:_id', EmbroideryController.destroy);

// Thumbnails
routes.get('/thumbnails', ThumbnailController.index);
routes.get('/thumbnails/:_id', ThumbnailController.show);
routes.post('/thumbnails', upload.single('photo'), ThumbnailController.store);
routes.put('/thumbnails/:_id', upload.single('photo'), ThumbnailController.update);
routes.delete('/thumbnails/:_id', ThumbnailController.destroy);

// Products
routes.get('/products', ProductController.index);
routes.get('/products/:_id', ProductController.show);
routes.post('/products', upload.single('photo'), ProductController.store);
routes.put('/products/:_id', upload.single('photo'), ProductController.update);
routes.delete('/products/:_id', ProductController.destroy);

// Materials
routes.get('/materials', MaterialController.index);
routes.get('/materials/:_id', MaterialController.show);
routes.post('/materials', MaterialController.store);
routes.put('/materials/:_id', MaterialController.update);
routes.delete('/materials/:_id', MaterialController.destroy);

// Orders
routes.get('/orders', OrderController.index);
routes.get('/orders/:_id', OrderController.show);
routes.post('/orders', OrderController.store);
routes.put('/orders/:_id', OrderController.update);
routes.delete('/orders/:_id', OrderController.destroy);

routes.put('/ordershistory/:_id', OrderController.updateStatus);

module.exports = routes;