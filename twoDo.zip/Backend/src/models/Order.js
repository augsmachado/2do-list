const mongoose = require('mongoose');

const OrderSchema = new mongoose.Schema({
    user:  {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User'
    },
    client:  {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Client'
    },
    orderHistoric: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'OrderHistoric'
    },

    product:  {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Product'
    },

    thumbnail:  {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Thumbnail'
    },

    embroidery:  {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Embroidery'
    },
    
    deliveryDate: Date,
    status: String,
    amount: Number,
    title: String,
    orderValue: Number,
    unitMeasure: String,
    width: Number,
    height: Number,
    length: Number,
    description: String,
    exclud: {type: Boolean, default: false}
}, {timestamps: true});

module.exports = mongoose.model('Order', OrderSchema);
