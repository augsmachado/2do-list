const mongoose = require('mongoose');

const MaterialSchema = new mongoose.Schema({
    title: String,
    unitMeasure: String,
    amount: Number,
    width: Number,
    height: Number,
    length: Number,
    user: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User'
    },
    exclud: {type: Boolean, default: false}
}, {timestamps: true});

module.exports = mongoose.model('Material', MaterialSchema);
