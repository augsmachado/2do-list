const mongoose = require('mongoose');

const ProductSchema = new mongoose.Schema({
    title: String,
    photo: String,
    unitMeasure: String,
    width: Number,
    height: Number,
    length: Number,
    description: String,
    user: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User'
    },
    exclud: {type: Boolean, default: false}
}, {timestamps: true});

module.exports = mongoose.model('Product', ProductSchema);
