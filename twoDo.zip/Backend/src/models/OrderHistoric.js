const mongoose = require('mongoose');

const OrderHistoricSchema = new mongoose.Schema({
    order: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Order'
    },
    status: String
}, {timestamps: true});

module.exports = mongoose.model('OrderHistoric', OrderHistoricSchema);
