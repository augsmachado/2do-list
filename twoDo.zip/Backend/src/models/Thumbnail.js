const mongoose = require('mongoose');

const ThumbnailSchema = new mongoose.Schema({
    title: String,
    photo: String,
    description: String,
    user: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User'
    },
    exclud: {type: Boolean, default: false}
}, {timestamps: true});

module.exports = mongoose.model('Thumbnail', ThumbnailSchema);
