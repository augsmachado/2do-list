const mongoose = require('mongoose');

const ClientSchema = new mongoose.Schema({
    fullName: String,
    cpf: String,
    address: String,
    phone: String,
    birthDate: Date,
    lastBirthDate: Date,
    exclud: {type: Boolean, default: false}
}, {timestamps: true});

module.exports = mongoose.model('Client', ClientSchema);
