const mongoose = require('mongoose');

const EmbroiderySchema = new mongoose.Schema({
    title: String,
    photo: String,
    description: String,
    user: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User'
    },
    exclud: {type: Boolean, default: false}
}, {timestamps: true});

module.exports = mongoose.model('Embroidery', EmbroiderySchema);
