const express = require('express');
const mongoose = require('mongoose');
const routes = require('./routes');
const cors = require('cors');
const app = express();
const http = require('http');
const server = http.Server(app);

const morgan = require('morgan');

// connection with the database, after need to be changed to online server
// mongoose.connect('mongodb://127.0.0.1:27017', {}).catch(err => {
//   console.log('erro conect mongoCloud', err)
// })

mongoose.connect('mongodb://twoDo:twoDo@twodo-shard-00-00-lif4p.mongodb.net:27017,twodo-shard-00-01-lif4p.mongodb.net:27017,twodo-shard-00-02-lif4p.mongodb.net:27017/twoDo?ssl=true&replicaSet=twoDo-shard-0&authSource=admin&retryWrites=true&w=majority', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
});

// set morgan to log info about our requests time for development use.
app.use(morgan('dev'));

// cors settings, need to chenge after the front was complited
var whitelist = ['http://localhost:3000', 'http://localhost:3333']
var corsOptions = {
  origin: function (origin, callback) {
    console.log(origin)
    // Allow tools or server-to-server requests, add
    if (whitelist.indexOf(origin) !== -1 || !origin) {
      callback(null, true)
    } else {
      callback(new Error('Not allowed by CORS'))
    }
  }
}
app.use(cors(corsOptions));
app.use(express.json());
app.use(routes);

server.listen(3333);
