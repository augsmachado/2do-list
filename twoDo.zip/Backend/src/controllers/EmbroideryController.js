const Embroidery = require('../models/Embroidery');
const User = require('../models/User');

module.exports = {
    async index(req, res) {
        try {
            let embroidery = await Embroidery.find({ exclud: false }).exec();
            return res.status(200).json(embroidery);

        }
        catch (e) {
            console.log('Error index embroidery', e)
            return res.status(404).json('Error index embroidery' + e);
        }
    },

    async show(req, res) {
        try {

            const { _id } = req.params

            let embroidery = await Embroidery.findOne({ _id }).exec();
            return res.status(200).json(embroidery);

        }
        catch (e) {
            console.log('Error show embroidery', e)
            return res.status(404).json('Error show the embroidery' + e);
        }
    },

    async store(req, res) {
        try {

            const { filename } = req.file;
            const { title, description } = req.body;
            // const { user_id } = req.headers;

            // // Save only if user logged
            // const user = await User.findById(user_id);

            // if (!user) {
            //     return res.status(404).json({'User does not exists' });
            // }

            const embroidery = await Embroidery.create({
                // user: user_id,
                photo: filename,
                title,
                description
            })

            return res.status(200).json(embroidery);

        }
        catch (e) {
            console.log('Error store embroidery', e)
            return res.status(400).json('Error create the embroidery' + e);
        }
    },

    async update(req, res) {
        try {
            var { filename } = { filename: undefined }
            if (req.file) {
                filename = req.file.filename;
            }

            const _id = req.params
            const { title, description } = req.body;
            // const { user_id } = req.headers;

            // // Save only if user logged
            // const user = await User.findById(user_id);

            // if (!user) {
            //     return res.status(404).json({ erro: 'User does not exists' });
            // }
            var embroidery
            if (filename) {
                embroidery = await Embroidery.findByIdAndUpdate(_id, {
                    photo: filename,
                    title,
                    description
                }, { new: true }).exec()
            }
            else {
                embroidery = await Embroidery.findByIdAndUpdate(_id, {
                    title,
                    description
                }, { new: true }).exec()
            }

            return res.status(200).json(embroidery);
        }
        catch (e) {
            console.log('Error update embroidery', e)
            return res.status(304).json('Error update the embroidery' + e);
        }
    },

    async destroy(req, res) {
        try {

            const { _id } = req.params

            let embroidery = Embroidery.findByIdAndUpdate(_id, {
              exclud: true
            }, { new: true }).exec()
            return res.status(200).json(embroidery);

        }
        catch (e) {
            console.log('Error destroy embroidery', e)
            return res.status(304).json('Error delete the embroidery' + e);
        }
    },
}
