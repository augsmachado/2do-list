const Thumbnail = require('../models/Thumbnail');
const User = require('../models/User');

module.exports = {
    async index(req, res) {
        try {
            let thumbnail = await Thumbnail.find({ exclud: false }).exec();
            return res.status(200).json(thumbnail);

        }
        catch (e) {
            console.log('Error index thumbnail', e)
            return res.status(404).json('Error index thumbnail' + e);
        }
    },

    async show(req, res) {
        try {

            const { _id } = req.params

            let thumbnail = await Thumbnail.findOne({ _id }).exec();
            console.log(thumbnail)
            return res.status(200).json(thumbnail);

        }
        catch (e) {
            console.log('Error show thumbnail', e)
            return res.status(404).json('Error show the thumbnail' + e);
        }
    },

    async store(req, res) {
        try {

            const { filename } = req.file;
            const { title, description } = req.body;

            const thumbnail = await Thumbnail.create({
                // user: user_id,
                photo: filename,
                title,
                description
            })

            return res.status(200).json(thumbnail);

        }
        catch (e) {
            console.log('Error store thumbnail', e)
            return res.status(400).json('Error create the thumbnail' + e);
        }
    },

    async update(req, res) {
        try {
            var { filename } = { filename: undefined }
            if (req.file) {
                filename = req.file.filename;
            }
            const { _id } = req.params;

            const { title, description } = req.body;
            // const { user_id } = req.headers;

            // // Save only if user logged
            // const user = await User.findById(user_id);

            // if (!user) {
            //     return res.status(404).json({ erro: 'User does not exists' });
            // }
            var thumbnail
            if (filename) {
                thumbnail = await Thumbnail.findByIdAndUpdate(_id, {
                    photo: filename,
                    title,
                    description
                }, { new: true }).exec()
            }
            else {
                thumbnail = await Thumbnail.findByIdAndUpdate(_id, {
                    title,
                    description
                }, { new: true }).exec()
            }

            return res.status(200).json(thumbnail);
        }
        catch (e) {
            console.log('Error update thumbnail', e)
            return res.status(304).json('Error update the thumbnail' + e);
        }
    },

    async destroy(req, res) {
        try {

            const { _id } = req.params

            let thumbnail = await Thumbnail.findByIdAndUpdate(_id, {
                exclud: true
            }, { new: true }).exec()

            return res.status(200).json(thumbnail);

        }
        catch (e) {
            console.log('Error destroy thumbnail', e)
            return res.status(304).json('Error delete the thumbnail' + e);
        }
    },
}
