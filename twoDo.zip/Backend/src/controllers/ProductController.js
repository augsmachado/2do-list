const Product = require('../models/Product');
const User = require('../models/User');

module.exports = {
    async index(req, res) {
        try {
            let product = await Product.find({ exclud: false }).exec();
            return res.status(200).json(product);

        }
        catch (e) {
            console.log('Error index product', e)
            return res.status(404).json('Error index product' + e);
        }
    },

    async show(req, res) {
        try {

            const { _id } = req.params

            let product = await Product.findOne({ _id }).exec();
            return res.status(200).json(product);

        }
        catch (e) {
            console.log('Error show product', e)
            return res.status(404).json('Error show the product' + e);
        }
    },

    async store(req, res) {
        try {

            const { filename } = req.file;
            const { title, description, unitMeasure, amount, width, height, length } = req.body;
            // const { user_id } = req.headers;

            // // Save only if user logged
            // const user = await User.findById(user_id);

            // if (!user) {
            //     return res.status(404).json({ erro: 'User does not exists' });
            // }

            const product = await Product.create({
                //user: user_id,
                photo: filename,
                title,
                description,
                unitMeasure,
                amount,
                width,
                height,
                length
            })

            return res.status(200).json(product);

        }
        catch (e) {
            console.log('Error store product', e)
            return res.status(400).json('Error create the product' + e);
        }
    },

    async update(req, res) {
        try {
            var { filename } = { filename: undefined }
            if (req.file) {
                filename = req.file.filename;
            }
            const { title, description, unitMeasure, amount, width, height, length } = req.body;
            const { _id } = req.params;

            var product
            if (filename) {
                product = await Product.findByIdAndUpdate(_id, {
                    photo: filename,
                    title,
                    description,
                    unitMeasure,
                    amount,
                    width,
                    height,
                    length
                }, { new: true }).exec()
            }
            else {
                product = await Product.findByIdAndUpdate(_id, {
                    //user: user_id,
                    title,
                    description,
                    unitMeasure,
                    amount,
                    width,
                    height,
                    length
                }, { new: true }).exec()
            }

            return res.status(200).json(product);
        }
        catch (e) {
            console.log('Error update product', e)
            return res.status(304).json('Error update the product' + e);
        }
    },

    async destroy(req, res) {
        try {

            const { _id } = req.params

            let product = await Product.findByIdAndUpdate(_id, {
                exclud: true
            }, { new: true }).exec()

            return res.status(200).json(product);


        }
        catch (e) {
            console.log('Error destroy product', e)
            return res.status(304).json('Error delete the product' + e);
        }
    },
}