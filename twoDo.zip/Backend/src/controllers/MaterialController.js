const Material = require('../models/Material');
const User = require('../models/User');

module.exports = {
    async index(req, res) {
        try {
            let material = await Material.find({ exclud: false }).exec();
            return res.status(200).json(material);

        }
        catch (e) {
            console.log('Error index material', e)
            return res.status(404).json('Error index material' + e);
        }
    },

    async show(req, res) {
        try {

            const { _id } = req.params

            let material = await Material.findOne({ _id }).exec();
            return res.status(200).json(material);

        }
        catch (e) {
            console.log('Error show material', e)
            return res.status(404).json('Error show the material' + e);
        }
    },

    async store(req, res) {
        try {

            const { title, unitMeasure, amount, width, height, length } = req.body;
            // const { user_id } = req.headers;
           
            // // Save only if user logged
            // const user = await User.findById(user_id);

            // if (!user) {
            //     return res.status(404).json({ erro: 'User does not exists' });
            // }

            const material = await Material.create({
               // user: user_id,
                title,
                unitMeasure,
                amount,
                width,
                height,
                length
            })

            return res.status(200).json(material);

        }
        catch (e) {
            console.log('Error store material', e)
            return res.status(400).json('Error create the material' + e);
        }
    },

    async update(req, res) {
        try {
           
            const { title, unitMeasure, amount, width, height, length } = req.body;
            const { _id } = req.params;

            const material = await Material.findByIdAndUpdate(_id, {
                //user: user_id,
                title,
                unitMeasure,
                amount,
                width,
                height,
                length
            }, { new: true }).exec()

            return res.status(200).json(material);
        }
        catch (e) {
            console.log('Error update material', e)
            return res.status(304).json('Error update the material' + e);
        }
    },

    async destroy(req, res) {
        try {

            const { _id } = req.params

            const material = await Material.findByIdAndUpdate(_id, {
                exclud: true
            }, { new: true }).exec()

                return res.status(200).json(material);
            

        }
        catch (e) {
            console.log('Error destroy material', e)
            return res.status(304).json('Error delete the material' + e);
        }
    },
}