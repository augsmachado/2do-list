const Order = require('../models/Order');
const User = require('../models/User');
const Client = require('../models/Client');
const OrderHistoric = require('../models/OrderHistoric');

module.exports = {
    async index(req, res) {
        try {
            let order = await Order.find({ exclud: false }).populate('product').populate('orderHistoric').populate('thumbnail').populate('embroidery').
                populate('client').exec();
            return res.status(200).json(order);

        }
        catch (e) {
            console.log('Error index order status', e)
            return res.status(404).json('Error index order status' + e);
        }
    },

    async show(req, res) {
        try {
            const { _id } = req.params

            let order = await Order.findOne({ _id }).populate('product').populate('orderHistoric').populate('thumbnail').populate('embroidery').
                populate('client').exec();
            return res.status(200).json(order);

        }
        catch (e) {
            console.log('Error show order', e)
            return res.status(404).json('Error show the order' + e);
        }
    },

    async store(req, res) {
        try {
            const { user } = req.headers;
            const { client,
                orderHistoric,
                product,
                thumbnail,
                embroidery,
                deliveryDate,
                amount,
                orderValue,
                width,
                height,
                length,
                description,
                unitMeasure,
                title
            } = req.body;

            let order = await Order.create({
                client: client,
                product: product,
                thumbnail: thumbnail,
                embroidery: embroidery,
                deliveryDate,
                amount,
                orderValue,
                width,
                height,
                length,
                description,
                unitMeasure,
                title
            })

            const history = await OrderHistoric.create({ status: 'Aguardando Pagamento', order: order._id })
            console.log(history)

            order = await Order.findByIdAndUpdate(order._id, {
                orderHistoric: history._id,
            }, { new: true }).exec()


            return res.status(200).json(order);

        }
        catch (e) {
            console.log('Error store order', e)
            return res.status(400).json('Error create the order' + e);
        }
    },

    async update(req, res) {
        try {
            const { user } = req.headers;
            const { _id } = req.params
            const {
                product,
                thumbnail,
                embroidery,
                deliveryDate,
                amount,
                width,
                height,
                length,
                description,
                unitMeasure,
                title
            } = req.body;

            const order = await Order.findByIdAndUpdate(_id, {
                product: product,
                thumbnail: thumbnail,
                embroidery: embroidery,
                deliveryDate: deliveryDate,
                amount: amount,
                width: width,
                height: height,
                length: length,
                description: description,
                unitMeasure: unitMeasure,
                title: title
            }, { new: true }).exec()

            return res.status(200).json(order);
        }
        catch (e) {
            console.log('Error update order', e)
            return res.status(304).json('Error update the order' + e);
        }
    },

    async updateStatus(req, res) {
        try {
            const { _id } = req.params
            const {
                status
            } = req.body;

            let aux = await OrderHistoric.find({ order: _id }).exec()
            console.log('here', aux)
            const order = await OrderHistoric.findByIdAndUpdate(aux[0]._id, { status: status }, { new: true }).exec()
            console.log('here2', order)
            return res.status(200).json(order);
        }
        catch (e) {
            console.log('Error orderHistoric in the order', e)
            return res.status(304).json('Error orderHistoric in the order' + e);
        }
    },

    async destroy(req, res) {
        try {
            const { _id } = req.params
            const order = await Order.findByIdAndUpdate(_id, {
                exclud: true
            }, { new: true }).exec()

            return res.status(200).json(order);

        }
        catch (e) {
            console.log('Error destroy product', e)
            return res.status(304).json('Error delete the product' + e);
        }
    },
}