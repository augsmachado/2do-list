const User = require('../models/User');
const bcrypt = require('bcrypt');

const saltRounds = 10;

module.exports = {
    async login(req, res) {
        try {
            const { email, password } = req.body
            let user = await User.findOne({ email }).exec();

            await bcrypt.compare(password, user.password, async (err, result) => {
                console.log(result)
                if (result) {
                    user = { _id: user._id, username: user.username, email: user.email, role: user.role }

                    res.status(200).json(user);

                }
                else {
                    return res.status(404).json("This user doesn't exist or e-mail or password are wrong");
                }
            });
        }
        catch (e) {
            console.log('error login', e)
            return res.json('error login' + e);
        }
    },
    async index(req, res) {
        try {
            let user = await User.find({ exclud: false }).exec();
            return res.status(200).json(user.map(user => { return ({ _id: user.id, username: user.username, email: user.email, role: user.role }) }));

        }
        catch (e) {
            console.log('Error index user', e)
            return res.status(404).json('Error index user' + e);
        }
    },

    async show(req, res) {
        try {

            const { _id } = req.params

            let user = await User.findOne({ _id }).exec();
            return res.status(200).json({ _id: user.id, username: user.username, email: user.email, role: user.role });

        }
        catch (e) {
            console.log('Error show user', e)
            return res.status(404).json('Error show the user' + e);
        }
    },

    async store(req, res) {
        try {
            const { username, password, email, role } = req.body;

            let user = await User.find({ email, username }).exec();
            if (!user) {
                bcrypt.hash(password, saltRounds, async (err, hash) => {
                    let user = await User.create({
                        username: username,
                        password: hash,
                        email: email,
                        role: role
                    });

                    return res.json({ _id: user._id, name: user.name, email: user.email });
                });
            }
            else {
                return res.json('user already registred');
            }
        }
        catch (e) {
            console.log('error store user', e)
            return res.json('error create the user' + e);
        }
    },

    async resetPassword(req, res) {
        try {

            const { username, email, password } = req.body

            let user = await User.find({ email, username }).exec();
            console.log(user, username, email)
            if (user.length > 0) {
                bcrypt.hash(password, saltRounds, async (err, hash) => {
                    user = await User.findOneAndUpdate(user._id, {
                        password: hash,
                    }, { new: true }).exec();
                    return res.status(200).json({ _id: user._id, username: user.username, email: user.email });
                })
            }
            else {
                return res.status(404).json({status: 404,  error:"usuario não encontrado"});
            }



        }
        catch (e) {
            console.log('error update user', e)
            return res.json('error update the user' + e);
        }
    },

    async update(req, res) {
        try {

            const { _id } = req.params
            const { username, email, password, role } = req.body
            let user
            if (password) {
                bcrypt.hash(password, saltRounds, async (err, hash) => {
                    user = await User.findOneAndUpdate(_id, {
                        username: username,
                        password: hash,
                        email: email,
                        role: role
                    }, { new: true }).exec();
                })
            }
            else {
                user = await User.findOneAndUpdate(_id, { username, email, role }, { new: true }).exec()
            }

            return res.status(200).json({ _id: user._id, username: user.username, email: user.email, role: user.role });

        }
        catch (e) {
            console.log('error update user', e)
            return res.json('error update the user' + e);
        }
    },

    async destroy(req, res) {
        try {
            const { _id } = req.params

            let user = await User.findOneAndUpdate(_id, { exclud: true }, { new: true }).exec()

            return res.json(user);

        }
        catch (e) {
            console.log('error destroy user', e)
            return res.json('error delete the user' + e);
        }
    }
}