const Client = require('../models/Client');

module.exports = {
    async index(req, res) {
        try {
            let client = await Client.find({exclud: false}).exec();
            return res.status(200).json(client);

        }
        catch (e) {
            console.log('Error index client', e)
            return res.status(404).json('Error index client' + e);
        }
    },
    async show(req, res) {
        try {

            const { _id } = req.params

            let client = await Client.findOne({ _id }).exec();
            return res.status(200).json(client);

        }
        catch (e) {
            console.log('Error show client', e)
            return res.status(404).json('Error show the client' + e);
        }
    },
    async store(req, res) {
        try {

            const { fullName, phone, cpf, address, birthDate } = req.body;
            const lastBirthDate = null
            let client = await Client.findOne({ cpf });

            if (!client) {
                client = await Client.create({ fullName, cpf, address, phone, birthDate, lastBirthDate });

                return res.status(201).json(client);
            }

            return res.status(409).json(client);
        }
        catch (e) {
            console.log('Error store client', e)
            return res.status(400).json('Error create the client' + e);
        }
    },

    async update(req, res) {
        try {
            const { fullName, phone, address, birthDate, lastBirthDate } = req.body;
            const { _id } = req.params
          
            let client = await Client.findByIdAndUpdate(_id, { fullName, address, phone, birthDate, lastBirthDate }, {new: true}).exec();

            return res.status(200).json(client);
        
        }
        catch (e) {
            console.log('Error update client', e)
            return res.status(304).json('Error update the client' + e);
        }
    },

    async updateBirth(req, res) {
        try {
            
            const { _id } = req.params

            let client = await Client.findById({ _id });
            const lastBirthDate = client.birthDate
            console.log(client)
            if (client) {
                client = await Client.findByIdAndUpdate({_id}, {lastBirthDate}).exec();
                return res.status(200).json(client);
            }
            
            return res.status(404).json(client);
        }
        catch (e) {
            console.log('Error update client', e)
            return res.status(304).json('Error update the client' + e);
        }
    },

    async destroy(req, res) {
        try {

            const { fullName, phone, address, birthDate, lastBirthDate } = req.body;
            const { _id } = req.params
          
            let client = await Client.findByIdAndUpdate(_id, { exclud: true }, {new: true}).exec();

            return res.status(200).json(client);
        }
        catch (e) {
            console.log('Error destroy client', e)
            return res.status(304).json('Error delete the client' + e);
        }
    },
    async birthDay(req, res) {
        try {
            let clis = await Client.find().exec();
            let date = new Date();
            date.setHours(0, 0, 0, 0)
            date.setYear(0)

            clis = clis.filter(t => {
                let date2 = new Date(Date.parse(t.birthDate));
                let date3 = new Date(Date.parse(t.lastBirthDate));
                date2.setYear(0);
                date2.setHours(0, 0, 0, 0)
                date2.setDate(date2.getDate() + 1)

                date3.setYear(0);
                date3.setHours(0, 0, 0, 0)
                date3.setDate(date3.getDate() + 1)

                if ((date2.valueOf() == date.valueOf()) && (date3.valueOf() != date.valueOf())) {
                    return t
                }
            })
            if (clis.length == 0) {
                clis = 'Não há aniversariantes para hoje'
            }
            return res.status(200).json(clis);

        }
        catch (e) {
            console.log('Error get Birthdays', e)
            return res.status(404).json('Error get Burthdays' + e);
        }
    }
}

