const OrderHistoric = require('../models/OrderHistoric');
const Order = require('../models/Order');

module.exports = {
    async index(req, res) {
        try {
            let orderHistoric = await OrderHistoric.find().exec();
            return res.status(200).json(orderHistoric);

        }
        catch (e) {
            console.log('Error index order status', e)
            return res.status(404).json('Error index order status' + e);
        }
    },

    async show(req, res) {
        try {

            const { _id } = req.params

            let orderHistoric = await OrderHistoric.findOne({ _id }).exec();
            return res.status(200).json(orderHistoric);

        }
        catch (e) {
            console.log('Error show order status', e)
            return res.status(404).json('Error show the order status' + e);
        }
    },

    async store(req, res) {
        try {
            const { status, date, order } = req.body;

            const orderHistoric = await OrderHistoric.create({
                order: order,
                status,
                date
            })

            return res.status(200).json(orderHistoric);

        }
        catch (e) {
            console.log('Error store order historic', e)
            return res.status(400).json('Error create the order historic' + e);
        }
    },

    async update(req, res) {
        try {
            const { status, date, order } = req.body;

            const orderHistoric = await OrderHistoric.updateOne({
                order: order,
                status,
                date
            }).exec()

            return res.status(200).json(orderHistoric);
        }
        catch (e) {
            console.log('Error update order status', e)
            return res.status(304).json('Error update the order status' + e);
        }
    },
}