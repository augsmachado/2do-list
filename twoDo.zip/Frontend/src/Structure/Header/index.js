import React, { useState } from 'react';
import {
  Collapse,
  Navbar,
  NavbarToggler,
  NavbarBrand,
  Nav,
  NavItem,
  NavLink,
  UncontrolledDropdown,
  DropdownToggle,
  DropdownMenu,
  DropdownItem,
  Modal,
  Row,
  Col,
  ModalHeader,
  ModalBody,
  ModalFooter,
} from 'reactstrap';
import Swal from "sweetalert2";
import './index.css';
import 'bootstrap/dist/css/bootstrap.min.css';

import api from '../../services/api';

const Home = (props) => {
  const [isOpen, setIsOpen] = useState(false);


  const [username, setUsername] = useState(false);

  //Modal Setings Edit
  const [editModal,
    setEditModal] = useState(false);
  const editToggle = state => setEditModal(state);
  const editToggleHeader = () => setEditModal(!editModal);

  const toggle = () => setIsOpen(!isOpen);
  let manager = ''
  if (sessionStorage.getItem('id').split(',')[2] == 'Admin') {
    manager = <DropdownItem href='usuarios'>
      Gerenciar Usuarios
  </DropdownItem>
  }

  const [confirmPassword,
    setConfirmPassword] = useState(undefined);


  // Model Variables
  const [model, setModel] = useState({ _id: undefined, email: undefined, username: undefined, password: undefined, role: 'Cliente' });


  async function getInformation(id) {

    const response = await api.get("/users/" + id);
    console.log(response)
    if (response.data) {
      setModel(response.data)
      return true
    }
    else {
      Swal.fire(
        "Oops...",
        "Erro ao buscar buscar as informações do registro",
        "error"
      );
      return false
    }
  }

  async function update() {
    try {
      if (!model.username || !model.email || !model.role) {
        Swal.fire(
          "Oops...",
          "Por favor, preencha todos os campos obrigatórios.",
          "info"
        );
      }
      if (model.password) {
        if (model.password != confirmPassword) {
          Swal.fire(
            "Oops...",
            "As Senhas digitadas não correspondem ",
            "warning"
          );
        }
        else {
          // disable the button to await the save
          document.getElementById('btnAlterar').disabled = true
          document.getElementById('btnAlterar').innerHTML = "Salvando..."

          const response = await api.put("/users/" + model._id, model)
          if (response.data) {
            await Swal.fire(
              "success!",
              "Salvo com sucesso!",
              "success"
            )
            editToggle(false)
            console.log(response.data)
            setUsername(response.data.username)
          }
          else {
            await Swal.fire(
              "Oops...",
              "Error ao tentar salvar.",
              "error"
            );
            document.getElementById('btnAlterar').disabled = false
            document.getElementById('btnAlterar').innerHTML = "Salvar"
          }
        }
      }
      else {
        // disable the button to await the save
        document.getElementById('btnAlterar').disabled = true
        document.getElementById('btnAlterar').innerHTML = "Salvando..."

        const response = await api.put("/users/" +  model._id, model)
        if (response.data) {
          await Swal.fire(
            "success!",
            "Salvo com sucesso!",
            "success"
          )
          editToggle(false)
          console.log(response.data)
          setUsername(response.data.username)
        }
        else {
          await Swal.fire(
            "Oops...",
            "Error ao tentar salvar.",
            "error"
          );
          document.getElementById('btnAlterar').disabled = false
          document.getElementById('btnAlterar').innerHTML = "Salvar"
        }
      }
    }
    catch (e) {
      Swal.fire(
        "Oops...",
        "Erro ao tentar Salvar",
        "info"
      );
    }
  }

  let name = ''
  if(!username){
    name = sessionStorage.getItem('id').split(',')[1]
  }
  else{
    name = username
  }

  return (
    <div >
      <Modal
        className={'modalNew modal-md'}
        isOpen={editModal}
        toggle={editToggleHeader}>
        <ModalHeader toggle={editToggleHeader}>Editar Usuario</ModalHeader>
        <ModalBody className="content">
          <Row className="lineComponent">
            <Col sm="12">
              <label className="label">Nome
                        <b style={{
                  color: 'red'
                }}>*</b>
              </label>
              <input
                type="text"
                className="form-control "
                value={model.username}
                onChange={event => setModel({ _id: model.id, username: event.target.value, email: model.email, password: model.password, role: model.role })} />
            </Col>
            <Col sm="12">
              <label className="label">E-mail
                        <b style={{
                  color: 'red'
                }}>*</b>
              </label>
              <input
                type="email"
                className="form-control "
                value={model.email}
                onChange={event => setModel({ _id: model.id, username: model.username, email: event.target.value, password: model.password, role: model.role })} />
            </Col>
          </Row>
          <Row className="lineComponent">
            <Col sm="6">
              <label className="label">Senha
                        <b style={{
                  color: 'red'
                }}>*</b>
              </label>
              <input
                type="password"
                className="form-control "
                value={model.password}
                onKeyUp={(event) => {
                  if (event.target.value) {
                    if (event.target.value.length > 0) {
                      document.getElementById('confirm').style.display = 'inline'
                    }
                    else {
                      document.getElementById('confirm').style.display = 'none'
                    }
                  }
                  else {
                    document.getElementById('confirm').style.display = 'none'
                  }
                }}
                onChange={event => {
                  setModel({ _id: model.id, username: model.username, email: model.email, password: event.target.value, role: model.role })
                }} />
            </Col>
            <Col sm="6">
              <div id='confirm'>
                <label className="label">Confirmação senha
                        <b style={{
                    color: 'red'
                  }}>*</b>
                </label>
                <input
                  type="password"
                  className="form-control "
                  value={confirmPassword}
                  onChange={event => setConfirmPassword(event.target.value)} />
              </div>
            </Col>
          </Row>
          <ModalFooter className='modalfooter'>
            <button id="btnAlterar"
              onClick={() => { update() }}
              className="btn btn-primary btnModal">
              Salvar
                </button>{" "}
            <button
              id="btnsave"
              className="btn btn-secondary btnModal"
              onClick={() => editToggle(false)}>
              Cancelar
                </button>
          </ModalFooter>
        </ModalBody>
      </Modal>

      <Navbar className='header' light expand="md">
        <NavbarBrand className='headerName' href="#home">2Do - System</NavbarBrand>
        <NavbarToggler onClick={toggle} />
        <Collapse isOpen={isOpen} navbar>
          <Nav className="mr-auto" navbar>
            <NavItem >
              <NavLink className='headerLink' href="/dashboard">Dashboard</NavLink>
            </NavItem>
            <NavItem >
              <NavLink className='headerLink' href="/clientes">Clientes</NavLink>
            </NavItem>
            <NavItem >
              <NavLink className='headerLink' href="/bordados">Bordados</NavLink>
            </NavItem>
            <NavItem >
              <NavLink className='headerLink' href="/estampas">Estampas</NavLink>
            </NavItem>
            <NavItem >
              <NavLink className='headerLink' href="/materiais">Materiais</NavLink>
            </NavItem>
            <NavItem >
              <NavLink className='headerLink' href="/produtos">Produtos</NavLink>
            </NavItem>
            <NavItem >
              <NavLink className='headerLink' href="/pedidos">Pedidos</NavLink>
            </NavItem>
            <NavItem >
              <NavLink className='headerLink' href="/aniversariantes">Aniversariantes</NavLink>
            </NavItem>
          </Nav>
          <UncontrolledDropdown nav inNavbar>
            <DropdownToggle className='headerNameLogado' nav caret>
              {name}
            </DropdownToggle>
            <DropdownMenu right>
              <DropdownItem onClick={() => { sessionStorage.clear(); window.location.href = "/" }} >
                Logout
                </DropdownItem>
              {manager}
              <DropdownItem onClick={() => {getInformation(sessionStorage.getItem('id').split(',')[0]); setConfirmPassword(undefined) ;editToggle(true) }}>
                Minha conta
                </DropdownItem>
            </DropdownMenu>
          </UncontrolledDropdown>
        </Collapse>
      </Navbar>
    </div>
  );
}

export default Home;
