import React from 'react';

import './App.css';

import Routes from './routes';
import Header from './Structure/Header/index';

export default class App extends React.Component {
  constructor(props) {
    super(props);

    this.state = {};

  }

  render() {
    let url = document.URL.split('/')[document.URL.split('/').length - 1]
    if ((url == '/' || url == '') || !sessionStorage.getItem('id')) {
      return (
        <>
          <Routes />
        </>
      );
    }
    else {
      return (
        <>
          <Header />
          <Routes />
        </>
      );
    }
  }
}

