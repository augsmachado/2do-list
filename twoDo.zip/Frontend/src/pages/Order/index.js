import React, { useEffect, useState, useMemo } from "react";
import { IconContext } from "react-icons";
import { FaCamera } from "react-icons/fa";
import Select from 'react-select';
import {
  Modal,
  Row,
  Container,
  Col, FormGroup, Label, Input,
  ModalHeader,
  ModalBody,
  ModalFooter,
} from 'reactstrap';

import Swal from "sweetalert2";
import BootstrapTable from "react-bootstrap-table-next";
import ToolkitProvider, { Search } from "react-bootstrap-table2-toolkit";
import paginationFactory from "react-bootstrap-table2-paginator";
import ReactTooltip from 'react-tooltip'
import { FaPencilAlt, FaTrashAlt } from "react-icons/fa";
import LoadingOverlay from 'react-loading-overlay';

import './index.css'
import "react-bootstrap-table-next/dist/react-bootstrap-table2.min.css";
import "semantic-ui-css/semantic.min.css";
import "bootstrap/dist/css/bootstrap.css";
import api from '../../services/api';

const images = require.context('../../../../2Do_backend/uploads', true)

const Products = props => {
  // Photo Previw Setings
  const [img, setImg] = useState(null);
  const [checked,
    setChecked] = useState({ cm: false, m: false })

  const [isActive,
    setIsActive] = useState(true);


  const [checkedOrder,
    setCheckedOrder] = useState({ cm: false, m: false })

  const [thumbnail, setThumbnail] = useState(null);
  const preview = useMemo(() => {
    return thumbnail ? URL.createObjectURL(thumbnail) : null;
  }, [thumbnail]);

  //Grids Config
  const { SearchBar } = Search;
  // pagination option
  const customTotal = (from, to, size) => (
    <span className="react-bootstrap-table-pagination-total">
      Mostrando {from + " "}
            até {to + " "}
            de {size + " "}
            Resultados
    </span>
  );
  const options = {
    paginationSize: 6,
    pageStartIndex: 1,
    alwaysShowAllBtns: true, // Always show next and previous button
    // withFirstAndLast: false, // Hide the going to First and Last page button
    hideSizePerPage: true, // Hide the sizePerPage dropdown always
    // hidePageListOnlyOnePage: true, // Hide the pagination list when only one page
    firstPageText: "Primeira",
    prePageText: "Anterior",
    nextPageText: "Próxima",
    lastPageText: "Última",
    nextPageTitle: "Primeira página",
    prePageTitle: "Pre página",
    firstPageTitle: "Póxima página",
    lastPageTitle: "Última página",
    showTotal: true,
    paginationTotalRenderer: customTotal
  };

  //Tale Config
  const columns = [
    {
      dataField: "title",
      text: "Título",
      classes: "tableContent"
    }, {
      dataField: "amount",
      text: "Quantidade",
      classes: "tableContent",
    },
    {
      dataField: "status",
      text: "Status",
      classes: "tableContent",
    },
    {
      dataField: "client",
      text: "Cliente",
      classes: "tableContent",
    },
    {
      dataField: "deliveryDate",
      text: "Data de entrega",
      classes: "tableContent",
    },
    {
      dataField: "options",
      text: "Opções"
    }
  ];

  //Modal Setings New
  const [newModal,
    setNewModal] = useState(false);
  const newToggle = state => setNewModal(state);
  const newToggleHeader = () => setNewModal(!newModal);

  //Modal Setings Edit
  const [editModal,
    setEditModal] = useState(false);
  const editToggle = state => setEditModal(state);
  const editToggleHeader = () => setEditModal(!editModal);

  //table rows load
  let auxData = [];
  const [data,
    setData] = useState([]);

  //select Options
  const [productOptions,
    setProductOptions] = useState([{}]);

  const [thumbnailsOptions,
    setThumbnailsOptions] = useState([{}]);

  const [embroideryOptions,
    setEmbroideryOptions] = useState([{}]);

  const [clientOptions,
    setClientOptions] = useState([{}]);

  let today = new Date();
  let dd = parseInt(String(today.getDate()).padStart(2, '0'));
  let mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
  let yyyy = today.getFullYear();

  today = yyyy + '-' + mm + '-' + dd;

  // Model Variables
  const [model, setModel] = useState({
    id: undefined,
    description: '',
    title: undefined,
    amount: 1,
    height: 0,
    width: 0,
    stats: undefined,
    length: 0,
    unitMeasure: undefined,
    orderValue: 0,
    deliveryDate: today,
    user: undefined,
    orderHistoric: undefined,
    client: undefined,
    product: undefined,
    thumbnail: undefined,
    embroidery: undefined
  });

  const [product, setProduct] = useState({ id: undefined, description: '', title: undefined, photo: undefined, unitMeasure: undefined, height: 0, width: 0, length: 0 });
  const [embroidery, setEmbroidery] = useState({ id: undefined, title: undefined, photo: undefined, description: '' });
  const [modelThumbnail, setModelThumbnail] = useState({ id: undefined, title: undefined, photo: undefined, description: '' });
  const [client, setClient] = useState({ id: undefined, fullName: undefined, birthDate: '', phone: undefined, address: undefined, cpf: undefined });

  const [productModal,
    setProductModal] = useState(false);
  const productModalToggle = state => setProductModal(state);
  const productModalToggleHeader = () => setProductModal(!productModal);

  const [embroideryModal,
    setEmbroideryModal] = useState(false);
  const embroiderytModalToggle = state => setEmbroideryModal(state);
  const embroideryModalToggleHeader = () => setEmbroideryModal(!embroideryModal);

  const [thumbnailModal,
    setThumbnailModal] = useState(false);
  const thumbnailModalToggle = state => setThumbnailModal(state);
  const thumbnailModalToggleHeader = () => setThumbnailModal(!thumbnailModal);

  const [visible,
    setVisible] = useState(true);

  useEffect(() => {
    loadPage();
    getItens()
  }, []);

  async function loadPage() {
    const response = await api.get('/orders')
    console.log(response)
    auxData = [];
    if (response.data) {
      response.data.forEach(register => {

        auxData.push({
          title: register.title,
          amount: register.amount,
          status: register.orderHistoric.status,
          client: register.client.fullName,
          deliveryDate: register.deliveryDate.split('T')[0].substr(0, 10).split('-').reverse().join('/'),
          options: [
            <div className="options" > <button
              id={register._id}
              data-tip="Editar"
              type="button"
              onClick={(event) => getInformation('order', event.currentTarget.getAttribute("id"))}
              className="btn btnEdit"
            >
              <ReactTooltip place="top" type="dark" effect="solid" />
              <FaPencilAlt />
            </button>
              < button
                id={register._id}
                data-tip="Excluir" type="button" className="btn btnDelete" onClick={
                  event => {
                    remove(event.currentTarget.getAttribute("id"))
                  }
                } > <FaTrashAlt /> </button>
            </div >]
        })
      })
    }

    // load the lines of the table
    setData(auxData.map(t => t));
    setIsActive(false)
  }

  async function getItens() {
    const products = await api.get('/products')
    const thumbnails = await api.get('/thumbnails')
    const embroideries = await api.get('/embroideries')
    const clients = await api.get('/clients')

    console.log(products, thumbnails, embroideries, clients)
    if (clients.data) {
      auxData = [];
      clients.data.forEach(register => {
        auxData.push({
          value: register._id,
          label: register.fullName
        })
      })
      setClientOptions(auxData.map(t => t))
    }
    if (products.data) {
      auxData = [];
      auxData.push({ value: undefined, label: "Nenhum" })

      products.data.forEach(register => {
        auxData.push({
          value: register._id,
          label: register.title
        })
      })
      setProductOptions(auxData.map(t => t))
    }
    if (thumbnails.data) {
      auxData = [];
      auxData.push({ value: undefined, label: "Nenhum" })

      thumbnails.data.forEach(register => {
        auxData.push({
          value: register._id,
          label: register.title
        })
      })
      setThumbnailsOptions(auxData.map(t => t))
    }
    if (embroideries.data) {
      auxData = [];
      auxData.push({ value: undefined, label: "Nenhum" })

      embroideries.data.forEach(register => {
        auxData.push({
          value: register._id,
          label: register.title
        })
      })
      setEmbroideryOptions(auxData.map(t => t))
    }
  }

  async function getInformation(model, id) {
    if (model == 'produto') {
      try {
        const response = await api.get("/products/" + id);
        console.log(response)
        if (response.data) {
          setProduct(response.data)
          setImg(<img className='thumbnailEditProduct' src={images('./' + response.data.photo)} />)
          if (response.data.unitMeasure == 'cm') {
            setChecked({ cm: true, m: false })
          }
          else {
            setChecked({ cm: false, m: true })
          }

          setProduct(response.data)

          setVisible(false)
        }
      }
      catch (e) {
        setProduct({ _id: undefined })
      }
    }
    else if (model == 'bordado') {
      try {
        const response = await api.get("/embroideries/" + id);
        console.log(response)
        if (response.data) {
          setEmbroidery(response.data)
          setImg(<img className='thumbnailEdit' src={images('./' + response.data.photo)} />)

          setVisible(false)
        }
      }
      catch (e) {
        setEmbroidery({ _id: undefined })
      }
    }
    else if (model == 'estampa') {
      try {
        const response = await api.get("/thumbnails/" + id);
        console.log(response)
        if (response.data) {
          setModelThumbnail(response.data)
          setImg(<img className='thumbnailEdit' src={images('./' + response.data.photo)} />)

          setVisible(false)
        }
      }
      catch (e) {
        setModelThumbnail({ _id: undefined })
      }
    }
    else if (model == 'client') {
      const response = await api.get("/clients/" + id);
      console.log(response)
      if (response.data) {
        setClient(response.data)
      }
    }
    else if (model == 'order') {

      const response = await api.get("/orders/" + id);
      console.log(response)
      if (response.data) {
        let date = response.data.deliveryDate.split('T')[0]
        delete response.data['deliveryDate']
        setModel({ deliveryDate: date, ...response.data, id: id })

        if (response.data.thumbnail)
          setModelThumbnail(response.data.thumbnail)
        if (response.data.product)
          setProduct(response.data.product)
        if (response.data.embroidery)
          setEmbroidery(response.data.embroidery)

        setClient(response.data.client)

        if (response.data.unitMeasure == 'cm') {
          setCheckedOrder({ cm: true, m: false })
        }
        else {
          setCheckedOrder({ cm: false, m: true })
        }

        editToggle(true)
      }
    }
  }

  async function create() {
    try {
      if (!model.title || !model.description || !client._id || !model.unitMeasure || !model.orderValue > 0) {
        Swal.fire(
          "Oops...",
          "Por favor, preencha todos os campos obrigatórios.",
          "info"
        );
      }
      else {
        // disable the button to await the save
        document.getElementById('btnSave').disabled = true
        document.getElementById('btnSave').innerHTML = "Salvando..."

        let data = {
          description: model.description,
          title: model.title,
          amount: model.amount,
          height: model.height.toString().replace(/,/g, '.'),
          width: model.width.toString().replace(/,/g, '.'),
          length: model.length.toString().replace(/,/g, '.'),
          unitMeasure: model.unitMeasure,
          orderValue: model.orderValue.toString().replace(/,/g, '.'),
          deliveryDate: model.deliveryDate,
          orderHistoric: undefined,
          client: client._id,
          product: product._id,
          thumbnail: modelThumbnail._id,
          embroidery: embroidery._id
        };

        console.log(data)

        const response = await api.post("/orders", data)

        if (response.data) {
          await Swal.fire(
            "success!",
            "Salvo com sucesso!",
            "success"
          )
          loadPage();
          newToggle(false);

          document.getElementById('btnSave').disabled = false
          document.getElementById('btnSave').innerHTML = "Salvar"
        }
        else {
          await Swal.fire(
            "Oops...",
            "Error ao tentar salvar.",
            "error"
          );
          document.getElementById('btnAlterar').disabled = false
          document.getElementById('btnSave').innerHTML = "Salvar"
        }
      }
    }
    catch (e) {
      await Swal.fire(
        "Oops...",
        "Error ao tentar salvar.",
        "error"
      );
    }

  }

  async function update() {
    try {
      if (!model.title || !model.description || !client._id || !model.unitMeasure || !model.orderValue > 0) {
        Swal.fire(
          "Oops...",
          "Por favor, preencha todos os campos obrigatórios.",
          "info"
        );
      }
      else {
        // disable the button to await the save
        document.getElementById('btnAlterar').disabled = true
        document.getElementById('btnAlterar').innerHTML = "Salvando..."

        let data = {
          _id: model._id,
          description: model.description,
          title: model.title,
          amount: model.amount.toString().replace(/,/g, '.'),
          height: model.height.toString().replace(/,/g, '.'),
          width: model.width.toString().replace(/,/g, '.'),
          length: model.length.toString().replace(/,/g, '.'),
          unitMeasure: model.unitMeasure,
          orderValue: model.orderValue.toString().replace(/,/g, '.'),
          deliveryDate: model.deliveryDate,
          product: product._id,
          thumbnail: modelThumbnail._id,
          embroidery: embroidery._id
        };

        const response = await api.put("/orders/" + model._id, data)

        if (response.data) {
          await Swal.fire(
            "success!",
            "Salvo com sucesso!",
            "success"
          )
          loadPage();
          editToggle(false);

          document.getElementById('btnAlterar').disabled = false
          document.getElementById('btnAlterar').innerHTML = "Salvar"
        }
        else {
          await Swal.fire(
            "Oops...",
            "Error ao tentar salvar.",
            "error"
          );
          document.getElementById('btnAlterar').disabled = false
          document.getElementById('btnSave').innerHTML = "Salvar"
        }
      }
    }
    catch (e) {
      await Swal.fire(
        "Oops...",
        "Error ao tentar salvar.",
        "error"
      );
    }
  }

  async function remove(id) {
    Swal.fire({
      title: 'Atenção',
      icon: 'warning',
      html:
        'Não será possivel desfazer um registro excluido. \n Deseja prosseguir?',
      showCancelButton: true,
      focusConfirm: false,
      confirmButtonText:
        'Sim',
      cancelButtonText:
        'Cancelar',
    }).then(async (value) => {
      if (value.value) {

        const response = await api.delete("/orders/" + id)

        if (response.data) {
          await Swal.fire(
            "Deleted!",
            "Deletado com Sucesso!",
            "success"
          ).then(result => { if (result.value) loadPage() });
        }
        else {
          Swal.fire(
            "Oops...",
            "Erro ao tentar deletar o registro.",
            "error"
          );
        }
      }
    })

  }

  function isNumeric(evt) {
    var charCode = (evt.which) ? evt.which : evt.keyCode
    if (charCode > 31 && (charCode != 44 && (charCode < 48 || charCode > 57)))
      return false;
    return true;
  }

  function fieldValidation(event) {
    event.target.value = event.target.value.replace(/[-!$%^&*()_+|~=`{}\[\]:";'<>?.\/]| |[a-z]|[A-Z]\w+/g, '')
    if (event.target.value[0] == ',') {
      return false
    }
    let aux = event.target.value.match(/,/g || []);
    if (aux) {
      if (aux.length == 1) {
        return true
      }
    }
    else {
      if (!aux) {
        return true
      }
      event.preventDefault()
    }
  }

  function blurEvent(event) {
    if (event.target.value[event.target.value.length - 1] == ',') {
      event.target.value = event.target.value.substring(0, event.target.value.length - 1)
    }; if (event.target.value.replace(/_|0|,/g, '') == '') { event.target.value = 0 }
  }

  async function cancelOrder() {
    Swal.fire({
      title: 'Atenção',
      icon: 'warning',
      html:
        'Não será possivel reabrir o pedido. \n Deseja prosseguir?',
      showCancelButton: true,
      focusConfirm: false,
      confirmButtonText:
        'Sim',
      cancelButtonText:
        'Cancelar',
    }).then(async (value) => {
      if (value.value) {

        const response = await api.put("/ordershistory/" + model._id, { status: 'Cancelado' })
        if (response.data) {
          await Swal.fire(
            "Sucesso!",
            "Pedido cancelado com Sucesso!",
            "success"
          ).then(result => { if (result.value) { editToggle(false); loadPage() } });
        }
        else {
          Swal.fire(
            "Oops...",
            "Erro ao tentar cancelar o pedido.",
            "error"
          );
        }
      }
    })
  }

  let btnCancel
  if (model.orderHistoric) {
    if (!(model.orderHistoric.status == 'Concluído' || model.orderHistoric.status == "Cancelado")) {
      btnCancel = (<button
        onClick={() => { cancelOrder() }}
        className="btn btn-danger btnModal">
        Cancelar Pedido
      </button>)
    }
  }

  return (<>
    <Modal
      className={'modalNew modal-md'}
      isOpen={embroideryModal}
      toggle={embroideryModalToggleHeader}>
      <ModalHeader toggle={embroideryModalToggleHeader}>Detalhes do Bordado {embroidery.title}</ModalHeader>
      <ModalBody className="content">
        <Row className="lineComponent">
          <Col sm="12">
            <label className="label">Nome
                        <b style={{
                color: 'red'
              }}>*</b>
            </label>
            <input
              tabIndex={0}
              disabled={true}
              type="text"
              className="form-control "
              value={embroidery.title}
              onChange={event => setEmbroidery({ title: event.target.value, photo: embroidery.photo, description: embroidery.description })} />
          </Col>
        </Row>
        <Row className="lineComponent">
          <Col sm='6'>
            <label className="label">Foto bordado <b style={{ color: 'red' }}>*</b></label>
            <Row>
              <Col sm="9">
                <label
                  id="thumbnail"
                  style={{ backgroundImage: `url(${preview})` }}
                  className={thumbnail ? "has-thumbnail" : ""}
                >
                  {img}
                  <input
                    disabled={true}
                    type="file"
                    onChange={event => setThumbnail(event.target.files[0])}
                  />
                  <IconContext.Provider value={{ className: "icon" }}>
                    <div>
                      <FaCamera />
                    </div>
                  </IconContext.Provider>
                </label>
              </Col>

            </Row>
          </Col>
          <Col sm='6'>
            <label className="label">Descrição

                    </label>
            <textarea disabled={true} onChange={event => setEmbroidery({ title: embroidery.title, photo: embroidery.photo, description: event.target.value })} value={embroidery.description} className="form-control " rows="9" cols="50">

            </textarea>
          </Col>
        </Row>

        <ModalFooter className='modalfooter'>

          <button
            className="btn btn-secondary btnModal"
            onClick={() => embroiderytModalToggle(false)}>
            Fechar
                </button>
        </ModalFooter>
      </ModalBody>
    </Modal>

    <Modal
      className={'modalNew modal-lg'}
      isOpen={productModal}
      toggle={productModalToggleHeader}>
      <ModalHeader toggle={productModalToggleHeader}>Detalhes do Produto {product.title}</ModalHeader>
      <ModalBody className="content">
        <Row className="lineComponent">
          <Col sm="6">
            <label className="label">Nome
                        <b style={{
                color: 'red'
              }}>*</b>
            </label>
            <input
              tabIndex={0}
              type="text"
              className="form-control "
              value={product.title}
              disabled={true}
              onChange={event => setProduct({
                title: event.target.value, unitMeasure: product.unitMeasure, description: product.description,
                width: product.width, photo: product.photo, length: product.length, height: product.height
              })} />
          </Col>
          <Col sm="6">
            <label className="labelUnd">Unidade de medida
                        <b style={{
                color: 'red'
              }}>*</b>
            </label>
            <br />
            <FormGroup disabled={true} value='cm' className='unitOptions' check onChange={event => {
              setChecked({ cm: false, m: true }); setProduct({
                title: product.title, unitMeasure: event.target.value, description: product.description,
                width: product.width, photo: product.photo, length: product.length, height: product.height
              })
            }}>
              <Label check>
                <Input disabled={true} checked={checked.cm} value='cm' type="radio" name="radio1" />{' '}
                            Centimetro(s)
                        </Label>
            </FormGroup>
            <FormGroup disabled={true} value='m' className='unitOptions' check onChange={event => {
              setChecked({ cm: false, m: true }); setProduct({
                title: product.title, unitMeasure: event.target.value, description: product.description,
                width: product.width, photo: product.photo, length: product.length, height: product.height
              })
            }}>
              <Label check>
                <Input disabled={true} checked={checked.m} value='m' type="radio" name="radio1" />{' '}
                           Metro(s)
                        </Label>
            </FormGroup>
          </Col>
        </Row>
        <Row className="lineComponent">
          <Col sm='6'>
            <label className="label">Foto Produto <b style={{ color: 'red' }}>*</b></label>
            <Row>
              <Col sm="9">
                <label
                  id="thumbnailProduct"
                  style={{ backgroundImage: `url(${preview})` }}
                  className={thumbnail ? "has-thumbnail" : ""}
                >
                  {img}
                  <input
                    disabled={true}
                    type="file"
                    onChange={event => setThumbnail(event.target.files[0])}
                  />
                  <IconContext.Provider value={{ className: "icon" }}>
                    <div>
                      <FaCamera />
                    </div>
                  </IconContext.Provider>
                </label>
              </Col>

            </Row>
          </Col>
          <Col sm='6'>
            <Row>
              <Col sm="4">
                <label className="label">Comprimento</label>
                <input
                  type='text'
                  onKeyPress={(evt) => { if (!isNumeric(evt)) { evt.preventDefault() } }}
                  className="form-control"
                  onClick={(event) => { if (event.target.value == '0') { event.target.value = '' } else event.target.value = product.length }}
                  onBlur={(event) => blurEvent(event)}
                  value={product.length}
                  disabled={true}
                  onChange={event => {
                    if (fieldValidation(event)) {
                      setProduct({
                        title: product.title, unitMeasure: product.unitMeasure,
                        amount: product.amount, width: product.width, length: event.target.value, height: product.height
                      })
                    }
                  }} />
              </Col>

              <Col sm="4">
                <label className="label">Largura</label>
                <input
                  type='text'
                  onKeyPress={(evt) => { if (!isNumeric(evt)) { evt.preventDefault() } }}
                  className="form-control"
                  onClick={(event) => { if (event.target.value == '0') { event.target.value = '' } else event.target.value = product.width }}
                  onBlur={(event) => blurEvent(event)}
                  value={product.width}
                  disabled={true}
                  onChange={event => {
                    if (fieldValidation(event)) {
                      setProduct({
                        title: product.title, unitMeasure: product.unitMeasure,
                        amount: product.amount, width: event.target.value, length: product.length, height: product.height
                      })
                    }
                  }} />
              </Col>

              <Col sm="4">
                <label className="label">Altura</label>
                <input
                  type='text'
                  onKeyPress={(evt) => { if (!isNumeric(evt)) { evt.preventDefault() } }}
                  className="form-control"
                  onClick={(event) => { if (event.target.value == '0') { event.target.value = '' } else event.target.value = product.height }}
                  onBlur={(event) => blurEvent(event)}
                  value={product.height}
                  disabled={true}
                  onChange={event => {
                    if (fieldValidation(event)) {
                      setProduct({
                        title: product.title, unitMeasure: product.unitMeasure,
                        amount: product.amount, width: product.width, length: product.length, height: event.target.value
                      })
                    }
                  }} />
              </Col>
            </Row>
            <br />
            <label className="label">Descrição</label>
            <textarea disabled={true} onChange={event => setProduct({
              title: product.title, unitMeasure: product.unitMeasure, description: event.target.value,
              amount: product.amount, width: product.width, length: product.length, height: product.height
            })
            } value={product.description} className="form-control " rows="9" cols="50">

            </textarea>
          </Col>
        </Row>

        <ModalFooter className='modalfooter'>
          <button
            className="btn btn-secondary btnModal"
            onClick={() => productModalToggle(false)}>
            Fechar
                </button>
        </ModalFooter>
      </ModalBody>
    </Modal>

    <Modal
      className={'modalNew modal-md'}
      isOpen={thumbnailModal}
      toggle={thumbnailModalToggleHeader}>
      <ModalHeader toggle={thumbnailModalToggleHeader}>Detalhes da Estampa {modelThumbnail.title}</ModalHeader>
      <ModalBody className="content">
        <Row className="lineComponent">
          <Col sm="12">
            <label className="label">Nome
                        <b style={{
                color: 'red'
              }}>*</b>
            </label>
            <input
              tabIndex={0}
              disabled={true}
              type="text"
              className="form-control "
              value={modelThumbnail.title}
              onChange={event => setModelThumbnail({ title: event.target.value, photo: modelThumbnail.photo, description: modelThumbnail.description })} />
          </Col>
        </Row>
        <Row className="lineComponent">
          <Col sm='6'>
            <label className="label">Foto Estampa <b style={{ color: 'red' }}>*</b></label>
            <Row>
              <Col sm="9">
                <label
                  id="thumbnail"
                  style={{ backgroundImage: `url(${preview})` }}
                  className={thumbnail ? "has-thumbnail" : ""}
                >
                  {img}
                  <input
                    type="file"
                    disabled={true}
                    onChange={event => setThumbnail(event.target.files[0])}
                  />
                  <IconContext.Provider value={{ className: "icon" }}>
                    <div>
                      <FaCamera />
                    </div>
                  </IconContext.Provider>
                </label>
              </Col>

            </Row>
          </Col>
          <Col sm='6'>
            <label className="label">Descrição

                    </label>
            <textarea disabled={true} onChange={event => setModelThumbnail({ title: modelThumbnail.title, photo: modelThumbnail.photo, description: event.target.value })} value={modelThumbnail.description} className="form-control " rows="9" cols="50">

            </textarea>
          </Col>
        </Row>

        <ModalFooter className='modalfooter'>
          <button
            className="btn btn-secondary btnModal"
            onClick={() => thumbnailModalToggle(false)}>
            Fechar
                </button>
        </ModalFooter>
      </ModalBody>
    </Modal>

    <Modal
      visible={visible}
      className={'modalNew modal-xl'}
      isOpen={newModal}
      toggle={newToggleHeader}>
      <ModalHeader toggle={newToggleHeader}>Novo Pedido</ModalHeader>
      <ModalBody className="content">
        <Row className="lineComponent">
          <Col sm="4">
            <label className="label">Nome
                        <b style={{
                color: 'red'
              }}>*</b>
            </label>
            <input
              tabIndex={0}
              type="text"
              className="form-control "
              value={model.title}
              onChange={event => setModel({
                title: event.target.value, unitMeasure: model.unitMeasure, description: model.description,
                width: model.width, orderValue: model.orderValue, length: model.length, height: model.height,
                amount: model.amount, status: model.stats, deliveryDate: model.deliveryDate, embroidery: model.embroidery,
                thumbnail: model.thumbnail, product: model.product, orderHistoric: model.orderHistoric, client: model.client
              })} />
          </Col>
          <Col sm="4">
            <label className="labelUnd">Unidade de medida
                        <b style={{
                color: 'red'
              }}>*</b>
            </label>
            <br />
            <FormGroup value='cm' className='unitOptions' check onChange={event => setModel({
              title: model.title, unitMeasure: event.target.value, description: model.description,
              width: model.width, orderValue: model.orderValue, length: model.length, height: model.height,
              amount: model.amount, status: model.stats, deliveryDate: model.deliveryDate, embroidery: model.embroidery,
              thumbnail: model.thumbnail, product: model.product, orderHistoric: model.orderHistoric, client: model.client
            })}>
              <Label check>
                <Input value='cm' type="radio" name="radio1" />{' '}
                            Centimetro(s)
                        </Label>
            </FormGroup>
            <FormGroup value='m' className='unitOptions' check onChange={event => setModel({
              title: model.title, unitMeasure: event.target.value, description: model.description,
              width: model.width, orderValue: model.orderValue, length: model.length, height: model.height,
              amount: model.amount, status: model.stats, deliveryDate: model.deliveryDate, embroidery: model.embroidery,
              thumbnail: model.thumbnail, product: model.product, orderHistoric: model.orderHistoric, client: model.client
            })}>>
              <Label check>
                <Input value='m' type="radio" name="radio1" />{' '}
                           Metro(s)
                        </Label>
            </FormGroup>
          </Col>
          <Col sm="4" className='referencesColumn'>
            <label className="labelUnd">Produto Modelo</label>
            <div>
              <Select onChange={(event) => { getInformation('produto', event.value) }} className='options' options={productOptions} />
              <button id='moreInfoProduct'
                onClick={(event) => {
                  if (product._id) { productModalToggle(true) } else {
                    Swal.fire(
                      "Oops...",
                      "Selecione um produto antes de ver seus detalhes.",
                      "info"
                    );
                  }
                }}
                className='btn btn-primary btnMoreAbout'> + Detalhes</button>
            </div>
          </Col>
          <div class="vl"></div>
        </Row>

        <Row className="lineComponent">
          <Col sm='4'>

            <label className="label">Descrição<b style={{
              color: 'red'
            }}>*</b>
            </label>
            <textarea value={model.description} className="form-control " rows="7" cols="50" onChange={event => setModel({
              title: model.title, unitMeasure: model.unitMeasure, description: event.target.value,
              width: model.width, orderValue: model.orderValue, length: model.length, height: model.height,
              amount: model.amount, status: model.stats, deliveryDate: model.deliveryDate, embroidery: model.embroidery,
              thumbnail: model.thumbnail, product: model.product, orderHistoric: model.orderHistoric, client: model.client
            })}>
            </textarea>
          </Col>

          <Col sm='4'>
            <Row>
              <Col sm="4">
                <label className="label">Comprimento</label>
                <input
                  type='text'
                  onKeyPress={(evt) => { if (!isNumeric(evt)) { evt.preventDefault() } }}
                  className="form-control"
                  onClick={(event) => { if (event.target.value == '0') { event.target.value = '' } else event.target.value = model.length }}
                  onBlur={(event) => blurEvent(event)}
                  value={model.length}
                  onChange={event => {
                    if (fieldValidation(event)) {
                      setModel({
                        title: model.title, unitMeasure: model.unitMeasure, description: model.description,
                        width: model.width, orderValue: model.orderValue, length: event.target.value, height: model.height,
                        amount: model.amount, status: model.stats, deliveryDate: model.deliveryDate, embroidery: model.embroidery,
                        thumbnail: model.thumbnail, product: model.product, orderHistoric: model.orderHistoric, client: model.client
                      })
                    }
                  }} />
              </Col>
              <Col sm="4">
                <label className="label">Largura</label>
                <input
                  type='text'
                  onKeyPress={(evt) => { if (!isNumeric(evt)) { evt.preventDefault() } }}
                  className="form-control"
                  onClick={(event) => { if (event.target.value == '0') { event.target.value = '' } else event.target.value = model.width }}
                  onBlur={(event) => blurEvent(event)}
                  value={model.width}
                  onChange={event => {
                    if (fieldValidation(event)) {
                      setModel({
                        title: model.title, unitMeasure: model.unitMeasure, description: model.description,
                        width: event.target.value, orderValue: model.orderValue, length: model.length, height: model.height,
                        amount: model.amount, status: model.stats, deliveryDate: model.deliveryDate, embroidery: model.embroidery,
                        thumbnail: model.thumbnail, product: model.product, orderHistoric: model.orderHistoric, client: model.client
                      })
                    }
                  }} />
              </Col>
              <Col sm="4">
                <label className="label">Altura</label>
                <input
                  type='text'
                  onKeyPress={(evt) => { if (!isNumeric(evt)) { evt.preventDefault() } }}
                  className="form-control"
                  onClick={(event) => { if (event.target.value == '0') { event.target.value = '' } else event.target.value = model.height }}
                  onBlur={(event) => blurEvent(event)}
                  value={model.height}
                  onChange={event => {
                    if (fieldValidation(event)) {
                      setModel({
                        title: model.title, unitMeasure: model.unitMeasure, description: model.description,
                        width: model.width, orderValue: model.orderValue, length: model.length, height: event.target.value,
                        amount: model.amount, status: model.stats, deliveryDate: model.deliveryDate, embroidery: model.embroidery,
                        thumbnail: model.thumbnail, product: model.product, orderHistoric: model.orderHistoric, client: model.client
                      })
                    }
                  }} />
              </Col>
            </Row>
          </Col>
          <Col sm="4" className='referencesColumn'>
            <label className="labelUnd">Estampa Modelo</label>
            <div>
              <Select onChange={(event) => { getInformation("estampa", event.value) }} className='options' options={thumbnailsOptions} />
              <button id='moreInfoThumb' onClick={(event) => {
                if (modelThumbnail._id) { thumbnailModalToggle(true) } else {
                  Swal.fire(
                    "Oops...",
                    "Selecione uma estampa antes de ver seus detalhes.",
                    "info"
                  );
                }
              }} className='btn btn-primary btnMoreAbout'> + Detalhes</button>
            </div>
          </Col>
        </Row>
        <div class="v2"></div>
        <Row>
          <div class="v3"></div>
          <Row className='offset-4 part2Middle'>
            <Col sm='6'>
              <Row>
                <Col sm='6'>
                  <label className="label">Valor
                        <b style={{
                      color: 'red'
                    }}>*</b>
                  </label>
                  <input
                    type='text'
                    onKeyPress={(evt) => { if (!isNumeric(evt)) { evt.preventDefault() } }}
                    className="form-control"
                    onClick={(event) => { if (event.target.value == '0') { event.target.value = '' } else event.target.value = model.orderValue }}
                    onBlur={(event) => blurEvent(event)}
                    value={model.orderValue}
                    onChange={event => {
                      if (fieldValidation(event)) {
                        setModel({
                          title: model.title, unitMeasure: model.unitMeasure, description: model.description,
                          width: model.width, orderValue: event.target.value, length: model.length, height: model.height,
                          amount: model.amount, status: model.stats, deliveryDate: model.deliveryDate, embroidery: model.embroidery,
                          thumbnail: model.thumbnail, product: model.product, orderHistoric: model.orderHistoric, client: model.client
                        })
                      }
                    }} />
                </Col>
                <Col sm='6'>
                  <label className="label">Quantidade
                        <b style={{
                      color: 'red'
                    }}>*</b>
                  </label>
                  <input
                    type='text'
                    onKeyPress={(evt) => { var charCode = (evt.which) ? evt.which : evt.keyCode; if ((charCode < 48 || charCode > 57)) { evt.preventDefault() } }}
                    className="form-control"
                    onClick={(event) => { if (event.target.value == '0') { event.target.value = '' } else event.target.value = model.amount }}
                    onBlur={(event) => blurEvent(event)}
                    value={model.amount}
                    onChange={event => {
                      if (fieldValidation(event)) {
                        setModel({
                          title: model.title, unitMeasure: model.unitMeasure, description: model.description,
                          width: model.width, orderValue: model.orderValue, length: model.length, height: model.height,
                          amount: event.target.value, status: model.stats, deliveryDate: model.deliveryDate, embroidery: model.embroidery,
                          thumbnail: model.thumbnail, product: model.product, orderHistoric: model.orderHistoric, client: model.client
                        })
                      }
                    }} />
                </Col>
              </Row>
            </Col>
          </Row>
          <Col className='offset-4' sm="4">
            <label className="label">Data de Entrega
                        <b style={{
                color: 'red'
              }}>*</b>
            </label>
            <Input
              type="date"
              name="date"
              value={model.deliveryDate}
              onChange={(event) => {
                if (new Date(event.target.value).valueOf() < Date.now().valueOf()) {
                  Swal.fire(
                    "Oops...",
                    "Data invalida",
                    "info"
                  );
                  event.preventDefault()
                }
                else {
                  setModel({
                    title: model.title, unitMeasure: model.unitMeasure, description: model.description,
                    width: model.width, orderValue: model.orderValue, length: model.length, height: model.height,
                    amount: model.amount, status: model.stats, deliveryDate: event.target.value, embroidery: model.embroidery,
                    thumbnail: model.thumbnail, product: model.product, orderHistoric: model.orderHistoric, client: model.client
                  })
                }
              }}
              placeholder=""
            />

          </Col>
          <Col sm='4'>
            <div className='last'>
              <label className="labelUnd">Bordado Modelo</label>
              <Select onChange={(event) => { getInformation("bordado", event.value) }} className='options' options={embroideryOptions} />
              <button id='moreInfoEnbroidery' onClick={(event) => {
                if (embroidery._id) { embroiderytModalToggle(true) } else {
                  Swal.fire(
                    "Oops...",
                    "Selecione um bordado antes de ver seus detalhes.",
                    "info"
                  );
                }
              }} className='btn btn-primary btnMoreAbout'> + Detalhes</button>
            </div>
          </Col>
          <Col sm='4'>
            <br /><br />
            <div className='last'>
              <label className="labelUnd">Cliente<b style={{
                color: 'red'
              }}>*</b></label>
              <Select onChange={(event) => { getInformation('client', event.value) }} className='options' options={clientOptions} />
            </div>
          </Col>
        </Row>

        <ModalFooter className='modalfooter'>
          <button id="btnSave"
            onClick={() => { create() }}
            className="btn btn-primary btnModal">
            Salvar
                </button>{" "}
          <button
            className="btn btn-secondary btnModal"
            onClick={() => newToggle(false)}>
            Cancelar
                </button>
        </ModalFooter>
      </ModalBody>
    </Modal>

    <Modal
      visible={visible}
      className={'modalNew modal-xl'}
      isOpen={editModal}
      toggle={editToggleHeader}>
      <ModalHeader toggle={editToggleHeader}>Editar Pedido</ModalHeader>
      <ModalBody className="content">
        <Row className="lineComponent">
          <Col sm="4">
            <label className="label">Nome
                        <b style={{
                color: 'red'
              }}>*</b>
            </label>
            <input
              type="text"
              className="form-control "
              value={model.title}
              onChange={event => setModel({
                _id: model._id,
                title: event.target.value, unitMeasure: model.unitMeasure, description: model.description,
                width: model.width, orderValue: model.orderValue, length: model.length, height: model.height,
                amount: model.amount, status: model.stats, deliveryDate: model.deliveryDate, embroidery: model.embroidery,
                thumbnail: model.thumbnail, product: model.product, orderHistoric: model.orderHistoric, client: model.client
              })} />
          </Col>
          <Col sm="4">
            <label className="labelUnd">Unidade de medida
                        <b style={{
                color: 'red'
              }}>*</b>
            </label>
            <br />
            <FormGroup value='cm' className='unitOptions' check onChange={event => {
              setCheckedOrder({ cm: true, m: false });
              setModel({
                _id: model._id, id: model.id,
                title: model.title, unitMeasure: event.target.value, description: model.description,
                width: model.width, orderValue: model.orderValue, length: model.length, height: model.height,
                amount: model.amount, status: model.stats, deliveryDate: model.deliveryDate, embroidery: model.embroidery,
                thumbnail: model.thumbnail, product: model.product, orderHistoric: model.orderHistoric, client: model.client
              })
            }}>
              <Label check>
                <Input checked={checkedOrder.cm} value='cm' type="radio" name="radio1" />{' '}
                            Centimetro(s)
                        </Label>
            </FormGroup>
            <FormGroup value='m' className='unitOptions' check onChange={event => {
              setCheckedOrder({ cm: false, m: true });
              setModel({
                _id: model._id, id: model.id,
                title: model.title, unitMeasure: event.target.value, description: model.description,
                width: model.width, orderValue: model.orderValue, length: model.length, height: model.height,
                amount: model.amount, status: model.stats, deliveryDate: model.deliveryDate, embroidery: model.embroidery,
                thumbnail: model.thumbnail, product: model.product, orderHistoric: model.orderHistoric, client: model.client
              })
            }}>>
              <Label check>
                <Input value='m' checked={checkedOrder.m} type="radio" name="radio1" />{' '}
                           Metro(s)
                        </Label>
            </FormGroup>
          </Col>
          <Col sm="4" className='referencesColumn'>
            <label className="labelUnd">Produto Modelo</label>
            <div>
              <Select value={{ label: product.title, value: product._id }} onChange={(event) => { getInformation('produto', event.value) }} className='options' options={productOptions} />
              <button id='moreInfoProduct'
                onClick={(event) => {
                  if (product._id) { productModalToggle(true) } else {
                    Swal.fire(
                      "Oops...",
                      "Selecione um produto antes de ver seus detalhes.",
                      "info"
                    );
                  }
                }}
                className='btn btn-primary btnMoreAbout'> + Detalhes</button>
            </div>
          </Col>
          <div class="vl"></div>
        </Row>

        <Row className="lineComponent">
          <Col sm='4'>

            <label className="label">Descrição<b style={{
              color: 'red'
            }}>*</b>
            </label>
            <textarea value={model.description} className="form-control " rows="7" cols="50" onChange={event => setModel({
              title: model.title, unitMeasure: model.unitMeasure, description: event.target.value,
              _id: model._id, id: model.id,
              width: model.width, orderValue: model.orderValue, length: model.length, height: model.height,
              amount: model.amount, status: model.stats, deliveryDate: model.deliveryDate, embroidery: model.embroidery,
              thumbnail: model.thumbnail, product: model.product, orderHistoric: model.orderHistoric, client: model.client
            })}>
            </textarea>
          </Col>

          <Col sm='4'>
            <Row>
              <Col sm="4">
                <label className="label">Comprimento</label>
                <input
                  type='text'
                  onKeyPress={(evt) => { if (!isNumeric(evt)) { evt.preventDefault() } }}
                  className="form-control"
                  onClick={(event) => { if (event.target.value == '0') { event.target.value = '' } else event.target.value = model.length }}
                  onBlur={(event) => blurEvent(event)}
                  value={model.length}
                  onChange={event => {
                    if (fieldValidation(event)) {
                      setModel({
                        _id: model._id, id: model.id,
                        title: model.title, unitMeasure: model.unitMeasure, description: model.description,
                        width: model.width, orderValue: model.orderValue, length: event.target.value, height: model.height,
                        amount: model.amount, status: model.stats, deliveryDate: model.deliveryDate, embroidery: model.embroidery,
                        thumbnail: model.thumbnail, product: model.product, orderHistoric: model.orderHistoric, client: model.client
                      })
                    }
                  }} />
              </Col>
              <Col sm="4">
                <label className="label">Largura</label>
                <input
                  type='text'
                  onKeyPress={(evt) => { if (!isNumeric(evt)) { evt.preventDefault() } }}
                  className="form-control"
                  onClick={(event) => { if (event.target.value == '0') { event.target.value = '' } else event.target.value = model.width }}
                  onBlur={(event) => blurEvent(event)}
                  value={model.width}
                  onChange={event => {
                    if (fieldValidation(event)) {
                      setModel({
                        _id: model._id, id: model.id,
                        title: model.title, unitMeasure: model.unitMeasure, description: model.description,
                        width: event.target.value, orderValue: model.orderValue, length: model.length, height: model.height,
                        amount: model.amount, status: model.stats, deliveryDate: model.deliveryDate, embroidery: model.embroidery,
                        thumbnail: model.thumbnail, product: model.product, orderHistoric: model.orderHistoric, client: model.client
                      })
                    }
                  }} />
              </Col>
              <Col sm="4">
                <label className="label">Altura</label>
                <input
                  type='text'
                  onKeyPress={(evt) => { if (!isNumeric(evt)) { evt.preventDefault() } }}
                  className="form-control"
                  onClick={(event) => { if (event.target.value == '0') { event.target.value = '' } else event.target.value = model.height }}
                  onBlur={(event) => blurEvent(event)}
                  value={model.height}
                  onChange={event => {
                    if (fieldValidation(event)) {
                      setModel({
                        _id: model._id, id: model.id,
                        title: model.title, unitMeasure: model.unitMeasure, description: model.description,
                        width: model.width, orderValue: model.orderValue, length: model.length, height: event.target.value,
                        amount: model.amount, status: model.stats, deliveryDate: model.deliveryDate, embroidery: model.embroidery,
                        thumbnail: model.thumbnail, product: model.product, orderHistoric: model.orderHistoric, client: model.client
                      })
                    }
                  }} />
              </Col>
            </Row>
          </Col>
          <Col sm="4" className='referencesColumn'>
            <label className="labelUnd">Estampa Modelo</label>
            <div>
              <Select value={{ label: modelThumbnail.title, value: modelThumbnail._id }} onChange={(event) => { getInformation("estampa", event.value) }} className='options' options={thumbnailsOptions} />
              <button id='moreInfoThumb' onClick={(event) => {
                if (modelThumbnail._id) { thumbnailModalToggle(true) } else {
                  Swal.fire(
                    "Oops...",
                    "Selecione uma estampa antes de ver seus detalhes.",
                    "info"
                  );
                }
              }} className='btn btn-primary btnMoreAbout'> + Detalhes</button>
            </div>
          </Col>
        </Row>
        <div class="v2"></div>
        <Row>
          <div class="v3"></div>
          <Row className='offset-4 part2Middle'>
            <Col sm='6'>
              <Row>
                <Col sm='6'>
                  <label className="label">Valor
                        <b style={{
                      color: 'red'
                    }}>*</b>
                  </label>
                  <input
                    disabled={true}
                    type='text'
                    onKeyPress={(evt) => { if (!isNumeric(evt)) { evt.preventDefault() } }}
                    className="form-control"
                    onClick={(event) => { if (event.target.value == '0') { event.target.value = '' } else event.target.value = model.orderValue }}
                    onBlur={(event) => blurEvent(event)}
                    value={model.orderValue}
                    onChange={event => {
                      if (fieldValidation(event)) {
                        setModel({
                          _id: model._id, id: model.id,
                          title: model.title, unitMeasure: model.unitMeasure, description: model.description,
                          width: model.width, orderValue: event.target.value, length: model.length, height: model.height,
                          amount: model.amount, status: model.stats, deliveryDate: model.deliveryDate, embroidery: model.embroidery,
                          thumbnail: model.thumbnail, product: model.product, orderHistoric: model.orderHistoric, client: model.client
                        })
                      }
                    }} />
                </Col>
                <Col sm='6'>
                  <label className="label">Quantidade
                        <b style={{
                      color: 'red'
                    }}>*</b>
                  </label>
                  <input
                    disabled={true}
                    type='text'
                    onKeyPress={(evt) => { var charCode = (evt.which) ? evt.which : evt.keyCode; if ((charCode > 31 && (charCode < 48 || charCode > 57))) { evt.preventDefault() } }}
                    className="form-control"
                    onClick={(event) => { if (event.target.value == '0') { event.target.value = '' } else event.target.value = model.amount }}
                    onBlur={(event) => blurEvent(event)}
                    value={model.amount}
                    onChange={event => {
                      if (fieldValidation(event)) {
                        setModel({
                          _id: model._id, id: model.id,
                          title: model.title, unitMeasure: model.unitMeasure, description: model.description,
                          width: model.width, orderValue: model.orderValue, length: model.length, height: model.height,
                          amount: event.target.value, status: model.stats, deliveryDate: model.deliveryDate, embroidery: model.embroidery,
                          thumbnail: model.thumbnail, product: model.product, orderHistoric: model.orderHistoric, client: model.client
                        })
                      }
                    }} />
                </Col>
              </Row>
            </Col>
          </Row>
          <Col className='offset-4' sm="4">
            <label className="label">Data de Entrega
                        <b style={{
                color: 'red'
              }}>*</b>
            </label>
            <Input
              type="date"
              name="date"
              value={model.deliveryDate}
              onChange={(event) => {
                if (new Date(event.target.value).valueOf() < Date.now().valueOf()) {
                  Swal.fire(
                    "Oops...",
                    "Data invalida",
                    "info"
                  );
                  event.preventDefault()
                }
                else {
                  setModel({
                    _id: model._id, id: model.id,
                    title: model.title, unitMeasure: model.unitMeasure, description: model.description,
                    width: model.width, orderValue: model.orderValue, length: model.length, height: model.height,
                    amount: model.amount, status: model.stats, deliveryDate: event.target.value, embroidery: model.embroidery,
                    thumbnail: model.thumbnail, product: model.product, orderHistoric: model.orderHistoric, client: model.client
                  })
                }
              }}
              placeholder=""
            />

          </Col>
          <Col sm='4'>
            <div className='last'>
              <label className="labelUnd">Bordado Modelo</label>
              <Select value={{ label: embroidery.title, value: embroidery._id }} onChange={(event) => { getInformation("bordado", event.value) }} className='options' options={embroideryOptions} />
              <button id='moreInfoEnbroidery' onClick={(event) => {
                if (embroidery._id) { embroiderytModalToggle(true) } else {
                  Swal.fire(
                    "Oops...",
                    "Selecione um bordado antes de ver seus detalhes.",
                    "info"
                  );
                }
              }} className='btn btn-primary btnMoreAbout'> + Detalhes</button>
            </div>
          </Col>
          <Col sm='4'>
            <br /><br />
            <div className='last'>
              <label className="labelUnd">Cliente<b style={{
                color: 'red'
              }}>*</b></label>
              <Select value={{ label: client.fullName, value: '' }} isDisabled={true} onChange={(event) => { getInformation('client', event.value) }} className='options' />
            </div>
          </Col>
        </Row>

        <ModalFooter className='modalfooter'>
          {btnCancel}

          <button id="btnAlterar"
            onClick={() => { update() }}
            className="btn btn-primary btnModal">
            Salvar
                </button>{" "}
          <button
            className="btn btn-secondary btnModal"
            onClick={() => editToggle(false)}>
            Cancelar
                </button>
        </ModalFooter>
      </ModalBody>
    </Modal>

    <Container className="tablePage" fluid > <ToolkitProvider keyField="name" data={data} columns={columns} search>
      {props => {
        return (
          <div>
            <button onClick={() => {
              setModel({
                id: undefined,
                description: '',
                title: undefined,
                amount: 1,
                height: 0,
                width: 0,
                stats: undefined,
                length: 0,
                unitMeasure: undefined,
                orderValue: 0,
                deliveryDate: today,
                user: undefined,
                orderHistoric: undefined,
                client: undefined,
                product: undefined,
                thumbnail: undefined,
                embroidery: undefined
              });

              setProduct({ id: undefined, description: '', title: undefined, photo: undefined, unitMeasure: undefined, height: 0, width: 0, length: 0 });
              setEmbroidery({ id: undefined, title: undefined, photo: undefined, description: '' });
              setModelThumbnail({ id: undefined, title: undefined, photo: undefined, description: '' });
              setClient({ id: undefined, fullName: undefined, birthDate: '', phone: undefined, address: undefined, cpf: undefined });

              newToggle(true)
            }} className="btnNew btn btn-primary">
              Novo Pedido
                    </button>
            <div className="searchBar">
              <label className="labelSearch">Buscar:</label>
              <SearchBar {...props.searchProps} />
            </div>
            <div className="table">
              <LoadingOverlay
                active={isActive}
                spinner
                text='Carregando...'
              ></LoadingOverlay>
              <BootstrapTable
                {...props.baseProps}
                striped
                hover
                condensed
                pagination={paginationFactory(options)} />
            </div>
          </div>
        )
      }}
    </ToolkitProvider> </Container>
  </>);
}
export default React.memo(Products);