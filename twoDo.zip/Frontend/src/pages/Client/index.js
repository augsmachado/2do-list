import React, { useEffect, useState } from "react";
import InputMask from "react-input-mask";
import {
    Modal,
    Row,
    Container,
    Col,
    ModalHeader,
    ModalBody,
    Input,
    ModalFooter,
} from 'reactstrap';
import Swal from "sweetalert2";
import BootstrapTable from "react-bootstrap-table-next";
import ToolkitProvider, { Search } from "react-bootstrap-table2-toolkit";
import paginationFactory from "react-bootstrap-table2-paginator";
import ReactTooltip from 'react-tooltip'
import { FaPencilAlt, FaTrashAlt } from "react-icons/fa";
// import Select from "react-select";
import LoadingOverlay from 'react-loading-overlay';
import './index.css'
import "react-bootstrap-table-next/dist/react-bootstrap-table2.min.css";
import "semantic-ui-css/semantic.min.css";
import "bootstrap/dist/css/bootstrap.css";
import api from '../../services/api';

const Client = props => {
    //Grids Config
    const { SearchBar } = Search;
    // pagination option
    const customTotal = (from, to, size) => (
        <span className="react-bootstrap-table-pagination-total">
            Mostrando {from + " "}
            até {to + " "}
            de {size + " "}
            Resultados
        </span>
    );
    const options = {
        paginationSize: 6,
        pageStartIndex: 1,
        alwaysShowAllBtns: true, // Always show next and previous button
        // withFirstAndLast: false, // Hide the going to First and Last page button
        hideSizePerPage: true, // Hide the sizePerPage dropdown always
        // hidePageListOnlyOnePage: true, // Hide the pagination list when only one page
        firstPageText: "Primeira",
        prePageText: "Anterior",
        nextPageText: "Próxima",
        lastPageText: "Última",
        nextPageTitle: "Primeira página",
        prePageTitle: "Pre página",
        firstPageTitle: "Póxima página",
        lastPageTitle: "Última página",
        showTotal: true,
        paginationTotalRenderer: customTotal
    };

    //Tale Config
    const columns = [
        {
            dataField: "fullName",
            text: "Nome",
            classes: "tableContent"
        }, {
            dataField: "address",
            text: "Endereço",
            classes: "tableContent"
        }, {
            dataField: "phone",
            text: "Telefone",
            classes: "tableContent"
        }, {
            dataField: "options",
            text: "Opções"
        }
    ];

    //Modal Setings New
    const [newModal,
        setNewModal] = useState(false);
    const newToggle = state => setNewModal(state);
    const newToggleHeader = () => setNewModal(!newModal);

    //Modal Setings Edit
    const [editModal,
        setEditModal] = useState(false);
    const editToggle = state => setEditModal(state);
    const editToggleHeader = () => setEditModal(!editModal);

    //table rows load
    let auxData = [];
    const [data,
        setData] = useState([]);

    const [isActive,
        setIsActive] = useState(true);

    // Model Variables
    const [model, setModel] = useState({ id: undefined, fullName: undefined, birthDate: '', phone: undefined, address: undefined, cpf: undefined });

    useEffect(() => {
        loadPage();
    }, []);

    async function loadPage() {
        const response = await api.get('/clients')
        console.log(response)
        auxData = [];
        if (response.data) {
            response.data.forEach(register => {
                console.log(register)
                auxData.push({
                    fullName: register.fullName,
                    address: register.address,
                    phone: register.phone,
                    options: [
                        <div className="options" > <button
                            id={register._id}
                            data-tip="Editar"
                            type="button"
                            onClick={(event) => { if (getInformation(event.currentTarget.getAttribute("id"))) { editToggle(true) } }}
                            className="btn btnEdit"
                        >
                            <ReactTooltip place="top" type="dark" effect="solid" />
                            <FaPencilAlt />
                        </button>
                            < button
                                id={register._id}
                                data-tip="Excluir" type="button" className="btn btnDelete" onClick={
                                    event => { remove(event.currentTarget.getAttribute("id")) }
                                } > <FaTrashAlt /> </button>
                        </div >]
                })
            })
        }
        // load the lines of the table
        setData(auxData.map(t => t));
        setIsActive(false)
    }

    async function getInformation(id) {

        const response = await api.get("/clients/" + id);
        console.log(response)
        if (response.data) {
            console.log(response.data)
            setModel(response.data)
            return true
        }
        else {
            Swal.fire(
                "Oops...",
                "Erro ao buscar buscar as informações do registro",
                "error"
            );
            return false
        }
    }

    async function remove(id) {
        Swal.fire({
            title: 'Atenção',
            icon: 'warning',
            html:
                'Não será possivel desfazer um registro excluido. \n Deseja prosseguir?',
            showCancelButton: true,
            focusConfirm: false,
            confirmButtonText:
                'Sim',
            cancelButtonText:
                'Cancelar',
        }).then(async (value) => {
            if (value.value) {

                const response = await api.delete("clients/" + id)

                if (response.data) {
                    await Swal.fire(
                        "Deleted!",
                        "Deletado com Sucesso!",
                        "success"
                    ).then(result => { if (result.value) loadPage() });
                }
                else {
                    Swal.fire(
                        "Oops...",
                        "Erro ao tentar deletar o registro.",
                        "error"
                    );
                }
            }
        })

    }

    function valdiadteCpf(cpf) {
        cpf = cpf.replace(/[-!$%^&*()_+|~=`{}\[\]:";'<>?,.\/]/g, '')
        var numeros, digitos, soma, i, resultado, digitos_iguais;
        digitos_iguais = 1;
        if (cpf.length < 11)
            return false;
        for (i = 0; i < cpf.length - 1; i++)
            if (cpf.charAt(i) != cpf.charAt(i + 1)) {
                digitos_iguais = 0;
                break;
            }
        if (!digitos_iguais) {
            numeros = cpf.substring(0, 9);
            digitos = cpf.substring(9);
            soma = 0;
            for (i = 10; i > 1; i--)
                soma += numeros.charAt(10 - i) * i;
            resultado = soma % 11 < 2 ? 0 : 11 - soma % 11;
            if (resultado != digitos.charAt(0))
                return false;
            numeros = cpf.substring(0, 10);
            soma = 0;
            for (i = 11; i > 1; i--)
                soma += numeros.charAt(11 - i) * i;
            resultado = soma % 11 < 2 ? 0 : 11 - soma % 11;
            if (resultado != digitos.charAt(1))
                return false;
            return true;
        }
        else
            return false;
    }

    async function create() {
        try {
            if (!model.fullName || !model.phone || !model.address || !model.birthDate || !model.cpf) {
                Swal.fire(
                    "Oops...",
                    "Por favor, preencha todos os campos obrigatórios.",
                    "info"
                );
            }
            else {
                if (!valdiadteCpf(model.cpf)) {
                    Swal.fire(
                        "Oops...",
                        "Por favor, preencha o CPF corretamente.",
                        "info"
                    );
                }
                else {
                    // disable the button to await the save
                    document.getElementById('btnSaveProject').disabled = true
                    document.getElementById('btnSaveProject').innerHTML = "Salvando..."

                    const response = await api.post("/clients", model)
                    if (response.data) {
                        await Swal.fire(
                            "success!",
                            "Salvo com sucesso!",
                            "success"
                        )
                        newToggle(false)
                        loadPage();
                    }
                    else {
                        await Swal.fire(
                            "Oops...",
                            "Error ao tentar salvar.",
                            "error"
                        );
                        document.getElementById('btnAlterar').disabled = false
                        document.getElementById('btnSave').innerHTML = "Salvar"
                    }
                }
            }
        }
        catch (e) {
            Swal.fire(
                "Oops...",
                "CPF já cadastrado",
                "info"
            );
        }
    }

    async function update() {
        try {
            if (!model.fullName || !model.phone || !model.address || !model.birthDate || !model.cpf) {
                Swal.fire(
                    "Oops...",
                    "Por favor, preencha todos os campos obrigatórios.",
                    "info"
                );
            }
            else {
                if (!valdiadteCpf(model.cpf)) {
                    Swal.fire(
                        "Oops...",
                        "Por favor, preencha o CPF corretamente.",
                        "info"
                    );
                }
                else {
                    // disable the button to await the save
                    document.getElementById('btnAlterar').disabled = true
                    document.getElementById('btnAlterar').innerHTML = "Salvando..."
                    console.log(model)
                    const response = await api.put("/clients/" + model._id, model)
                    if (response.data) {
                        await Swal.fire(
                            "success!",
                            "Salvo com sucesso!",
                            "success"
                        )
                        editToggle(false)
                        loadPage();
                    }
                    else {
                        await Swal.fire(
                            "Oops...",
                            "Error ao tentar salvar.",
                            "error"
                        );
                        document.getElementById('btnAlterar').disabled = false
                        document.getElementById('btnAlterar').innerHTML = "Salvar"
                    }
                }
            }
        }
        catch (e) {
            Swal.fire(
                "Oops...",
                "Erro ao tentar Salvar",
                "info"
            );
        }
    }

    return (<>
        <Modal
            className={'modalNew modal-md'}
            isOpen={newModal}
            toggle={newToggleHeader}>
            <ModalHeader toggle={newToggleHeader}>Novo Cliente</ModalHeader>
            <ModalBody className="content">
                <Row className="lineComponent">
                    <Col sm="6">
                        <label className="label">Nome
                        <b style={{
                                color: 'red'
                            }}>*</b>
                        </label>
                        <input
                            tabIndex={0}
                            type="text"
                            className="form-control "
                            value={model.fullName}
                            onChange={event => setModel({ fullName: event.target.value, birthDate: model.birthDate, phone: model.phone, address: model.address, cpf: model.cpf })} />
                    </Col>
                    <Col sm="6">
                        <label className="label">CPF
                        <b style={{
                                color: 'red'
                            }}>*</b>
                        </label>
                        <InputMask mask="999.999.999-99" value={model.cpf} className="form-control "
                            onChange={event => setModel({ fullName: model.fullName, birthDate: model.birthDate, phone: model.phone, address: model.address, cpf: event.target.value })} />
                    </Col>
                </Row>
                <Row className="lineComponent">
                    <Col sm="12">
                        <label className="label">Endereço
                        <b style={{
                                color: 'red'
                            }}>*</b>
                        </label>
                        <input
                            type="text"
                            className="form-control"
                            value={model.address}
                            onChange={event => setModel({ fullName: model.fullName, birthDate: model.birthDate, phone: model.phone, address: event.target.value, cpf: model.cpf })} />
                    </Col>
                </Row>
                <Row className="lineComponent">
                    <Col sm="6">
                        <label className="label">Telefone
                        <b style={{
                                color: 'red'
                            }}>*</b>
                        </label>
                        <InputMask mask="(99) 99999-9999"
                            className="form-control "
                            value={model.phone}
                            onChange={event => setModel({ fullName: model.fullName, birthDate: model.birthDate, phone: event.target.value, address: model.address, cpf: model.cpf })} />
                    </Col>
                    <Col sm="6">
                        <label className="label">Data de Nascimento
                        <b style={{
                                color: 'red'
                            }}>*</b>
                        </label>
                        <Input
                            type="date"
                            value={model.birthDate}
                            name="date"
                            onChange={event => {
                                if (new Date(event.target.value).valueOf() > Date.now().valueOf()) {
                                    Swal.fire(
                                        "Oops...",
                                        "Data invalida",
                                        "info"
                                    );
                                    event.preventDefault()
                                }
                                else {
                                    setModel({ fullName: model.fullName, phone: model.phone, birthDate: event.target.value, address: model.address, cpf: model.cpf })
                                }
                            }} />

                    </Col>
                </Row>
                <ModalFooter className='modalfooter'>
                    <button id="btnSaveProject"
                        onClick={() => { create() }}
                        className="btn btn-primary btnModal">
                        Salvar
                </button>{" "}
                    <button
                        id="btnsave"
                        className="btn btn-secondary btnModal"
                        onClick={() => newToggle(false)}>
                        Cancelar
                </button>
                </ModalFooter>
            </ModalBody>
        </Modal>

        <Modal
            className={'modalNew modal-md'}
            isOpen={editModal}
            toggle={editToggleHeader}>
            <ModalHeader toggle={editToggleHeader}>Alterando dados do Cliente {model.name}</ModalHeader>
            <ModalBody className="content">
                <Row className="lineComponent">
                    <Col sm="6">
                        <label className="label">Nome
                        <b style={{
                                color: 'red'
                            }}>*</b>
                        </label>
                        <input
                            tabIndex={0}
                            type="text"
                            className="form-control "
                            value={model.fullName}
                            onChange={event => setModel({ _id: model._id, fullName: event.target.value, birthDate: model.birthDate, phone: model.phone, address: model.address, cpf: model.cpf })} />
                    </Col>
                    <Col sm="6">
                        <label className="label">CPF
                        <b style={{
                                color: 'red'
                            }}>*</b>
                        </label>
                        <InputMask mask="999.999.999-99" value={model.cpf} className="form-control "
                            onChange={event => setModel({ _id: model._id, fullName: model.fullName, birthDate: model.birthDate, phone: model.phone, address: model.address, cpf: event.target.value })} />
                    </Col>
                </Row>
                <Row className="lineComponent">
                    <Col sm="12">
                        <label className="label">Endereço
                        <b style={{
                                color: 'red'
                            }}>*</b>
                        </label>
                        <input
                            type="text"
                            className="form-control"
                            value={model.address}
                            onChange={event => setModel({ _id: model._id, fullName: model.fullName, birthDate: model.birthDate, phone: model.phone, address: event.target.value, cpf: model.cpf })} />
                    </Col>
                </Row>
                <Row className="lineComponent">
                    <Col sm="6">
                        <label className="label">Telefone
                        <b style={{
                                color: 'red'
                            }}>*</b>
                        </label>
                        <InputMask mask="(99) 99999-9999"
                            className="form-control "
                            value={model.phone}
                            onChange={event => setModel({ _id: model._id, fullName: model.fullName, birthDate: model.birthDate, phone: event.target.value, address: model.address, cpf: model.cpf })} />
                    </Col>
                    <Col sm="6">
                        <label className="label">Data de Nascimento
                        <b style={{
                                color: 'red'
                            }}>*</b>
                        </label>
                        <Input
                            type="date"
                            name="date"
                            value={model.birthDate.split('T')[0]}
                            onChange={event => {
                                if (new Date(event.target.value).valueOf() > Date.now().valueOf()) {
                                    Swal.fire(
                                        "Oops...",
                                        "Data invalida",
                                        "info"
                                    );
                                    event.preventDefault()
                                }
                                else {
                                    setModel({ _id: model._id, fullName: model.fullName, phone: model.phone, birthDate: event.target.value, address: model.address, cpf: model.cpf })
                                }
                            }} />

                    </Col>
                </Row>
                <ModalFooter className='modalfooter'>
                    <button
                        id="btnAlterar"
                        onClick={() => { update() }}
                        className="btn btn-primary btnModal">
                        Salvar alterações
                </button>{" "}
                    <button
                        className="btn btn-secondary btnModal"
                        onClick={() => editToggle(false)}>
                        Cancelar
                </button>
                </ModalFooter>
            </ModalBody>
        </Modal>

        < Container className="tablePage" fluid >
            <ToolkitProvider keyField="name" data={data} columns={columns} search>
                {props => {
                    return (
                        <div>
                            <button onClick={() => { setModel({ fullName: undefined, phone: undefined, birthDate: '', address: undefined, cpf: undefined }); newToggle(true) }} className="btnNew btn btn-primary">
                                Novo Cliente
                    </button>
                            <div className="searchBar">
                                <label className="labelSearch">Buscar:</label>
                                <SearchBar {...props.searchProps} />
                            </div>

                            <div className="table">
                                <LoadingOverlay
                                    active={isActive}
                                    spinner
                                    text='Carregando...'
                                ></LoadingOverlay>
                                <BootstrapTable
                                    {...props.baseProps}
                                    striped
                                    hover
                                    condensed
                                    pagination={paginationFactory(options)} />
                            </div>
                        </div>
                    )
                }}
            </ToolkitProvider>
        </Container>
    </>)
        ;
}
export default React.memo(Client);