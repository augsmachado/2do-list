import React, { useEffect, useState, useMemo } from "react";
import { IconContext } from "react-icons";
import { FaCamera } from "react-icons/fa";
import {
  Modal,
  Row,
  Container,
  Col,
  ModalHeader,
  ModalBody,
  ModalFooter,
} from 'reactstrap';
import LoadingOverlay from 'react-loading-overlay';
import Swal from "sweetalert2";
import BootstrapTable from "react-bootstrap-table-next";
import ToolkitProvider, { Search } from "react-bootstrap-table2-toolkit";
import paginationFactory from "react-bootstrap-table2-paginator";
import ReactTooltip from 'react-tooltip'
import { FaPencilAlt, FaTrashAlt } from "react-icons/fa";
// import Select from "react-select";

import './index.css'
import "react-bootstrap-table-next/dist/react-bootstrap-table2.min.css";
import "semantic-ui-css/semantic.min.css";
import "bootstrap/dist/css/bootstrap.css";
import api from '../../services/api';

const images = require.context('../../../../2Do_backend/uploads', true)

const Thumbnail = props => {
  // Photo Previw Setings
  const [img, setImg] = useState(null);
  const [thumbnail, setThumbnail] = useState(null);
  const preview = useMemo(() => {
    return thumbnail ? URL.createObjectURL(thumbnail) : null;
  }, [thumbnail]);

  //Grids Config
  const { SearchBar } = Search;
  // pagination option
  const customTotal = (from, to, size) => (
    <span className="react-bootstrap-table-pagination-total">
      Mostrando {from + " "}
            até {to + " "}
            de {size + " "}
            Resultados
    </span>
  );
  const options = {
    paginationSize: 6,
    pageStartIndex: 1,
    alwaysShowAllBtns: true, // Always show next and previous button
    // withFirstAndLast: false, // Hide the going to First and Last page button
    hideSizePerPage: true, // Hide the sizePerPage dropdown always
    // hidePageListOnlyOnePage: true, // Hide the pagination list when only one page
    firstPageText: "Primeira",
    prePageText: "Anterior",
    nextPageText: "Próxima",
    lastPageText: "Última",
    nextPageTitle: "Primeira página",
    prePageTitle: "Pre página",
    firstPageTitle: "Póxima página",
    lastPageTitle: "Última página",
    showTotal: true,
    paginationTotalRenderer: customTotal
  };

  const [isActive,
    setIsActive] = useState(true);

  //Tale Config
  const columns = [
    {
      dataField: "title",
      text: "Nome",
      classes: "tableContent"
    }, {
      dataField: "description",
      text: "Descrição",
      classes: "tableContent"
    }, {
      dataField: "options",
      text: "Opções"
    }
  ];

  //Modal Setings New
  const [newModal,
    setNewModal] = useState(false);
  const newToggle = state => setNewModal(state);
  const newToggleHeader = () => setNewModal(!newModal);

  //Modal Setings Edit
  const [editModal,
    setEditModal] = useState(false);
  const editToggle = state => setEditModal(state);
  const editToggleHeader = () => setEditModal(!editModal);

  //table rows load
  let auxData = [];
  const [data,
    setData] = useState([]);

  // Model Variables
  const [model, setModel] = useState({ id: undefined, title: undefined, photo: undefined, description: '' });

  useEffect(() => {
    loadPage();
  }, []);

  async function loadPage() {
    const response = await api.get('/thumbnails')
    auxData = []
    if (response.data) {
      response.data.forEach(register => {
        auxData.push({
          title: [<img className='imgThumb' src={images('./' + register.photo)} />, register.title],
          description: register.description,
          options: [
            <div className="optionsWithImg" > <button
              id={register._id}
              data-tip="Editar"
              type="button"
              onClick={(event) => { getInformation(event.currentTarget.getAttribute("id")); editToggle(true) }}
              className="btn btnEdit"
            >
              <ReactTooltip place="top" type="dark" effect="solid" />
              <FaPencilAlt />
            </button>
              < button
                id={register._id}
                data-tip="Excluir" type="button" className="btn btnDelete" onClick={
                  event => {
                    remove(event.currentTarget.getAttribute("id"))
                  }
                } > <FaTrashAlt /> </button>
            </div >]
        })
      })
    }
    // load the lines of the table
    setData(auxData.map(t => t));

    setIsActive(false)
  }

  async function getInformation(id) {

    const response = await api.get("/thumbnails/" + id);
    console.log(response)
    if (response.data) {
      setThumbnail(undefined)
      setModel(response.data)
      setImg(<img className='thumbnailEdit' src={images('./' + response.data.photo)} />)
    }
    else {
      Swal.fire(
        "Oops...",
        "Erro ao buscar buscar as informações do registro",
        "error"
      );
    }
  }

  async function remove(id) {
    Swal.fire({
      title: 'Atenção',
      icon: 'warning',
      html:
        'Não será possivel desfazer um registro excluido. \n Deseja prosseguir?',
      showCancelButton: true,
      focusConfirm: false,
      confirmButtonText:
        'Sim',
      cancelButtonText:
        'Cancelar',
    }).then(async (value) => {
      if (value.value) {

        const response = await api.delete("/thumbnails/" + id)

        if (response.data) {
          await Swal.fire(
            "Deleted!",
            "Deletado com Sucesso!",
            "success"
          ).then(result => { if (result.value) loadPage() });
        }
        else {
          Swal.fire(
            "Oops...",
            "Erro ao tentar deletar o registro.",
            "error"
          );
        }
      }
    })

  }

  async function create() {
    try {
      if (!model.title || !thumbnail) {
        Swal.fire(
          "Oops...",
          "Por favor, preencha todos os campos obrigatórios.",
          "info"
        );
      }
      else {
        // disable the button to await the save
        document.getElementById('btnSave').disabled = true
        document.getElementById('btnSave').innerHTML = "Salvando..."

        const data = new FormData();

        data.append("title", model.title);
        data.append("description", model.description);
        data.append("photo", thumbnail);

        const response = await api.post("/thumbnails", data)

        if (response.data) {
          await Swal.fire(
            "success!",
            "Salvo com sucesso!",
            "success"
          )
          loadPage();
          editToggle(false);

        }
        else {
          await Swal.fire(
            "Oops...",
            "Error ao tentar salvar.",
            "error"
          );
          document.getElementById('btnSave').disabled = false
          document.getElementById('btnSave').innerHTML = "Salvar"
        }
      }
    }
    catch (e) {
      await Swal.fire(
        "Oops...",
        "Error ao tentar salvar.",
        "error"
      );
    }
  }

  async function update() {
    try {
      console.log(!model.title, !img, !thumbnail)
      if (!model.title) {
        Swal.fire(
          "Oops...",
          "Por favor, preencha todos os campos obrigatórios.",
          "info"
        );
      }
      else {
        // disable the button to await the save
        document.getElementById('btnEdit').disabled = true
        document.getElementById('btnEdit').innerHTML = "Salvando..."

        const data = new FormData();

        data.append("title", model.title);
        data.append("description", model.description);

        if (thumbnail)
          data.append("photo", thumbnail);

        const response = await api.put("/thumbnails/" + model._id, data)

        if (response.data) {
          await Swal.fire(
            "success!",
            "Salvo com sucesso!",
            "success"
          )
          loadPage();
          editToggle(false);

        }
        else {
          await Swal.fire(
            "Oops...",
            "Error ao tentar salvar.",
            "error"
          );
          document.getElementById('btnEdit').disabled = false
          document.getElementById('btnEdit').innerHTML = "Salvar"
        }
      }
    }
    catch (e) {
      await Swal.fire(
        "Oops...",
        "Error ao tentar salvar.",
        "error"
      );
    }
  }

  return (<>
    <Modal
      className={'modalNew modal-md'}
      isOpen={newModal}
      toggle={newToggleHeader}>
      <ModalHeader toggle={newToggleHeader}>Nova Estampa</ModalHeader>
      <ModalBody className="content">
        <Row className="lineComponent">
          <Col sm="12">
            <label className="label">Nome
                        <b style={{
                color: 'red'
              }}>*</b>
            </label>
            <input
              type="text"
              className="form-control "
              value={model.title}
              onChange={event => setModel({ title: event.target.value, photo: model.photo, description: model.description })} />
          </Col>
        </Row>
        <Row className="lineComponent">
          <Col sm='6'>
            <label className="label">Foto Estampa <b style={{ color: 'red' }}>*</b></label>
            <Row>
              <Col sm="9">
                <label
                  id="thumbnail"
                  style={{ backgroundImage: `url(${preview})` }}
                  className={thumbnail ? "has-thumbnail" : ""}
                >
                  <input
                    type="file"
                    accept="image/*"
                    onChange={event => {
                      if (!/(\.bmp|\.gif|\.jpg|\.jpeg|\.png|\.tiff|\.svg|\.ico)$/i.test(event.target.value)) {
                        Swal.fire(
                          "Oops...",
                          "Não é possivel carregar essa imagem, por favor, escolha outra",
                          "info"
                        );
                        event.preventDefault()
                      }
                      else {
                        setThumbnail(event.target.files[0])
                      }
                    }
                    }
                  />
                  <IconContext.Provider value={{ className: "icon" }}>
                    <div>
                      <FaCamera />
                    </div>
                  </IconContext.Provider>
                </label>
              </Col>

            </Row>
          </Col>
          <Col sm='6'>
            <label className="label">Descrição

                    </label>
            <textarea onChange={event => setModel({ title: model.title, photo: model.photo, description: event.target.value })} value={model.description} className="form-control " rows="9" cols="50">

            </textarea>
          </Col>
        </Row>

        <ModalFooter className='modalfooter'>
          <button id="btnSave"
            onClick={() => { create() }}
            className="btn btn-primary btnModal">
            Salvar
                </button>{" "}
          <button
            className="btn btn-secondary btnModal"
            onClick={() => newToggle(false)}>
            Cancelar
                </button>
        </ModalFooter>
      </ModalBody>
    </Modal>

    <Modal
      className={'modalNew modal-md'}
      isOpen={editModal}
      toggle={editToggleHeader}>
      <ModalHeader toggle={editToggleHeader}>Alterando informações da Estampa {model.title}</ModalHeader>
      <ModalBody className="content">
        <Row className="lineComponent">
          <Col sm="12">
            <label className="label">Nome
                        <b style={{
                color: 'red'
              }}>*</b>
            </label>
            <input
              type="text"
              className="form-control "
              value={model.title}
              onChange={event => setModel({_id: model._id,  title: event.target.value, photo: model.photo, description: model.description })} />
          </Col>
        </Row>
        <Row className="lineComponent">
          <Col sm='6'>
            <label className="label">Descrição

                    </label>
            <textarea onChange={event => setModel({_id: model._id,  title: model.title, photo: model.birthDate, description: event.target.value })} value={model.description} className="form-control " rows="9" cols="50">

            </textarea>
          </Col>
          <Col sm='6'>
            <label className="label">Foto Estampa <b style={{ color: 'red' }}>*</b></label>
            <Row>
              <Col sm="9">
                <label
                  id="thumbnail"
                  style={{ backgroundImage: `url(${preview})` }}
                  className={thumbnail ? "has-thumbnail" : ""}
                >

                  {img}
                  <input
                    type="file"
                    accept="image/*"
                    onChange={event => {
                      if (!/(\.bmp|\.gif|\.jpg|\.jpeg|\.png|\.tiff|\.svg|\.ico)$/i.test(event.target.value)) {
                        Swal.fire(
                          "Oops...",
                          "Não é possivel carregar essa imagem, por favor, escolha outra",
                          "info"
                        );
                        event.preventDefault()
                      }
                      else {
                        setThumbnail(event.target.files[0])
                      }
                    }
                    }
                  />
                  <IconContext.Provider value={{ className: "icon" }}>
                    <div>
                      <FaCamera />
                    </div>
                  </IconContext.Provider>
                </label>
              </Col>
            </Row>
          </Col>
        </Row>
        <ModalFooter className='modalfooter'>
          <button
            id="btnEdit"
            onClick={() => { update() }}
            className="btn btn-primary btnModal">
            Salvar alterações
                </button>{" "}
          <button
            className="btn btn-secondary btnModal"
            onClick={() => editToggle(false)}>
            Cancelar
                </button>
        </ModalFooter>
      </ModalBody>
    </Modal>

    <Container className="tablePage" fluid > <ToolkitProvider keyField="name" data={data} columns={columns} search>
      {props => {
        return (
          <div>
            <button onClick={() => {setThumbnail(undefined); setModel({ _id: undefined, title: undefined, photo: undefined, description: '' }); newToggle(true) }} className="btnNew btn btn-primary">
              Adicionar Estampa
                    </button>
            <div className="searchBar">
              <label className="labelSearch">Buscar:</label>
              <SearchBar {...props.searchProps} />
            </div>
            <div className="table">
              <LoadingOverlay
                active={isActive}
                spinner
                text='Carregando...'
              ></LoadingOverlay>
              <BootstrapTable
                {...props.baseProps}
                striped
                hover
                condensed
                pagination={paginationFactory(options)} />
            </div>
          </div>
        )
      }}
    </ToolkitProvider> </Container>
  </>);
}
export default React.memo(Thumbnail);