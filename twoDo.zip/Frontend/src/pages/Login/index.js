import React, { useEffect, useState } from "react";
import Swal from "sweetalert2";
import {
    Container,
    Modal,
    Row,
    Col,
    ModalHeader,
    ModalBody,
    ModalFooter,
} from 'reactstrap';

import './index.css'
import 'bootstrap/dist/css/bootstrap.min.css';
import api from '../../services/api';

const Login = props => {

    const [email,
        setEmail] = useState();

    const [password,
        setPassword] = useState();

    const [username,
        setUsername] = useState();

    const [confirmPassword,
        setConfirmPassword] = useState(undefined);

    //Modal Setings Edit
    const [editModal,
        setEditModal] = useState(false);
    const editToggle = state => setEditModal(state);
    const editToggleHeader = () => setEditModal(!editModal);


    async function login() {
        try {
            if (!email || !password) {
                Swal.fire(
                    "Oops...",
                    "Por favor, preencha o campo de email e senha.",
                    "info"
                );
            }
            else {

                document.getElementById('btnLogin').disabled = true
                document.getElementById('btnLogin').innerHTML = "Acessando..."

                try {
                    const response = await api.post('/login', { email: email, password: password })
                    console.log(response)
                    if (response.data._id) {
                        sessionStorage.setItem('id', [response.data._id, response.data.username, response.data.role])
                        window.location.href = "/dashboard";
                    }
                    else {
                        Swal.fire(
                            "Oops...",
                            "E-mail ou senha incorretos",
                            "info"
                        );
                        document.getElementById('btnLogin').disabled = false
                        document.getElementById('btnLogin').innerHTML = "Fazer Login"
                    }
                }
                catch (e) {
                    Swal.fire(
                        "Oops...",
                        "E-mail ou senha incorretos",
                        "info"
                    );
                    document.getElementById('btnLogin').disabled = false
                    document.getElementById('btnLogin').innerHTML = "Fazer Login"
                }

            }
        }
        catch (e) {
            console.log(e)
            Swal.fire(
                "Oops...",
                "E-mail ou senha incorretos",
                "info"
            );
        }
    }

    async function resetPassword() {
        try {
            if (!username || !email || !password) {
                Swal.fire(
                    "Oops...",
                    "Por favor, preencha todos os campos obrigatórios.",
                    "info"
                );
            }
            if (password) {
                if (password != confirmPassword) {
                    Swal.fire(
                        "Oops...",
                        "As Senhas digitadas não correspondem ",
                        "warning"
                    );
                }
                else {
                    // disable the button to await the save
                    document.getElementById('btnAlterar').disabled = true
                    document.getElementById('btnAlterar').innerHTML = "Resetando.."

                    const response = await api.post("/resetPassword", { username: username, password: password, email: email })

                    if (response.data) {
                        await Swal.fire(
                            "success!",
                            "Resetado com sucesso!",
                            "success"
                        )
                        editToggle(false)
                        console.log(response.data)
                        setUsername(response.data.username)
                    }
                    else {
                        await Swal.fire(
                            "Oops...",
                            "Error ao tentar resetar a senha.",
                            "warning"
                        );
                        document.getElementById('btnAlterar').disabled = false
                        document.getElementById('btnAlterar').innerHTML = "Resetar"
                    }
                }
            }
            else {
                // enablle the button 
                document.getElementById('btnAlterar').disabled = false
                document.getElementById('btnAlterar').innerHTML = "Resetar"
            }
        }
        catch (e) {
            if (e.toString().search('404') > 0) {
                Swal.fire(
                    "Oops...",
                    "usuario não encontrado",
                    "info"
                );
            }
            else {
                Swal.fire(
                    "Oops...",
                    "Error ao tentar resetar a senha.",
                    "info"
                );
            }
            // enablle the button 
            document.getElementById('btnAlterar').disabled = false
            document.getElementById('btnAlterar').innerHTML = "Resetar"
        }
    }

    return (
        <>
            <Modal
                className={'modalNew modal-md'}
                isOpen={editModal}
                toggle={editToggleHeader}>
                <ModalHeader toggle={editToggleHeader}>Resetar Senha</ModalHeader>
                <ModalBody className="content">
                    <Row className="lineComponent">
                        <Col sm="12">
                            <label className="label">Nome de Usuario
                        <b style={{
                                    color: 'red'
                                }}>*</b>
                            </label>
                            <input
                                tabIndex={0}
                                type="text"
                                className="form-control "
                                value={username}
                                onChange={event => setUsername(event.target.value)} />
                        </Col>
                        <Col sm="12">
                            <label className="label">E-mail
                        <b style={{
                                    color: 'red'
                                }}>*</b>
                            </label>
                            <input
                                type="email"
                                className="form-control "
                                value={email}
                                onChange={event => setEmail(event.target.value)} />
                        </Col>
                    </Row>
                    <Row className="lineComponent">
                        <Col sm="6">
                            <label className="label">Nova Senha
                        <b style={{
                                    color: 'red'
                                }}>*</b>
                            </label>
                            <input
                                type="password"
                                className="form-control "
                                value={password}
                                onKeyUp={(event) => {
                                    if (event.target.value) {
                                        if (event.target.value.length > 0) {
                                            document.getElementById('confirm').style.display = 'inline'
                                        }
                                        else {
                                            document.getElementById('confirm').style.display = 'none'
                                        }
                                    }
                                    else {
                                        document.getElementById('confirm').style.display = 'none'
                                    }
                                }}
                                onChange={event => {
                                    setPassword(event.target.value)
                                }} />
                        </Col>
                        <Col sm="6">
                            <div id='confirm'>
                                <label className="label">Confirmação senha
                        <b style={{
                                        color: 'red'
                                    }}>*</b>
                                </label>
                                <input
                                    type="password"
                                    className="form-control "
                                    value={confirmPassword}
                                    onChange={event => setConfirmPassword(event.target.value)} />
                            </div>
                        </Col>
                    </Row>
                    <ModalFooter className='modalfooter'>
                        <button id="btnAlterar"
                            onClick={() => { resetPassword() }}
                            className="btn btn-primary btnModal">
                            Resetar
                </button>{" "}
                        <button
                            id="btnsave"
                            className="btn btn-secondary btnModal"
                            onClick={() => editToggle(false)}>
                            Cancelar
                </button>
                    </ModalFooter>
                </ModalBody>
            </Modal>

            <Container>
                <div className='containerLogin'>
                    <h3>Login</h3>
                    <div className="form-group">
                        <label>E-mail</label>
                        <input tabIndex={0} value={email} onChange={(event) => setEmail(event.target.value)} type="email" className="form-control" placeholder="E-mail" />
                    </div>

                    <div className="form-group">
                        <label>Senha</label>
                        <input value={password} onChange={(event) => setPassword(event.target.value)} type="password" className="form-control" placeholder="Senha" />
                    </div>
                    <a onClick={() => { setPassword(undefined); setUsername(undefined); setEmail(undefined); setConfirmPassword(undefined); editToggle(true) }} className='recoverPassword'>Recuperar Senha</a>
                    <button id='btnLogin' onClick={() => login()} className="btn btn-primary btn-block btnLogin">Fazer Login</button>
                </div>
            </Container>
        </>
    );
}
export default React.memo(Login);