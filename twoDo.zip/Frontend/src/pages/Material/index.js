import React, { useEffect, useState } from "react";
import LoadingOverlay from 'react-loading-overlay';
import {
    Modal,
    Row,
    Container,
    Col,
    ModalHeader,
    ModalBody,
    FormGroup, Label, Input,
    ModalFooter,
} from 'reactstrap';

import Swal from "sweetalert2";
import BootstrapTable from "react-bootstrap-table-next";
import ToolkitProvider, { Search } from "react-bootstrap-table2-toolkit";
import paginationFactory from "react-bootstrap-table2-paginator";
import ReactTooltip from 'react-tooltip'
import { FaPencilAlt, FaTrashAlt } from "react-icons/fa";
// import Select from "react-select";

import './index.css'
import "react-bootstrap-table-next/dist/react-bootstrap-table2.min.css";
import "semantic-ui-css/semantic.min.css";
import "bootstrap/dist/css/bootstrap.css";
import api from '../../services/api';
import Thumbnail from "../Thumbnail";

const Material = props => {
    //Grids Config
    const { SearchBar } = Search;
    // pagination option
    const customTotal = (from, to, size) => (
        <span className="react-bootstrap-table-pagination-total">
            Mostrando {from + " "}
            até {to + " "}
            de {size + " "}
            Resultados
        </span>
    );
    const options = {
        paginationSize: 6,
        pageStartIndex: 1,
        alwaysShowAllBtns: true, // Always show next and previous button
        // withFirstAndLast: false, // Hide the going to First and Last page button
        hideSizePerPage: true, // Hide the sizePerPage dropdown always
        // hidePageListOnlyOnePage: true, // Hide the pagination list when only one page
        firstPageText: "Primeira",
        prePageText: "Anterior",
        nextPageText: "Próxima",
        lastPageText: "Última",
        nextPageTitle: "Primeira página",
        prePageTitle: "Pre página",
        firstPageTitle: "Póxima página",
        lastPageTitle: "Última página",
        showTotal: true,
        paginationTotalRenderer: customTotal
    };

    //Tale Config
    const columns = [
        {
            dataField: "title",
            text: "Nome",
            classes: "tableContent"
        }, {
            dataField: "amount",
            text: "Quantidade",
            classes: "tableContent"
        }, {
            dataField: "mesures",
            text: "Medidas",
            classes: "tableContent",
            headerStyle: (colum, colIndex) => {
                return { width: '500px', textAlign: 'center' };
            }
        }, {
            dataField: "options",
            text: "Opções"
        }
    ];

    //Modal Setings New
    const [newModal,
        setNewModal] = useState(false);
    const newToggle = state => setNewModal(state);
    const newToggleHeader = () => setNewModal(!newModal);

    //Modal Setings Edit
    const [editModal,
        setEditModal] = useState(false);
    const editToggle = state => setEditModal(state);
    const editToggleHeader = () => setEditModal(!editModal);

    //table rows load
    let auxData = [];
    const [data,
        setData] = useState([]);

    const [isActive,
        setIsActive] = useState(true);

    const [checked,
        setChecked] = useState({ cm: false, m: false })

    // Model Variables
    const [model, setModel] = useState({ id: undefined, title: undefined, unitMeasure: undefined, height: 0, amount: 0, width: 0, length: 0 });

    useEffect(() => {
        loadPage();
    }, []);


    async function loadPage() {
        const response = await api.get('/materials')
        console.log(response)
        auxData = [];
        if (response.data) {
            response.data.forEach(register => {
                console.log(register)
                let width = '', height = '', length = ''
                if (register.width) {
                    width = ('Largura: ' + register.width + " " + register.unitMeasure).replace(/\./g, ',')
                }
                if (register.height) {
                    height = ('Altura: ' + register.height + " " + register.unitMeasure).replace(/\./g, ',')
                }
                if (register.length) {
                    length = ('Comprimento: ' + register.length + " " + register.unitMeasure).replace(/\./g, ',')
                }

                auxData.push({
                    title: register.title,
                    amount: register.amount,
                    mesures: [
                        <div className='measureContent'>
                            <div className="measureHeader">
                                <div className='measureUnit measureUnit1'>
                                    {width}
                                </div>
                                <div className='measureUnit'>
                                    {height}
                                </div>
                                <div className='measureUnit'>
                                    {length}
                                </div>
                            </div>
                        </div>
                    ],
                    options: [
                        <div className="options" > <button
                            id={register._id}
                            data-tip="Editar"
                            type="button"
                            onClick={(event) => { getInformation(event.currentTarget.getAttribute("id")); editToggle(true) }}
                            className="btn btnEdit"
                        >
                            <ReactTooltip place="top" type="dark" effect="solid" />
                            <FaPencilAlt />
                        </button>
                            < button
                                id={register._id}
                                data-tip="Excluir" type="button" className="btn btnDelete" onClick={
                                    event => {
                                        remove(event.currentTarget.getAttribute("id"))
                                    }
                                } > <FaTrashAlt /> </button>
                        </div >]
                })
            })
        }
        // load the lines of the table
        setData(auxData.map(t => t));
        setIsActive(false)
    }

    async function getInformation(id) {

        const response = await api.get("/materials/" + id);
        console.log(response)
        if (response.data) {
            if (response.data.unitMeasure == 'cm') {
                setChecked({ cm: true, m: false })
            }
            else {
                setChecked({ cm: false, m: true })
            }

            setModel({
                id: response.data._id, amount: response.data.amount, title: response.data.title,
                width: response.data.width.toString().replace(/\./, ','), height: response.data.height.toString().replace(/\./, ','),
                length: response.data.length.toString().replace(/\./, ','), unitMeasure: response.data.unitMeasure
            })
        }
        else {
            Swal.fire(
                "Oops...",
                "Erro ao buscar buscar as informações do registro",
                "error"
            );
        }
    }

    async function remove(id) {
        Swal.fire({
            title: 'Atenção',
            icon: 'warning',
            html:
                'Não será possivel desfazer um registro excluido. \n Deseja prosseguir?',
            showCancelButton: true,
            focusConfirm: false,
            confirmButtonText:
                'Sim',
            cancelButtonText:
                'Cancelar',
        }).then(async (value) => {
            if (value.value) {

                const response = await api.delete("/materials/" + id)

                if (response.data) {
                    await Swal.fire(
                        "Deleted!",
                        "Deletado com Sucesso!",
                        "success"
                    ).then(result => { if (result.value) loadPage() });
                }
                else {
                    Swal.fire(
                        "Oops...",
                        "Erro ao tentar deletar o registro.",
                        "error"
                    );
                }
            }
        })

    }

    async function create() {
        try {
            if (!model.title || !model.unitMeasure || !model.amount || !Thumbnail) {
                Swal.fire(
                    "Oops...",
                    "Por favor, preencha todos os campos obrigatórios.",
                    "info"
                );
            }
            else {
                // disable the button to await the save
                document.getElementById('btnSave').disabled = true
                document.getElementById('btnSave').innerHTML = "Salvando..."

                let data = {
                    title: model.title, unitMeasure: model.unitMeasure, width: model.width.toString().replace(/,/g, '.'),
                    height: model.height.toString().replace(/,/g, '.'),
                    length: model.length.toString().replace(/,/g, '.'),
                    amount: model.amount
                }


                const response = await api.post("/materials", data)

                if (response.data) {
                    await Swal.fire(
                        "success!",
                        "Salvo com sucesso!",
                        "success"
                    )
                    loadPage();
                    newToggle(false);

                }
                else {
                    await Swal.fire(
                        "Oops...",
                        "Error ao tentar salvar.",
                        "error"
                    );
                    document.getElementById('btnSave').disabled = false
                    document.getElementById('btnSave').innerHTML = "Salvar"
                }
            }
        }
        catch (e) {
            await Swal.fire(
                "Oops...",
                "Error ao tentar salvar.",
                "error"
            );
        }
    }

    async function update() {
        try {
            if (!model.title || !model.unitMeasure || !model.amount) {
                Swal.fire(
                    "Oops...",
                    "Por favor, preencha todos os campos obrigatórios.",
                    "info"
                );
            }
            else {
                // disable the button to await the save
                document.getElementById('btnAlterar').disabled = true
                document.getElementById('btnAlterar').innerHTML = "Salvando..."

                let data = {
                    id: model._id,
                    title: model.title, unitMeasure: model.unitMeasure,
                    width: model.width.toString().replace(/,/g, '.'),
                    height: model.height.toString().replace(/,/g, '.'),
                    length: model.length.toString().replace(/,/g, '.'),
                    amount: model.amount
                }

                const response = await api.put("/materials/" + data.id, data)

                if (response.data) {
                    await Swal.fire(
                        "success!",
                        "Salvo com sucesso!",
                        "success"
                    )
                    loadPage();
                    editToggle(false);

                }
                else {
                    await Swal.fire(
                        "Oops...",
                        "Error ao tentar salvar.",
                        "error"
                    );
                    document.getElementById('btnAlterar').disabled = false
                    document.getElementById('btnAlterar').innerHTML = "Salvar"
                }
            }
        }
        catch (e) {
            await Swal.fire(
                "Oops...",
                "Error ao tentar salvar.",
                "error"
            );
        }
    }

    function isNumeric(evt) {
        var charCode = (evt.which) ? evt.which : evt.keyCode
        if (charCode > 31 && (charCode != 44 && (charCode < 48 || charCode > 57)))
            return false;
        return true;
    }

    function fieldValidation(event) {
        event.target.value = event.target.value.replace(/[-!$%^&*()_+|~=`{}\[\]:";'<>?.\/]| |[a-z]|[A-Z]\w+/g, '')
        if (event.target.value[0] == ',') {
            return false
        }
        let aux = event.target.value.match(/,/g || []);
        if (aux) {
            if (aux.length == 1) {
                return true
            }
        }
        else {
            if (!aux) {
                event.preventDefault()
                return true
            }

        }
    }

    function blurEvent(event) {
        if (event.target.value[event.target.value.length - 1] == ',') {
            event.target.value = event.target.value.substring(0, event.target.value.length - 1)
        }; if (event.target.value.replace(/_|0|,/g, '') == '') { event.target.value = 0 }
    }

    return (<>
        <Modal
            className={'modalNew modal-md'}
            isOpen={newModal}
            toggle={newToggleHeader}>
            <ModalHeader toggle={newToggleHeader}>Novo Material</ModalHeader>
            <ModalBody className="content">
                <Row className="lineComponent">
                    <Col sm="12">
                        <label className="label">Nome
                        <b style={{
                                color: 'red'
                            }}>*</b>
                        </label>
                        <input
                            tabIndex={0}
                            type="text"
                            className="form-control "
                            value={model.title}
                            onChange={event => setModel({
                                title: event.target.value, unitMeasure: model.unitMeasure,
                                amount: model.amount, width: model.width, length: model.length, height: model.height
                            })} />
                    </Col>
                </Row>
                <Row>
                    <Col sm="12">
                        <label className="labelUnd">Unidade de medida
                        <b style={{
                                color: 'red'
                            }}>*</b>
                        </label>
                        <br />
                        <FormGroup value='cm' className='unitOptions' check onChange={event => {
                            setChecked({ cm: true, m: false });
                            setModel({
                                title: model.title, unitMeasure: event.target.value,
                                amount: model.amount, width: model.width, length: model.length, height: model.height
                            })
                        }}>
                            <Label check>
                                <Input value='cm' type="radio" name="radio1" />{' '}
                            Centimetro(s)
                        </Label>
                        </FormGroup>
                        <FormGroup value='m' className='unitOptions' check onChange={event => {
                            setChecked({ cm: true, m: false });
                            setModel({
                                title: model.title, unitMeasure: event.target.value,
                                amount: model.amount, width: model.width, length: model.length, height: model.height
                            })
                        }}>
                            <Label check>
                                <Input value='m' type="radio" name="radio1" />{' '}
                           Metro(s)
                        </Label>
                        </FormGroup>
                    </Col>

                </Row>
                <Row className="lineComponent">
                    <Col sm="6">
                        <label className="label">Quantidade
                        <b style={{
                                color: 'red'
                            }}>*</b>
                        </label>
                        <input
                            type='text'
                            onKeyPress={(evt) => { var charCode = (evt.which) ? evt.which : evt.keyCode; if (((charCode < 48 || charCode > 57))) { evt.preventDefault() } }}
                            className="form-control"
                            onClick={(event) => { if (event.target.value == '0') { event.target.value = '' } else event.target.value = model.amount }}
                            onBlur={(event) => blurEvent(event)}
                            value={model.amount}
                            onChange={event => {
                                if (fieldValidation(event)) {
                                    setModel({
                                        title: model.title, unitMeasure: model.unitMeasure,
                                        amount: event.target.value, width: model.width, length: model.length, height: model.height
                                    })
                                }
                            }} />
                    </Col>
                    <Col sm="6">
                        <label className="label">Comprimento</label>
                        <input
                            type='text'
                            onKeyPress={(evt) => { if (!isNumeric(evt)) { evt.preventDefault() } }}
                            className="form-control"
                            onClick={(event) => { if (event.target.value == '0') { event.target.value = '' } else event.target.value = model.length }}
                            onBlur={(event) => blurEvent(event)}
                            value={model.length}
                            onChange={event => {
                                if (fieldValidation(event)) {
                                    setModel({
                                        title: model.title, unitMeasure: model.unitMeasure, description: model.description,
                                        amount: model.amount, width: model.width, length: event.target.value, height: model.height
                                    })
                                }
                            }} />
                    </Col>
                </Row>
                <Row className="lineComponent">
                    <Col sm="6">
                        <label className="label">Largura</label>
                        <input
                            type='text'
                            onKeyPress={(evt) => { if (!isNumeric(evt)) { evt.preventDefault() } }}
                            className="form-control"
                            onClick={(event) => { if (event.target.value == '0') { event.target.value = '' } else event.target.value = model.width }}
                            onBlur={(event) => blurEvent(event)}
                            value={model.width}
                            onChange={event => {
                                if (fieldValidation(event)) {
                                    setModel({
                                        title: model.title, unitMeasure: model.unitMeasure,
                                        amount: model.amount, width: event.target.value, length: model.length, height: model.height
                                    })
                                }
                            }} />

                    </Col>
                    <Col sm="6">
                        <label className="label">Altura</label>
                        <input
                            type='text'
                            onKeyPress={(evt) => { if (!isNumeric(evt)) { evt.preventDefault() } }}
                            className="form-control"
                            onClick={(event) => { if (event.target.value == '0') { event.target.value = '' } else event.target.value = model.height }}
                            onBlur={(event) => blurEvent(event)}
                            value={model.height}
                            onChange={event => {
                                if (fieldValidation(event)) {
                                    setModel({
                                        title: model.title, unitMeasure: model.unitMeasure,
                                        amount: model.amount, width: model.width, length: model.length, height: event.target.value
                                    })
                                }
                            }} />
                    </Col>
                </Row>
                <ModalFooter className='modalfooter'>
                    <button id="btnSave"
                        onClick={() => { create() }}
                        className="btn btn-primary btnModal">
                        Salvar
                </button>{" "}
                    <button
                        className="btn btn-secondary btnModal"
                        onClick={() => newToggle(false)}>
                        Cancelar
                </button>
                </ModalFooter>
            </ModalBody>
        </Modal>

        <Modal
            className={'modalNew modal-md'}
            isOpen={editModal}
            toggle={editToggleHeader}>
            <ModalHeader toggle={editToggleHeader}>Alterando dados do Material {model.title}</ModalHeader>
            <ModalBody className="content">
                <Row className="lineComponent">
                    <Col sm="12">
                        <label className="label">Nome
                        <b style={{
                                color: 'red'
                            }}>*</b>
                        </label>
                        <input
                            tabIndex={0}
                            type="text"
                            className="form-control "
                            value={model.title}
                            onChange={event => setModel({
                                _id: model.id,
                                title: event.target.value, unitMeasure: model.unitMeasure,
                                amount: model.amount, width: model.width, length: model.length, height: model.height
                            })} />
                    </Col>
                </Row>
                <Row>
                    <Col sm="12">
                        <label className="labelUnd">Unidade de medida
                        <b style={{
                                color: 'red'
                            }}>*</b>
                        </label>
                        <br />
                        <FormGroup value='cm' className='unitOptions' check onChange={event => {
                            setChecked({ cm: true, m: false });
                            setModel({
                                _id: model.id,
                                title: model.title, unitMeasure: event.target.value,
                                amount: model.amount, width: model.width, length: model.length, height: model.height
                            })
                        }}>
                            <Label check>
                                <Input checked={checked.cm} value='cm' type="radio" name="radio1" />{' '}
                            Centimetro(s)
                        </Label>
                        </FormGroup>
                        <FormGroup value='m' className='unitOptions' check onChange={event => {
                            setChecked({ cm: false, m: true });
                            setModel({
                                _id: model.id,
                                title: model.title, unitMeasure: event.target.value,
                                amount: model.amount, width: model.width, length: model.length, height: model.height
                            })
                        }}>
                            <Label check>
                                <Input checked={checked.m} value='m' type="radio" name="radio1" />{' '}
                           Metro(s)
                        </Label>
                        </FormGroup>
                    </Col>

                </Row>
                <Row className="lineComponent">
                    <Col sm="6">
                        <label className="label">Quantidade
                        <b style={{
                                color: 'red'
                            }}>*</b>
                        </label>
                        <input
                            type='text'
                            onKeyPress={(evt) => { var charCode = (evt.which) ? evt.which : evt.keyCode; if ((charCode > 31 && (charCode < 48 || charCode > 57))) { evt.preventDefault() } }}
                            className="form-control"
                            onClick={(event) => { if (event.target.value == '0') { event.target.value = '' } else event.target.value = model.amount }}
                            onBlur={(event) => blurEvent(event)}
                            value={model.amount}
                            onChange={event => {
                                if (fieldValidation(event)) {
                                    setModel({
                                        _id: model.id,
                                        title: model.title, unitMeasure: model.unitMeasure,
                                        amount: event.target.value, width: model.width, length: model.length, height: model.height
                                    })
                                }
                            }} />
                    </Col>
                    <Col sm="6">
                        <label className="label">Comprimento</label>
                        <input
                            type='text'
                            onKeyPress={(evt) => { if (!isNumeric(evt)) { evt.preventDefault() } }}
                            className="form-control"
                            onClick={(event) => { if (event.target.value == '0') { event.target.value = '' } else event.target.value = model.length }}
                            onBlur={(event) => blurEvent(event)}
                            value={model.length}
                            onChange={event => {
                                if (fieldValidation(event)) {
                                    setModel({
                                        _id: model.id,
                                        title: model.title, unitMeasure: model.unitMeasure, description: model.description,
                                        amount: model.amount, width: model.width, length: event.target.value, height: model.height
                                    })
                                }
                            }} />
                    </Col>
                </Row>
                <Row className="lineComponent">
                    <Col sm="6">
                        <label className="label">Largura</label>
                        <input
                            type='text'
                            onKeyPress={(evt) => { if (!isNumeric(evt)) { evt.preventDefault() } }}
                            className="form-control"
                            onClick={(event) => { if (event.target.value == '0') { event.target.value = '' } else event.target.value = model.width }}
                            onBlur={(event) => blurEvent(event)}
                            value={model.width}
                            onChange={event => {
                                if (fieldValidation(event)) {
                                    setModel({
                                        _id: model.id,
                                        title: model.title, unitMeasure: model.unitMeasure,
                                        amount: model.amount, width: event.target.value, length: model.length, height: model.height
                                    })
                                }
                            }} />

                    </Col>
                    <Col sm="6">
                        <label className="label">Altura</label>
                        <input
                            type='text'
                            onKeyPress={(evt) => { if (!isNumeric(evt)) { evt.preventDefault() } }}
                            className="form-control"
                            onClick={(event) => { if (event.target.value == '0') { event.target.value = '' } else event.target.value = model.height }}
                            onBlur={(event) => blurEvent(event)}
                            value={model.height}
                            onChange={event => {
                                if (fieldValidation(event)) {
                                    setModel({
                                        _id: model.id,
                                        title: model.title, unitMeasure: model.unitMeasure,
                                        amount: model.amount, width: model.width, length: model.length, height: event.target.value
                                    })
                                }
                            }} />
                    </Col>
                </Row>

                <ModalFooter className='modalfooter'>
                    <button
                        id="btnAlterar"
                        onClick={() => { update() }}
                        className="btn btn-primary btnModal">
                        Salvar alterações
                </button>{" "}
                    <button
                        className="btn btn-secondary btnModal"
                        onClick={() => editToggle(false)}>
                        Cancelar
                </button>
                </ModalFooter>
            </ModalBody>
        </Modal>

        < Container className="tablePage" fluid > <ToolkitProvider keyField="name" data={data} columns={columns} search>
            {props => {
                return (
                    <div>
                        <button onClick={() => { setModel({ id: undefined, title: undefined, unitMeasure: undefined, height: 0, amount: 0, width: 0, length: 0 }); newToggle(true) }} className="btnNew btn btn-primary">
                            Novo Material
                    </button>
                        <div className="searchBar">
                            <label className="labelSearch">Buscar:</label>
                            <SearchBar {...props.searchProps} />
                        </div>
                        <div className="table">
                            <LoadingOverlay
                                active={isActive}
                                spinner
                                text='Carregando...'
                            ></LoadingOverlay>
                            <BootstrapTable
                                {...props.baseProps}
                                striped
                                hover
                                condensed
                                pagination={paginationFactory(options)} />
                        </div>
                    </div>
                )
            }}
        </ToolkitProvider> </Container>
    </>);
}
export default React.memo(Material);