import React from 'react';

import {
  Collapse,
  Container,
  Navbar,
  NavbarBrand,
  Nav
} from 'reactstrap';

import  './index.css'
import 'bootstrap/dist/css/bootstrap.min.css';

export default class Login extends React.Component {
    render() {
        return (
          <>
            </>
        );
    }
}
