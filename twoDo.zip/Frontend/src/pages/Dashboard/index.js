import React, { useEffect, useState, useMemo } from "react";
import api from '../../services/api';
import ReactTooltip from 'react-tooltip'
import { IconContext } from "react-icons";
import { FaCamera } from "react-icons/fa";
import { FaPencilAlt, FaTrashAlt } from "react-icons/fa";
import Select from 'react-select';
import Swal from "sweetalert2";
import {
  Modal,
  Button,
  Row,
  Container,
  Col, FormGroup, Label, Input,
  ModalHeader,
  ModalBody,
  ModalFooter,
} from 'reactstrap';
import AsyncBoard from 'react-trello'

import './index.css'
import 'bootstrap/dist/css/bootstrap.min.css';

const images = require.context('../../../../2Do_backend/uploads', true)

const Dashboard = props => {
  const columnStyle = {
    'width': window.screen.width / 4 + 20
  }

  let auxData = []

  const [data, setData] = useState({
    lanes: [
      {
        id: "awaiting",
        title: "Aguardando Pagamento",
        style: columnStyle,
        cards: [],
      },
      {
        id: "stock",
        title: "Em Separação de Estoque",
        style: columnStyle,
        cards: [],
      },
      {
        id: "production",
        title: "Em produção",
        style: columnStyle,
        cards: [],
      },
      {
        id: "delivery",
        title: "Aguardando Entrega/Retirada",
        style: columnStyle,
        cards: [],
      },
    ]
  })

  const [thumbnail, setThumbnail] = useState(null);
  const preview = useMemo(() => {
    return thumbnail ? URL.createObjectURL(thumbnail) : null;
  }, [thumbnail]);


  //select Options
  const [productOptions,
    setProductOptions] = useState([{}]);

  const [thumbnailsOptions,
    setThumbnailsOptions] = useState([{}]);

  const [embroideryOptions,
    setEmbroideryOptions] = useState([{}]);

  const [clientOptions,
    setClientOptions] = useState([{}]);

  //Modal Setings Edit
  const [editModal,
    setEditModal] = useState(false);
  const editToggle = state => setEditModal(state);
  const editToggleHeader = () => setEditModal(!editModal);

  const [img, setImg] = useState(null);
  const [checkedOrder,
    setCheckedOrder] = useState({ cm: false, m: false })

  const [checked,
    setChecked] = useState({ cm: false, m: false })

  let today = new Date();
  let dd = parseInt(String(today.getDate()).padStart(2, '0')) + 10;
  let mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
  let yyyy = today.getFullYear();

  today = yyyy + '-' + mm + '-' + dd;

  // Model Variables
  const [model, setModel] = useState({
    id: undefined,
    description: '',
    title: undefined,
    amount: 1,
    height: 0,
    width: 0,
    stats: undefined,
    length: 0,
    unitMeasure: undefined,
    orderValue: 0,
    deliveryDate: today,
    user: undefined,
    orderHistoric: undefined,
    client: undefined,
    product: undefined,
    thumbnail: undefined,
    embroidery: undefined
  });

  const [product, setProduct] = useState({ _id: undefined, description: '', title: undefined, photo: undefined, unitMeasure: undefined, height: 0, width: 0, length: 0 });
  const [embroidery, setEmbroidery] = useState({ _id: undefined, title: undefined, photo: undefined, description: '' });
  const [modelThumbnail, setModelThumbnail] = useState({ _id: undefined, title: undefined, photo: undefined, description: '' });
  const [client, setClient] = useState({ _id: undefined, fullName: undefined, birthDate: '', phone: undefined, address: undefined, cpf: undefined });

  const [productModal,
    setProductModal] = useState(false);
  const productModalToggle = state => setProductModal(state);
  const productModalToggleHeader = () => setProductModal(!productModal);

  const [embroideryModal,
    setEmbroideryModal] = useState(false);
  const embroiderytModalToggle = state => setEmbroideryModal(state);
  const embroideryModalToggleHeader = () => setEmbroideryModal(!embroideryModal);

  const [thumbnailModal,
    setThumbnailModal] = useState(false);
  const thumbnailModalToggle = state => setThumbnailModal(state);
  const thumbnailModalToggleHeader = () => setThumbnailModal(!thumbnailModal);

  const [visible,
    setVisible] = useState(true);

  const [isEdited,
    setIsEdited] = useState(true);

  useEffect(() => {
    getItens()
    loadPage();
  }, []);

  async function getInformation(model, id) {
    if (model == 'produto') {
      try {
        const response = await api.get("/products/" + id);
        console.log(response)
        if (response.data) {
          setProduct(response.data)
          setImg(<img className='thumbnailEditProduct' src={images('./' + response.data.photo)} />)
          if (response.data.unitMeasure == 'cm') {
            setChecked({ cm: true, m: false })
          }
          else {
            setChecked({ cm: false, m: true })
          }

          setProduct(response.data)


        }
      }
      catch (e) {
        setProduct({ _id: undefined })
      }
    }
    else if (model == 'bordado') {
      try {
        const response = await api.get("/embroideries/" + id);
        console.log(response)
        if (response.data) {
          setEmbroidery(response.data)
          setImg(<img className='thumbnailEdit' src={images('./' + response.data.photo)} />)


        }
      }
      catch (e) {
        setEmbroidery({ _id: undefined })
      }
    }
    else if (model == 'estampa') {
      try {
        const response = await api.get("/thumbnails/" + id);
        console.log(response)
        if (response.data) {
          setModelThumbnail(response.data)
          setImg(<img className='thumbnailEdit' src={images('./' + response.data.photo)} />)

        }
      }
      catch (e) {
        setModelThumbnail({ _id: undefined })
      }
    }
    else if (model == 'client') {
      const response = await api.get("/clients/" + id);
      console.log(response)
      if (response.data) {
        setClient(response.data)
      }
    }
    else if (model == 'order') {

      const response = await api.get("/orders/" + id);

      if (response.data) {
        let date = response.data.deliveryDate.split('T')[0]
        delete response.data['deliveryDate']
        setModel({ deliveryDate: date, ...response.data, id: id })

        if (response.data.thumbnail) {
          setModelThumbnail(response.data.thumbnail)
          setImg(<img className='thumbnailEdit' src={images('./' + response.data.thumbnail.photo)} />)
        }
        if (response.data.product) {
          setProduct(response.data.product)
          setImg(<img className='thumbnailEdit' src={images('./' + response.data.product.photo)} />)
        }
        if (response.data.embroidery) {
          setEmbroidery(response.data.embroidery)
        }

        setClient(response.data.client)

        if (response.data.unitMeasure == 'cm') {
          setCheckedOrder({ cm: true, m: false })
        }
        else {
          setCheckedOrder({ cm: false, m: true })
        }

        editToggle(true)
      }
    }
  }

  async function getItens() {
    const products = await api.get('/products')
    const thumbnails = await api.get('/thumbnails')
    const embroideries = await api.get('/embroideries')
    const clients = await api.get('/clients')

    console.log(products, thumbnails, embroideries, clients)
    if (clients.data) {
      auxData = [];
      clients.data.forEach(register => {
        auxData.push({
          value: register._id,
          label: register.fullName
        })
      })
      setClientOptions(auxData.map(t => t))
    }
    if (products.data) {
      auxData = [];
      auxData.push({ value: undefined, label: "Nenhum" })

      products.data.forEach(register => {
        auxData.push({
          value: register._id,
          label: register.title
        })
      })
      setProductOptions(auxData.map(t => t))
    }
    if (thumbnails.data) {
      auxData = [];
      auxData.push({ value: undefined, label: "Nenhum" })

      thumbnails.data.forEach(register => {
        auxData.push({
          value: register._id,
          label: register.title
        })
      })
      setThumbnailsOptions(auxData.map(t => t))
    }
    if (embroideries.data) {
      auxData = [];
      auxData.push({ value: undefined, label: "Nenhum" })

      embroideries.data.forEach(register => {
        auxData.push({
          value: register._id,
          label: register.title
        })
      })
      setEmbroideryOptions(auxData.map(t => t))
    }
  }

  async function loadPage() {
    const response = await api.get('/orders')
    console.log(response)
    auxData = [];
    if (response.data) {

      let awaitingCards = []
      let stockCards = []
      let productionCards = []
      let deliveryCards = []

      console.log(response.data)
      response.data.map(t => {
        let color = 'blue'
        let aux = (((new Date().getDate() - new Date(t.deliveryDate).getDate()) * -1) + 1)
        let daysToDelivery = 'Dias Para entrega: ' + aux
        let textColor = 'white'
        if (aux < 2) {
          color = 'red'
        }
        else if (aux <= 5) {
          color = 'yellow'
          textColor = 'black'
        }

        if (aux < 0) {
          daysToDelivery = 'Atrasada: ' + aux * -1 + ' dias'
        }


        if (t.orderHistoric.status == "Aguardando Pagamento") {
          console.log(t)
          awaitingCards.push({
            id: t._id,
            title: t.title,
            label: t.client.fullName,
            body: "tyestes",
            description: t.description,
            metadata: { id: 'Card1' },
            tags: [{ title: daysToDelivery, color: textColor, bgcolor: color }],
          })
        }
        else if (t.orderHistoric.status == "Em Separação de Estoque") {
          console.log(t)
          stockCards.push({
            id: t._id,
            title: t.title,
            label: t.client.fullName,
            body: "tyestes",
            description: t.description,
            metadata: { id: 'Card1' },
            tags: [{ title: daysToDelivery, color: textColor, bgcolor: color }],
          })
        }
        else if (t.orderHistoric.status == "Em produção") {
          console.log(t)
          productionCards.push({
            id: t._id,
            title: t.title,
            label: t.client.fullName,
            body: "tyestes",
            description: t.description,
            metadata: { id: 'Card1' },
            tags: [{ title: daysToDelivery, color: textColor, bgcolor: color }],
          })
        }
        else if (t.orderHistoric.status == "Aguardando Entrega/Retirada") {
          console.log(t)
          let aux1 = (((new Date().getDate() - new Date(t.updatedAt).getDate()) * -1))
          if (aux1 == 0) {
            aux1 = 'Finalizado hoje'
          }
          else {
            if (aux1 < 0)
              aux1 = aux1 * -1
            aux1 = 'Aguardando Retirada a ' + aux1 + ' dias'
          }

          let tags = [{ title: aux1, color: textColor, bgcolor: 'green' },
          ]

          if (aux < 0) {
            tags.push({ title: daysToDelivery, color: textColor, bgcolor: color })
          }

          deliveryCards.push({
            id: t._id,
            title: t.title,
            label: t.client.fullName,
            body: "tyestes",
            description: t.description,
            metadata: { id: 'Card1' },
            tags: tags,
          })
        }

      })

      let lentgh = { c1: '', c2: '', c3: '', c4: '' }
      if (awaitingCards.length > 0) {
        lentgh.c1 = awaitingCards.length
      }
      if (stockCards.length > 0) {
        lentgh.c2 = stockCards.length
      }
      if (productionCards.length > 0) {
        lentgh.c3 = productionCards.length
      }
      if (deliveryCards.length > 0) {
        lentgh.c4 = deliveryCards.length
      }

      setData({
        lanes: [
          {
            id: "Aguardando Pagamento",
            title: "Aguardando Pagamento",
            label: lentgh.c1,
            style: columnStyle,
            cards: awaitingCards,
          },
          {
            id: "Em Separação de Estoque",
            label: lentgh.c2,
            title: "Em Separação de Estoque",
            style: columnStyle,
            cards: stockCards
          },
          {
            id: "Em produção",
            title: "Em produção",
            label: lentgh.c3,
            style: columnStyle,
            cards: productionCards
          },
          {
            id: "Aguardando Entrega/Retirada",
            title: "Aguardando Entrega/Retirada",
            label: lentgh.c4,
            style: columnStyle,
            cards: deliveryCards,
          },
        ]
      })
    }

    //setData(auxData.map(t => t));
  }

  async function update() {
    if (document.getElementById('btnAlterar').innerHTML == 'Editar') {
      document.getElementById('btnAlterar').innerHTML = 'Salvar'
      setIsEdited(false)
      document.getElementById('btnClose').innerHTML = 'Cancelar'
    }
    else {
      try {
        if (!model.title || !model.description || !client._id || !model.unitMeasure || !model.orderValue > 0) {
          Swal.fire(
            "Oops...",
            "Por favor, preencha todos os campos obrigatórios.",
            "info"
          );
        }
        else {
          // disable the button to await the save
          document.getElementById('btnAlterar').disabled = true
          document.getElementById('btnAlterar').innerHTML = "Salvando..."

          let data = {
            _id: model._id,
            description: model.description,
            title: model.title,
            amount: model.amount.toString().replace(/,/g, '.'),
            height: model.height.toString().replace(/,/g, '.'),
            width: model.width.toString().replace(/,/g, '.'),
            length: model.length.toString().replace(/,/g, '.'),
            unitMeasure: model.unitMeasure,
            orderValue: model.orderValue.toString().replace(/,/g, '.'),
            deliveryDate: model.deliveryDate,
            product: product._id,
            thumbnail: modelThumbnail._id,
            embroidery: embroidery._id
          };

          const response = await api.put("/orders/" + model._id, data)

          if (response.data) {
            await Swal.fire(
              "success!",
              "Salvo com sucesso!",
              "success"
            )
            loadPage();
            editToggle(false);

            document.getElementById('btnAlterar').disabled = false
            document.getElementById('btnAlterar').innerHTML = "Salvar"

            document.getElementById('btnAlterar').innerHTML = 'Editar'
            setIsEdited(true)
            document.getElementById('btnClose').innerHTML = 'Fechar'
          }
          else {
            await Swal.fire(
              "Oops...",
              "Error ao tentar salvar.",
              "error"
            );
            document.getElementById('btnAlterar').disabled = false
            document.getElementById('btnSave').innerHTML = "Salvar"
          }
        }
      }
      catch (e) {
        await Swal.fire(
          "Oops...",
          "Error ao tentar salvar.",
          "error"
        );
      }
    }
  }

  function isNumeric(evt) {
    var charCode = (evt.which) ? evt.which : evt.keyCode
    if (charCode > 31 && (charCode != 44 && (charCode < 48 || charCode > 57)))
      return false;
    return true;
  }

  function fieldValidation(event) {
    event.target.value = event.target.value.replace(/[-!$%^&*()_+|~=`{}\[\]:";'<>?.\/]| |[a-z]|[A-Z]\w+/g, '')
    if (event.target.value[0] == ',') {
      return false
    }
    let aux = event.target.value.match(/,/g || []);
    if (aux) {
      if (aux.length == 1) {
        return true
      }
    }
    else {
      if (!aux) {
        return true
      }
      event.preventDefault()
    }
  }

  function blurEvent(event) {
    if (event.target.value[event.target.value.length - 1] == ',') {
      event.target.value = event.target.value.substring(0, event.target.value.length - 1)
    }; if (event.target.value.replace(/_|0|,/g, '') == '') { event.target.value = 0 }
  }

  async function updadteStatus(id, newStatus) {
    try {
      const response = await api.put("/ordershistory/" + id, { status: newStatus })

      console.log(response)

      loadPage()
    }
    catch (e) {
      console.log('erro updadte order status', e)
    }

  }

  async function finishOrder() {
    Swal.fire({
      title: 'Atenção',
      icon: 'warning',
      html:
        'Não será possivel reabrir o pedido. \n Deseja prosseguir?',
      showCancelButton: true,
      focusConfirm: false,
      confirmButtonText:
        'Sim',
      cancelButtonText:
        'Cancelar',
    }).then(async (value) => {
      if (value.value) {

        const response = await api.put("/ordershistory/" + model._id, { status: 'Concluído' })
        if (response.data) {
          await Swal.fire(
            "Sucesso!",
            "Pedido finalizado com Sucesso!",
            "success"
          ).then(result => { if (result.value) { editToggle(false); loadPage() } });
        }
        else {
          Swal.fire(
            "Oops...",
            "Erro ao tentar finalizar o pedido.",
            "error"
          );
        }
      }
    })

  }

  async function cancelOrder() {
    Swal.fire({
      title: 'Atenção',
      icon: 'warning',
      html:
        'Não será possivel reabrir o pedido. \n Deseja prosseguir?',
      showCancelButton: true,
      focusConfirm: false,
      confirmButtonText:
        'Sim',
      cancelButtonText:
        'Cancelar',
    }).then(async (value) => {
      if (value.value) {

        const response = await api.put("/ordershistory/" + model._id, { status: 'Cancelado' })
        if (response.data) {
          await Swal.fire(
            "Sucesso!",
            "Pedido cancelado com Sucesso!",
            "success"
          ).then(result => { if (result.value) { editToggle(false); loadPage() } });
        }
        else {
          Swal.fire(
            "Oops...",
            "Erro ao tentar cancelar o pedido.",
            "error"
          );
        }
      }
    })
  }

  let btnFinishOrder

  if (model.orderHistoric) {
    if (model.orderHistoric.status == 'Aguardando Entrega/Retirada') {
      btnFinishOrder = (<button onClick={() => { finishOrder() }} className='btn btn-success'>Finalizar pedido</button>)
    }
  }

  return (
    <>
      <Modal
        className={'modalNew modal-md'}
        isOpen={embroideryModal}
        toggle={embroideryModalToggleHeader}>
        <ModalHeader toggle={embroideryModalToggleHeader}>Detalhes do Bordado {embroidery.title}</ModalHeader>
        <ModalBody className="content">
          <Row className="lineComponent">
            <Col sm="12">
              <label className="label">Nome
                        <b style={{
                  color: 'red'
                }}>*</b>
              </label>
              <input
                tabIndex={0}
                disabled={true}
                type="text"
                className="form-control "
                value={embroidery.title}
                onChange={event => setEmbroidery({ title: event.target.value, photo: embroidery.photo, description: embroidery.description })} />
            </Col>
          </Row>
          <Row className="lineComponent">
            <Col sm='6'>
              <label className="label">Foto bordado <b style={{ color: 'red' }}>*</b></label>
              <Row>
                <Col sm="9">
                  <label
                    id="thumbnail"
                    style={{ backgroundImage: `url(${preview})` }}
                    className={thumbnail ? "has-thumbnail" : ""}
                  >
                    {img}
                    <input
                      disabled={true}
                      type="file"
                      onChange={event => setThumbnail(event.target.files[0])}
                    />
                    <IconContext.Provider value={{ className: "icon" }}>
                      <div>
                        <FaCamera />
                      </div>
                    </IconContext.Provider>
                  </label>
                </Col>

              </Row>
            </Col>
            <Col sm='6'>
              <label className="label">Descrição

                    </label>
              <textarea disabled={true} onChange={event => setEmbroidery({ title: embroidery.title, photo: embroidery.photo, description: event.target.value })} value={embroidery.description} className="form-control " rows="9" cols="50">

              </textarea>
            </Col>
          </Row>

          <ModalFooter className='modalfooter'>

            <button
              className="btn btn-secondary btnModal"
              onClick={() => embroiderytModalToggle(false)}>
              Fechar
                </button>
          </ModalFooter>
        </ModalBody>
      </Modal>

      <Modal
        className={'modalNew modal-lg'}
        isOpen={productModal}
        toggle={productModalToggleHeader}>
        <ModalHeader toggle={productModalToggleHeader}>Detalhes do Produto {product.title}</ModalHeader>
        <ModalBody className="content">
          <Row className="lineComponent">
            <Col sm="6">
              <label className="label">Nome
                        <b style={{
                  color: 'red'
                }}>*</b>
              </label>
              <input
                tabIndex={0}
                type="text"
                className="form-control "
                value={product.title}
                disabled={true}
                onChange={event => setProduct({
                  title: event.target.value, unitMeasure: product.unitMeasure, description: product.description,
                  width: product.width, photo: product.photo, length: product.length, height: product.height
                })} />
            </Col>
            <Col sm="6">
              <label className="labelUnd">Unidade de medida
                        <b style={{
                  color: 'red'
                }}>*</b>
              </label>
              <br />
              <FormGroup disabled={true} value='cm' className='unitOptions' check onChange={event => {
                setChecked({ cm: false, m: true }); setProduct({
                  title: product.title, unitMeasure: event.target.value, description: product.description,
                  width: product.width, photo: product.photo, length: product.length, height: product.height
                })
              }}>
                <Label check>
                  <Input disabled={true} checked={checked.cm} value='cm' type="radio" name="radio1" />{' '}
                            Centimetro(s)
                        </Label>
              </FormGroup>
              <FormGroup disabled={true} value='m' className='unitOptions' check onChange={event => {
                setChecked({ cm: false, m: true }); setProduct({
                  title: product.title, unitMeasure: event.target.value, description: product.description,
                  width: product.width, photo: product.photo, length: product.length, height: product.height
                })
              }}>
                <Label check>
                  <Input disabled={true} checked={checked.m} value='m' type="radio" name="radio1" />{' '}
                           Metro(s)
                        </Label>
              </FormGroup>
            </Col>
          </Row>
          <Row className="lineComponent">
            <Col sm='6'>
              <label className="label">Foto Produto <b style={{ color: 'red' }}>*</b></label>
              <Row>
                <Col sm="9">
                  <label
                    id="thumbnailProduct"
                    style={{ backgroundImage: `url(${preview})` }}
                    className={thumbnail ? "has-thumbnail" : ""}
                  >
                    {img}
                    <input
                      disabled={true}
                      type="file"
                      onChange={event => setThumbnail(event.target.files[0])}
                    />
                    <IconContext.Provider value={{ className: "icon" }}>
                      <div>
                        <FaCamera />
                      </div>
                    </IconContext.Provider>
                  </label>
                </Col>

              </Row>
            </Col>
            <Col sm='6'>
              <Row>
                <Col sm="4">
                  <label className="label">Comprimento</label>
                  <input
                    type='text'
                    onKeyPress={(evt) => { if (!isNumeric(evt)) { evt.preventDefault() } }}
                    className="form-control"
                    onClick={(event) => { if (event.target.value == '0') { event.target.value = '' } else event.target.value = product.length }}
                    onBlur={(event) => blurEvent(event)}
                    value={product.length}
                    disabled={true}
                    onChange={event => {
                      if (fieldValidation(event)) {
                        setProduct({
                          title: product.title, unitMeasure: product.unitMeasure,
                          amount: product.amount, width: product.width, length: event.target.value, height: product.height
                        })
                      }
                    }} />
                </Col>

                <Col sm="4">
                  <label className="label">Largura</label>
                  <input
                    type='text'
                    onKeyPress={(evt) => { if (!isNumeric(evt)) { evt.preventDefault() } }}
                    className="form-control"
                    onClick={(event) => { if (event.target.value == '0') { event.target.value = '' } else event.target.value = product.width }}
                    onBlur={(event) => blurEvent(event)}
                    value={product.width}
                    disabled={true}
                    onChange={event => {
                      if (fieldValidation(event)) {
                        setProduct({
                          title: product.title, unitMeasure: product.unitMeasure,
                          amount: product.amount, width: event.target.value, length: product.length, height: product.height
                        })
                      }
                    }} />
                </Col>

                <Col sm="4">
                  <label className="label">Altura</label>
                  <input
                    type='text'
                    onKeyPress={(evt) => { if (!isNumeric(evt)) { evt.preventDefault() } }}
                    className="form-control"
                    onClick={(event) => { if (event.target.value == '0') { event.target.value = '' } else event.target.value = product.height }}
                    onBlur={(event) => blurEvent(event)}
                    value={product.height}
                    disabled={true}
                    onChange={event => {
                      if (fieldValidation(event)) {
                        setProduct({
                          title: product.title, unitMeasure: product.unitMeasure,
                          amount: product.amount, width: product.width, length: product.length, height: event.target.value
                        })
                      }
                    }} />
                </Col>
              </Row>
              <br />
              <label className="label">Descrição</label>
              <textarea disabled={true} onChange={event => setProduct({
                title: product.title, unitMeasure: product.unitMeasure, description: event.target.value,
                amount: product.amount, width: product.width, length: product.length, height: product.height
              })
              } value={product.description} className="form-control " rows="9" cols="50">

              </textarea>
            </Col>
          </Row>

          <ModalFooter className='modalfooter'>
            <button
              className="btn btn-secondary btnModal"
              onClick={() => productModalToggle(false)}>
              Fechar
                </button>
          </ModalFooter>
        </ModalBody>
      </Modal>

      <Modal
        className={'modalNew modal-md'}
        isOpen={thumbnailModal}
        toggle={thumbnailModalToggleHeader}>
        <ModalHeader toggle={thumbnailModalToggleHeader}>Detalhes da Estampa {modelThumbnail.title}</ModalHeader>
        <ModalBody className="content">
          <Row className="lineComponent">
            <Col sm="12">
              <label className="label">Nome
                        <b style={{
                  color: 'red'
                }}>*</b>
              </label>
              <input
                tabIndex={0}
                disabled={true}
                type="text"
                className="form-control "
                value={modelThumbnail.title}
                onChange={event => setModelThumbnail({ title: event.target.value, photo: modelThumbnail.photo, description: modelThumbnail.description })} />
            </Col>
          </Row>
          <Row className="lineComponent">
            <Col sm='6'>
              <label className="label">Foto Estampa <b style={{ color: 'red' }}>*</b></label>
              <Row>
                <Col sm="9">
                  <label
                    id="thumbnail"
                    style={{ backgroundImage: `url(${preview})` }}
                    className={thumbnail ? "has-thumbnail" : ""}
                  >
                    {img}
                    <input
                      type="file"
                      disabled={true}
                      onChange={event => setThumbnail(event.target.files[0])}
                    />
                    <IconContext.Provider value={{ className: "icon" }}>
                      <div>
                        <FaCamera />
                      </div>
                    </IconContext.Provider>
                  </label>
                </Col>

              </Row>
            </Col>
            <Col sm='6'>
              <label className="label">Descrição

                    </label>
              <textarea disabled={true} onChange={event => setModelThumbnail({ title: modelThumbnail.title, photo: modelThumbnail.photo, description: event.target.value })} value={modelThumbnail.description} className="form-control " rows="9" cols="50">

              </textarea>
            </Col>
          </Row>

          <ModalFooter className='modalfooter'>
            <button
              className="btn btn-secondary btnModal"
              onClick={() => thumbnailModalToggle(false)}>
              Fechar
                </button>
          </ModalFooter>
        </ModalBody>
      </Modal>

      <Modal
        visible={visible}
        className={'modalNew modal-xl'}
        isOpen={editModal}
        toggle={editToggleHeader}>
        <ModalHeader toggle={editToggleHeader}>Informações do Pedido</ModalHeader>
        <ModalBody className="content">
          <Row className="lineComponent">
            <Col sm="4">
              <label className="label">Nome
                        <b style={{
                  color: 'red'
                }}>*</b>
              </label>
              <input
                tabIndex={0}
                disabled={isEdited}
                type="text"
                className="form-control "
                value={model.title}
                onChange={event => setModel({
                  _id: model._id,
                  title: event.target.value, unitMeasure: model.unitMeasure, description: model.description,
                  width: model.width, orderValue: model.orderValue, length: model.length, height: model.height,
                  amount: model.amount, status: model.stats, deliveryDate: model.deliveryDate, embroidery: model.embroidery,
                  thumbnail: model.thumbnail, product: model.product, orderHistoric: model.orderHistoric, client: model.client
                })} />
            </Col>
            <Col sm="4">
              <label className="labelUnd">Unidade de medida
                        <b style={{
                  color: 'red'
                }}>*</b>
              </label>
              <br />
              <FormGroup value='cm' className='unitOptions' check onChange={event => {
                setCheckedOrder({ cm: true, m: false });
                setModel({
                  _id: model._id, id: model.id,
                  title: model.title, unitMeasure: event.target.value, description: model.description,
                  width: model.width, orderValue: model.orderValue, length: model.length, height: model.height,
                  amount: model.amount, status: model.stats, deliveryDate: model.deliveryDate, embroidery: model.embroidery,
                  thumbnail: model.thumbnail, product: model.product, orderHistoric: model.orderHistoric, client: model.client
                })
              }}>
                <Label check>
                  <Input checked={checkedOrder.cm} value='cm' type="radio" name="radio1" />{' '}
                            Centimetro(s)
                        </Label>
              </FormGroup>
              <FormGroup value='m' className='unitOptions' check onChange={event => {
                setCheckedOrder({ cm: false, m: true });
                setModel({
                  _id: model._id, id: model.id,
                  title: model.title, unitMeasure: event.target.value, description: model.description,
                  width: model.width, orderValue: model.orderValue, length: model.length, height: model.height,
                  amount: model.amount, status: model.stats, deliveryDate: model.deliveryDate, embroidery: model.embroidery,
                  thumbnail: model.thumbnail, product: model.product, orderHistoric: model.orderHistoric, client: model.client
                })
              }}>
                <Label check>
                  <Input disabled={isEdited} value='m' checked={checkedOrder.m} type="radio" name="radio1" />{' '}
                           Metro(s)
                        </Label>
              </FormGroup>
            </Col>
            <Col sm="4" className='referencesColumn'>
              <label className="labelUnd">Produto Modelo</label>
              <div>
                <Select isDisabled={isEdited} value={{ label: product.title, value: product._id }} onChange={(event) => { getInformation('produto', event.value) }} className='options' options={productOptions} />
                <button id='moreInfoProduct'
                  onClick={(event) => {
                    if (product._id) {
                      setImg(<img className='thumbnailEdit' src={images('./' + product.photo)} />)
                      productModalToggle(true)
                    }
                  }}
                  className='btn btn-primary btnMoreAbout'> + Detalhes</button>
              </div>
            </Col>
            <div class="vl"></div>
          </Row>

          <Row className="lineComponent">
            <Col sm='4'>

              <label className="label">Descrição<b style={{
                color: 'red'
              }}>*</b>
              </label>
              <textarea disabled={isEdited} value={model.description} className="form-control " rows="7" cols="50" onChange={event => setModel({
                title: model.title, unitMeasure: model.unitMeasure, description: event.target.value,
                _id: model._id, id: model.id,
                width: model.width, orderValue: model.orderValue, length: model.length, height: model.height,
                amount: model.amount, status: model.stats, deliveryDate: model.deliveryDate, embroidery: model.embroidery,
                thumbnail: model.thumbnail, product: model.product, orderHistoric: model.orderHistoric, client: model.client
              })}>
              </textarea>
            </Col>

            <Col sm='4'>
              <Row>
                <Col sm="4">
                  <label className="label">Comprimento</label>
                  <input
                    type='text'
                    disabled={isEdited}
                    onKeyPress={(evt) => { if (!isNumeric(evt)) { evt.preventDefault() } }}
                    className="form-control"
                    onClick={(event) => { if (event.target.value == '0') { event.target.value = '' } else event.target.value = model.length }}
                    onBlur={(event) => blurEvent(event)}
                    value={model.length}
                    onChange={event => {
                      if (fieldValidation(event)) {
                        setModel({
                          _id: model._id, id: model.id,
                          title: model.title, unitMeasure: model.unitMeasure, description: model.description,
                          width: model.width, orderValue: model.orderValue, length: event.target.value, height: model.height,
                          amount: model.amount, status: model.stats, deliveryDate: model.deliveryDate, embroidery: model.embroidery,
                          thumbnail: model.thumbnail, product: model.product, orderHistoric: model.orderHistoric, client: model.client
                        })
                      }
                    }} />
                </Col>
                <Col sm="4">
                  <label className="label">Largura</label>
                  <input
                    type='text'
                    disabled={isEdited}
                    onKeyPress={(evt) => { if (!isNumeric(evt)) { evt.preventDefault() } }}
                    className="form-control"
                    onClick={(event) => { if (event.target.value == '0') { event.target.value = '' } else event.target.value = model.width }}
                    onBlur={(event) => blurEvent(event)}
                    value={model.width}
                    onChange={event => {
                      if (fieldValidation(event)) {
                        setModel({
                          _id: model._id, id: model.id,
                          title: model.title, unitMeasure: model.unitMeasure, description: model.description,
                          width: event.target.value, orderValue: model.orderValue, length: model.length, height: model.height,
                          amount: model.amount, status: model.stats, deliveryDate: model.deliveryDate, embroidery: model.embroidery,
                          thumbnail: model.thumbnail, product: model.product, orderHistoric: model.orderHistoric, client: model.client
                        })
                      }
                    }} />
                </Col>
                <Col sm="4">
                  <label className="label">Altura</label>
                  <input
                    type='text'
                    disabled={isEdited}
                    onKeyPress={(evt) => { if (!isNumeric(evt)) { evt.preventDefault() } }}
                    className="form-control"
                    onClick={(event) => { if (event.target.value == '0') { event.target.value = '' } else event.target.value = model.height }}
                    onBlur={(event) => blurEvent(event)}
                    value={model.height}
                    onChange={event => {
                      if (fieldValidation(event)) {
                        setModel({
                          _id: model._id, id: model.id,
                          title: model.title, unitMeasure: model.unitMeasure, description: model.description,
                          width: model.width, orderValue: model.orderValue, length: model.length, height: event.target.value,
                          amount: model.amount, status: model.stats, deliveryDate: model.deliveryDate, embroidery: model.embroidery,
                          thumbnail: model.thumbnail, product: model.product, orderHistoric: model.orderHistoric, client: model.client
                        })
                      }
                    }} />
                </Col>
              </Row>
            </Col>
            <Col sm="4" className='referencesColumn'>
              <label className="labelUnd">Estampa Modelo</label>
              <div>
                <Select isDisabled={isEdited} value={{ label: modelThumbnail.title, value: modelThumbnail._id }} onChange={(event) => { getInformation("estampa", event.value) }} className='options' options={thumbnailsOptions} />
                <button id='moreInfoThumb' onClick={(event) => {
                  if (modelThumbnail._id) {
                    setImg(<img className='thumbnailEdit' src={images('./' + modelThumbnail.photo)} />)
                    thumbnailModalToggle(true)
                  }
                }} className='btn btn-primary btnMoreAbout'> + Detalhes</button>
              </div>
            </Col>
          </Row>
          <div class="v2"></div>
          <Row>
            <div class="v3"></div>
            <Row className='offset-4 part2Middle'>
              <Col sm='6'>
                <Row>
                  <Col sm='6'>
                    <label className="label">Valor
                        <b style={{
                        color: 'red'
                      }}>*</b>
                    </label>
                    <input
                      disabled={true}
                      type='text'
                      onKeyPress={(evt) => { if (!isNumeric(evt)) { evt.preventDefault() } }}
                      className="form-control"
                      onClick={(event) => { if (event.target.value == '0') { event.target.value = '' } else event.target.value = model.orderValue }}
                      onBlur={(event) => blurEvent(event)}
                      value={model.orderValue}
                      onChange={event => {
                        if (fieldValidation(event)) {
                          setModel({
                            _id: model._id, id: model.id,
                            title: model.title, unitMeasure: model.unitMeasure, description: model.description,
                            width: model.width, orderValue: event.target.value, length: model.length, height: model.height,
                            amount: model.amount, status: model.stats, deliveryDate: model.deliveryDate, embroidery: model.embroidery,
                            thumbnail: model.thumbnail, product: model.product, orderHistoric: model.orderHistoric, client: model.client
                          })
                        }
                      }} />
                  </Col>
                  <Col sm='6'>
                    <label className="label">Quantidade
                        <b style={{
                        color: 'red'
                      }}>*</b>
                    </label>
                    <input
                      disabled={true}
                      type='text'
                      onKeyPress={(evt) => { var charCode = (evt.which) ? evt.which : evt.keyCode; if ((charCode > 31 && (charCode < 48 || charCode > 57))) { evt.preventDefault() } }}
                      className="form-control"
                      onClick={(event) => { if (event.target.value == '0') { event.target.value = '' } else event.target.value = model.amount }}
                      onBlur={(event) => blurEvent(event)}
                      value={model.amount}
                      onChange={event => {
                        if (fieldValidation(event)) {
                          setModel({
                            _id: model._id, id: model.id,
                            title: model.title, unitMeasure: model.unitMeasure, description: model.description,
                            width: model.width, orderValue: model.orderValue, length: model.length, height: model.height,
                            amount: event.target.value, status: model.stats, deliveryDate: model.deliveryDate, embroidery: model.embroidery,
                            thumbnail: model.thumbnail, product: model.product, orderHistoric: model.orderHistoric, client: model.client
                          })
                        }
                      }} />
                  </Col>
                </Row>
              </Col>
            </Row>
            <Col className='offset-4' sm="4">
              <label className="label">Data de Entrega
                        <b style={{
                  color: 'red'
                }}>*</b>
              </label>
              <Input
                type="date"
                name="date"
                value={model.deliveryDate}
                disabled={isEdited}
                onChange={(event) => {
                  setModel({
                    _id: model._id, id: model.id,
                    title: model.title, unitMeasure: model.unitMeasure, description: model.description,
                    width: model.width, orderValue: model.orderValue, length: model.length, height: model.height,
                    amount: model.amount, status: model.stats, deliveryDate: event.target.value, embroidery: model.embroidery,
                    thumbnail: model.thumbnail, product: model.product, orderHistoric: model.orderHistoric, client: model.client
                  })
                }}
                placeholder=""
              />

            </Col>
            <Col sm='4'>
              <div className='last'>
                <label className="labelUnd">Bordado Modelo</label>
                <Select isDisabled={isEdited} value={{ label: embroidery.title, value: embroidery._id }} onChange={(event) => { getInformation("bordado", event.value) }} className='options' options={embroideryOptions} />
                <button id='moreInfoEnbroidery' onClick={(event) => {
                  if (embroidery._id) {
                    setImg(<img className='thumbnailEdit' src={images('./' + embroidery.photo)} />)
                    embroiderytModalToggle(true)
                  }
                }} className='btn btn-primary btnMoreAbout'> + Detalhes</button>
              </div>
            </Col>
            <Col sm='4'>
              <br /><br />
              <div className='last'>
                <label className="labelUnd">Cliente<b style={{
                  color: 'red'
                }}>*</b></label>
                <Select value={{ label: client.fullName, value: '' }} isDisabled={true} onChange={(event) => { getInformation('client', event.value) }} className='options' />
              </div>
            </Col>
          </Row>

          <ModalFooter className='modalfooter'>
            {btnFinishOrder}
            <button
              onClick={() => { cancelOrder() }}
              className="btn btn-danger btnModal">
              Cancelar Pedido
                </button>
            <button id="btnAlterar"
              onClick={() => { update() }}
              className="btn btn-primary btnModal">
              Editar
                </button>{" "}
            <button
              id='btnClose'
              className="btn btn-secondary btnModal"
              onClick={() => { setIsEdited(true); editToggle(false) }}>
              Fechar
                </button>
          </ModalFooter>
        </ModalBody>
      </Modal>

      <div className='dashboard'>
        <AsyncBoard
          data={data}
          hideCardDeleteIcon
          onCardClick={(cardId) => { getInformation('order', cardId) }}
          onCardMoveAcrossLanes={(fromLaneId, toLaneId, cardId, index) => { updadteStatus(cardId, toLaneId) }}
        />
      </div>
    </>
  );
}
export default React.memo(Dashboard);

