import React, { useState } from 'react';

import {
  Collapse,
  Container,
  Navbar,
  NavbarBrand,
  Nav
} from 'reactstrap';


import './index.css'
import 'bootstrap/dist/css/bootstrap.min.css';

import Login from '../Login/index'
// import Footer from '../../Structure/Footer'

export default class Home extends React.Component {
  render() {
    return (
      <>
        <Navbar className='header' light expand="md">
          <NavbarBrand className='headerName' href="#home">2Do - System</NavbarBrand>

          <Nav className="mr-auto" navbar>
          </Nav>

        </Navbar>
        <Container className='home'>
          <Login />
        </Container>
        {/* <Footer/> */}
      </>
    );
  }
}
