import React, { useEffect, useState } from "react";
import {
  Modal,
  Row,
  Container,
  Col,
  ModalHeader,
  ModalBody,
  Input,
  ModalFooter,
} from 'reactstrap';
import Swal from "sweetalert2";
import BootstrapTable from "react-bootstrap-table-next";
import ToolkitProvider, { Search } from "react-bootstrap-table2-toolkit";
import paginationFactory from "react-bootstrap-table2-paginator";
import ReactTooltip from 'react-tooltip'
import { FaPencilAlt, FaTrashAlt } from "react-icons/fa";
// import Select from "react-select";
import LoadingOverlay from 'react-loading-overlay';
import './index.css'
import "react-bootstrap-table-next/dist/react-bootstrap-table2.min.css";
import "semantic-ui-css/semantic.min.css";
import "bootstrap/dist/css/bootstrap.css";
import api from '../../services/api';

const Users = props => {
  //Grids Config
  const { SearchBar } = Search;
  // pagination option
  const customTotal = (from, to, size) => (
    <span className="react-bootstrap-table-pagination-total">
      Mostrando {from + " "}
            até {to + " "}
            de {size + " "}
            Resultados
    </span>
  );
  const options = {
    paginationSize: 6,
    pageStartIndex: 1,
    alwaysShowAllBtns: true, // Always show next and previous button
    // withFirstAndLast: false, // Hide the going to First and Last page button
    hideSizePerPage: true, // Hide the sizePerPage dropdown always
    // hidePageListOnlyOnePage: true, // Hide the pagination list when only one page
    firstPageText: "Primeira",
    prePageText: "Anterior",
    nextPageText: "Próxima",
    lastPageText: "Última",
    nextPageTitle: "Primeira página",
    prePageTitle: "Pre página",
    firstPageTitle: "Póxima página",
    lastPageTitle: "Última página",
    showTotal: true,
    paginationTotalRenderer: customTotal
  };

  //Tale Config
  const columns = [
    {
      dataField: "fullName",
      text: "Nome",
      classes: "tableContent"
    }, {
      dataField: "email",
      text: "E-mail",
      classes: "tableContent"
    }, {
      dataField: "role",
      text: "Nivel Acesso",
      classes: "tableContent"
    }, {
      dataField: "options",
      text: "Opções"
    }
  ];

  //Modal Setings New
  const [newModal,
    setNewModal] = useState(false);
  const newToggle = state => setNewModal(state);
  const newToggleHeader = () => setNewModal(!newModal);

  //Modal Setings Edit
  const [editModal,
    setEditModal] = useState(false);
  const editToggle = state => setEditModal(state);
  const editToggleHeader = () => setEditModal(!editModal);

  //table rows load
  let auxData = [];
  const [data,
    setData] = useState([]);

  const [isActive,
    setIsActive] = useState(true);

  const [confirmPassword,
    setConfirmPassword] = useState(undefined);

  // Model Variables
  const [model, setModel] = useState({ _id: undefined, email: undefined, username: undefined, password: undefined, role: 'Cliente' });

  useEffect(() => {
    loadPage();
  }, []);

  async function loadPage() {
    const response = await api.get('/users')
    console.log(response)
    auxData = [];
    if (response.data) {
      response.data.forEach(register => {

        let btnExclude = ''
        if (register.username != sessionStorage.getItem('id').split(',')[1]) {
          btnExclude = < button
            id={register._id}
            data-tip="Excluir" type="button" className="btn btnDelete" onClick={
              event => { remove(event.currentTarget.getAttribute("id")) }
            } > <FaTrashAlt /> </button>
        }

        auxData.push({
          fullName: register.username,
          email: register.email,
          role: register.role,
          options: [
            <div className="options" > <button
              id={register._id}
              data-tip="Editar"
              type="button"
              onClick={(event) => { if (getInformation(event.currentTarget.getAttribute("id"))) { editToggle(true) } }}
              className="btn btnEdit"
            >
              <ReactTooltip place="top" type="dark" effect="solid" />
              <FaPencilAlt />
            </button>
              {btnExclude}
            </div >]
        })
      })
    }
    // load the lines of the table
    setData(auxData.map(t => t));
    setIsActive(false)
  }

  async function getInformation(id) {

    const response = await api.get("/users/" + id);
    console.log(response)
    if (response.data) {
      console.log(response.data)
      setModel(response.data)
      return true
    }
    else {
      Swal.fire(
        "Oops...",
        "Erro ao buscar buscar as informações do registro",
        "error"
      );
      return false
    }
  }

  async function remove(id) {
    Swal.fire({
      title: 'Atenção',
      icon: 'warning',
      html:
        'Não será possivel desfazer um registro excluido. \n Deseja prosseguir?',
      showCancelButton: true,
      focusConfirm: false,
      confirmButtonText:
        'Sim',
      cancelButtonText:
        'Cancelar',
    }).then(async (value) => {
      if (value.value) {

        const response = await api.delete("users/" + id)

        if (response.data) {
          await Swal.fire(
            "Deleted!",
            "Deletado com Sucesso!",
            "success"
          ).then(result => { if (result.value) loadPage() });
        }
        else {
          Swal.fire(
            "Oops...",
            "Erro ao tentar deletar o registro.",
            "error"
          );
        }
      }
    })

  }

  async function create() {
    try {
      if (!model.username || !model.password || !model.email || !model.role) {
        Swal.fire(
          "Oops...",
          "Por favor, preencha todos os campos obrigatórios.",
          "info"
        );
      }
      else if (model.password != confirmPassword) {
        Swal.fire(
          "Oops...",
          "As Senhas digitadas não correspondem ",
          "warning"
        );
      }
      else {
        // disable the button to await the save
        document.getElementById('btnSaveProject').disabled = true
        document.getElementById('btnSaveProject').innerHTML = "Salvando..."

        const response = await api.post("/users", model)
        if (response.data) {
          await Swal.fire(
            "success!",
            "Salvo com sucesso!",
            "success"
          )
          newToggle(false)
          loadPage();
        }
        else {
          await Swal.fire(
            "Oops...",
            "Error ao tentar salvar.",
            "error"
          );
          document.getElementById('btnAlterar').disabled = false
          document.getElementById('btnSave').innerHTML = "Salvar"
        }
      }
    }
    catch (e) {
      await Swal.fire(
        "Oops...",
        "Error ao tentar salvar.",
        "error"
      );
    }
  }

  async function update() {
    try {
      if (!model.username || !model.email || !model.role) {
        Swal.fire(
          "Oops...",
          "Por favor, preencha todos os campos obrigatórios.",
          "info"
        );
      }
      if (model.password) {
        if (model.password != confirmPassword) {
          Swal.fire(
            "Oops...",
            "As Senhas digitadas não correspondem ",
            "warning"
          );
        }
        else {
          // disable the button to await the save
          document.getElementById('btnAlterar').disabled = true
          document.getElementById('btnAlterar').innerHTML = "Salvando..."

          const response = await api.put("/users/" + model._id, model)
          if (response.data) {
            await Swal.fire(
              "success!",
              "Salvo com sucesso!",
              "success"
            )
            editToggle(false)
            loadPage();
          }
          else {
            await Swal.fire(
              "Oops...",
              "Error ao tentar salvar.",
              "error"
            );
            document.getElementById('btnAlterar').disabled = false
            document.getElementById('btnAlterar').innerHTML = "Salvar"
          }
        }
      }
      else {
        // disable the button to await the save
        document.getElementById('btnAlterar').disabled = true
        document.getElementById('btnAlterar').innerHTML = "Salvando..."

        const response = await api.put("/users/" + model._id, model)
        if (response.data) {
          await Swal.fire(
            "success!",
            "Salvo com sucesso!",
            "success"
          )
          editToggle(false)
          loadPage();
        }
        else {
          await Swal.fire(
            "Oops...",
            "Error ao tentar salvar.",
            "error"
          );
          document.getElementById('btnAlterar').disabled = false
          document.getElementById('btnAlterar').innerHTML = "Salvar"
        }
      }
    }
    catch (e) {
      Swal.fire(
        "Oops...",
        "Erro ao tentar Salvar",
        "info"
      );
    }
  }

  return (<>
    <Modal
      className={'modalNew modal-md'}
      isOpen={newModal}
      toggle={newToggleHeader}>
      <ModalHeader toggle={newToggleHeader}>Novo Usuario</ModalHeader>
      <ModalBody className="content">
        <Row className="lineComponent">
          <Col sm="12">
            <label className="label">Nome
                        <b style={{
                color: 'red'
              }}>*</b>
            </label>
            <input
              type="text"
              className="form-control "
              value={model.username}
              onChange={event => setModel({ username: event.target.value, email: model.email, password: model.password, role: model.role })} />
          </Col>
          <Col sm="12">
            <label className="label">E-mail
                        <b style={{
                color: 'red'
              }}>*</b>
            </label>
            <input
              type="email"
              className="form-control "
              value={model.email}
              onChange={event => setModel({ username: model.username, email: event.target.value, password: model.password, role: model.role })} />
          </Col>
        </Row>
        <Row className="lineComponent">
          <Col sm="6">
            <label className="label">Senha
                        <b style={{
                color: 'red'
              }}>*</b>
            </label>
            <input
              type="password"
              className="form-control "
              value={model.password}
              onKeyUp={(event) => {
                if (event.target.value) {
                  if (event.target.value.length > 0) {
                    document.getElementById('confirm').style.display = 'inline'
                  }
                  else {
                    document.getElementById('confirm').style.display = 'none'
                  }
                }
                else {
                  document.getElementById('confirm').style.display = 'none'
                }
              }}
              onChange={event => {
                setModel({ _id: model.id, username: model.username, email: model.email, password: event.target.value, role: model.role })
              }} />
          </Col>
          <Col sm="6">
            <div id='confirm'>
              <label className="label">Confirmação senha
                        <b style={{
                  color: 'red'
                }}>*</b>
              </label>
              <input
                type="password"
                className="form-control "
                value={confirmPassword}
                onChange={event => setConfirmPassword(event.target.value)} />
            </div>
            <label className="label">Nivel Acesso
                        <b style={{
                color: 'red'
              }}>*</b>
            </label>
            <select className="form-control "
              value={model.role}
              onChange={event => setModel({ username: model.username, email: model.email, password: event.target.value, role: model.role })} >
              <option value="Admin">Admin</option>
              <option value="Cliente">Cliente</option>
            </select>
          </Col>
        </Row>
        <ModalFooter className='modalfooter'>
          <button id="btnSaveProject"
            onClick={() => { create() }}
            className="btn btn-primary btnModal">
            Salvar
                </button>{" "}
          <button
            id="btnsave"
            className="btn btn-secondary btnModal"
            onClick={() => newToggle(false)}>
            Cancelar
                </button>
        </ModalFooter>
      </ModalBody>
    </Modal>

    <Modal
      className={'modalNew modal-md'}
      isOpen={editModal}
      toggle={editToggleHeader}>
      <ModalHeader toggle={editToggleHeader}>Editar Usuario</ModalHeader>
      <ModalBody className="content">
        <Row className="lineComponent">
          <Col sm="12">
            <label className="label">Nome
                        <b style={{
                color: 'red'
              }}>*</b>
            </label>
            <input
              type="text"
              className="form-control "
              value={model.username}
              onChange={event => setModel({ _id: model.id, username: event.target.value, email: model.email, password: model.password, role: model.role })} />
          </Col>
          <Col sm="12">
            <label className="label">E-mail
                        <b style={{
                color: 'red'
              }}>*</b>
            </label>
            <input
              type="email"
              className="form-control "
              value={model.email}
              onChange={event => setModel({ _id: model.id, username: model.username, email: event.target.value, password: model.password, role: model.role })} />
          </Col>
        </Row>
        <Row className="lineComponent">
          <Col sm="6">
            <label className="label">Senha
                        <b style={{
                color: 'red'
              }}>*</b>
            </label>
            <input
              type="password"
              className="form-control "
              value={model.password}
              onKeyUp={(event) => {
                if (event.target.value) {
                  if (event.target.value.length > 0) {
                    document.getElementById('confirm').style.display = 'inline'
                  }
                  else {
                    document.getElementById('confirm').style.display = 'none'
                  }
                }
                else {
                  document.getElementById('confirm').style.display = 'none'
                }
              }}
              onChange={event => {
                setModel({ _id: model.id, username: model.username, email: model.email, password: event.target.value, role: model.role })
              }} />
          </Col>
          <Col sm="6">
            <div id='confirm'>
              <label className="label">Confirmação senha
                        <b style={{
                  color: 'red'
                }}>*</b>
              </label>
              <input
                type="password"
                className="form-control "
                value={confirmPassword}
                onChange={event => setConfirmPassword(event.target.value)} />
            </div>
            <label className="label">Nivel Acesso
                        <b style={{
                color: 'red'
              }}>*</b>
            </label>
            <select className="form-control "
              value={model.role}
              onChange={event => setModel({ _id: model.id, username: model.username, email: model.email, password: event.target.value, role: model.role })} >
              <option value="Admin">Admin</option>
              <option value="Cliente">Cliente</option>
            </select>
          </Col>
        </Row>
        <ModalFooter className='modalfooter'>
          <button id="btnAlterar"
            onClick={() => { update() }}
            className="btn btn-primary btnModal">
            Salvar
                </button>{" "}
          <button
            id="btnsave"
            className="btn btn-secondary btnModal"
            onClick={() => editToggle(false)}>
            Cancelar
                </button>
        </ModalFooter>
      </ModalBody>
    </Modal>

    < Container className="tablePage" fluid >
      <ToolkitProvider keyField="name" data={data} columns={columns} search>
        {props => {
          return (
            <div>
              <button onClick={() => { setModel({ _id: undefined, email: undefined, username: undefined, password: undefined, role: 'Cliente' }); newToggle(true) }} className="btnNew btn btn-primary">
                Novo Usuario
                    </button>
              <div className="searchBar">
                <label className="labelSearch">Buscar:</label>
                <SearchBar {...props.searchProps} />
              </div>
              <div className="table">
                <LoadingOverlay
                  active={isActive}
                  spinner
                  text='Carregando...'
                ></LoadingOverlay>
                <BootstrapTable
                  {...props.baseProps}
                  striped
                  hover
                  condensed
                  pagination={paginationFactory(options)} />
              </div>
            </div>
          )
        }}
      </ToolkitProvider>
    </Container>
  </>)
    ;
}
export default React.memo(Users);