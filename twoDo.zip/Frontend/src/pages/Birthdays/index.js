import React, { useEffect, useState } from "react";

import {
  Modal,
  Row,
  Container,
  Col,
  ModalHeader,
  ModalBody,
  ModalFooter,
} from 'reactstrap';

import Swal from "sweetalert2";
import BootstrapTable from "react-bootstrap-table-next";
import ToolkitProvider, { Search } from "react-bootstrap-table2-toolkit";
import paginationFactory from "react-bootstrap-table2-paginator";
import ReactTooltip from 'react-tooltip'
import { RiCalendarCheckLine } from "react-icons/ri";
// import Select from "react-select";

import './index.css'
import "react-bootstrap-table-next/dist/react-bootstrap-table2.min.css";
import "semantic-ui-css/semantic.min.css";
import "bootstrap/dist/css/bootstrap.css";
import api from '../../services/api';
import cake from '../../Imgs/cake.png'
const Birthdays = props => {
  //Grids Config
  const { SearchBar } = Search;
  // pagination option
  const customTotal = (from, to, size) => (
    <span className="react-bootstrap-table-pagination-total">
      Mostrando {from + " "}
            até {to + " "}
            de {size + " "}
            Resultados
    </span>
  );
  const options = {
    paginationSize: 6,
    pageStartIndex: 1,
    alwaysShowAllBtns: true, // Always show next and previous button
    // withFirstAndLast: false, // Hide the going to First and Last page button
    hideSizePerPage: true, // Hide the sizePerPage dropdown always
    // hidePageListOnlyOnePage: true, // Hide the pagination list when only one page
    firstPageText: "Primeira",
    prePageText: "Anterior",
    nextPageText: "Próxima",
    lastPageText: "Última",
    nextPageTitle: "Primeira página",
    prePageTitle: "Pre página",
    firstPageTitle: "Póxima página",
    lastPageTitle: "Última página",
    showTotal: true,
    paginationTotalRenderer: customTotal
  };

  //Tale Config
  const columns = [
    {
      dataField: "fullName",
      text: "Nome",
      classes: "tableContent"
    }, {
      dataField: "phone",
      text: "Telefone",
      classes: "tableContent"
    }, {
      dataField: "options",
      text: ""
    }
  ];

  //Modal Setings New
  const [newModal,
    setNewModal] = useState(false);
  const newToggle = state => setNewModal(state);
  const newToggleHeader = () => setNewModal(!newModal);

  //Modal Setings Edit
  const [editModal,
    setEditModal] = useState(false);
  const editToggle = state => setEditModal(state);
  const editToggleHeader = () => setEditModal(!editModal);

  //table rows load
  let auxData = [];
  const [data,
    setData] = useState([]);

  const [page,
    setPage] = useState();

  useEffect(() => {
    loadPage();
  }, []);

  async function loadPage() {
    const response = await api.get('/birthday')
    console.log(response)
    auxData = [];

    if (typeof (response.data) != 'string') {
      response.data.forEach(register => {
        auxData.push({
          fullName: register.fullName,
          address: register.address,
          phone: register.phone,
          options: [
            <div className="optionsBirth" > <button
              id={register._id}
              name={register.fullName}
              phone={register.phone}
              data-tip="Enviar um parabéns via Whatsapp"
              type="button"
              onClick={(event) => { birthdays(event.currentTarget.getAttribute("id"), event.currentTarget.getAttribute("name"), event.currentTarget.getAttribute("phone")) }}
              className="btn btnGratings"
            >
              <ReactTooltip place="top" type="dark" effect="solid" />
              <RiCalendarCheckLine size='24px' /> Enviar parabéns
                    </button>

            </div >]
        })
      })
    }
    else {
      setPage(<>
        <div className='birthday'>
          <div className='birthdayText'> Não há aniversariantes para hoje </div>
          <img alt='Bolo de aniversário' width='20%' src={cake} />
        </div>
      </>)
    }
    // load the lines of the table
    setData(auxData.map(t => t));
  }

  async function birthdays(id, name, phone) {
    Swal.fire({
      title: 'Enviar os Parabéns!',
      text: "Confirma o envio do parabens para o(a) " + name + "?",
      icon: 'info',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Sim!'
    }).then(async (result) => {
      if (result.value) {

        window.open('https://api.whatsapp.com/send?phone=55'+phone+'&text=%F0%9F%8E%82%F0%9F%A5%B3%20Parab%C3%A9ns!%20%F0%9F%A5%B3%F0%9F%8E%82%20Oi%2C%20aqui%20%C3%A9%20do%20Maria%20e%20Ana%20Costura%20Creativa!%20Passei%20s%C3%B3%20para%20te%20desejar%20um%20feliz%20um%20anivers%C3%A1rio.%20Muita%20sa%C3%BAde%20e%20felicidade%20para%20voc%C3%AA%20e%20sua%20fam%C3%ADlia.%20Abra%C3%A7os!', '_blank');
        
        await api.put('/updateBirth/'+ id )

        loadPage()
      }
    })
  }

  return (<>
    < Container className="tablePage" fluid > <ToolkitProvider keyField="name" data={data} columns={columns} search>
      {props => {
        return (
          <div>
            <div className="searchBar">
              <label className="labelSearch">Buscar:</label>
              <SearchBar {...props.searchProps} />
            </div>
            <div className="table">
              <BootstrapTable
                {...props.baseProps}
                striped
                hover
                condensed
                pagination={paginationFactory(options)} />
            </div>
          </div>
        )
      }}
    </ToolkitProvider>
      {page}
    </Container>
  </>);
}
export default React.memo(Birthdays);