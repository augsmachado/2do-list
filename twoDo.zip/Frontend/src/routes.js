import React, { useEffect, useState } from "react";
import { BrowserRouter, Switch, Route } from 'react-router-dom';

import Dashboard from './pages/Dashboard';
import Home from './pages/Home/index';

import Clients from './pages/Client';
import Embroidery from './pages/Embroidery';
import Thumbnail from './pages/Thumbnail';
import Material from './pages/Material';
import Products from './pages/Products';
import Orders from './pages/Order';
import Birthdays from './pages/Birthdays';
import My404Component from './pages/404/index';
import Users from './pages/Users/index';

const Routs = props => {

  const [page,
    setPage] = useState(<>
      <Switch>
        <Route path="/" exact component={Home} />
        <Route path='*' exact={true} component={My404Component} />
      </Switch>
    </>);

  useEffect(() => {
    let url = document.URL.split('/')[document.URL.split('/').length - 1] 
    if (url != '' && url != '/') {
      if (sessionStorage.getItem('id')) {
        setPage(<>
          <Switch>
            <Route path="/" exact component={Home} />
            <Route path="/clientes" component={Clients} />
            <Route path="/bordados" component={Embroidery} />
            <Route path="/estampas" component={Thumbnail} />
            <Route path="/materiais" component={Material} />
            <Route path="/produtos" component={Products} />
            <Route path="/pedidos" component={Orders} />
            <Route path="/aniversariantes" component={Birthdays} />
            <Route path="/dashboard" component={Dashboard} />
            <Route path="/usuarios" component={Users} />
            <Route path='*' exact={true} component={My404Component} />
          </Switch>
        </>)
      }
      else {
        if (url.toString() != '404') {
          window.location.href = "/404"
        }
      }
    }
  }, []);


  return (
    <BrowserRouter>
      {page}
    </BrowserRouter>
  );
}
export default React.memo(Routs);